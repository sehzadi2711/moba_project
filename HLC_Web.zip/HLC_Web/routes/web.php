<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\v1\LoginController;
use App\Http\Controllers\Api\v1\DashboardController;
use App\Http\Controllers\Api\v1\ReportController;
use App\Http\Controllers\Api\v1\LocationMapController;
use App\Http\Controllers\Api\v1\ForgotPasswordController;
use Illuminate\Support\Facades\Artisan;

use App\Http\Controllers\CronController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/clear-cache', function () {
    Artisan::call('config:clear');
    Artisan::call('view:clear');
    Artisan::call('route:clear');
    echo 'cache cleared at ' . date('Y-m-d H:i:s');
});

Route::get('/', [LoginController::class, 'login'])->name('login1');
Route::get('/login', [LoginController::class, 'login'])->name('login');
Route::post('/appUserLogin', [LoginController::class, 'appUserLogin']);
Route::post('/appUserLogout', [LoginController::class, 'appUserLogout']);

Route::get('/forget-password', [ForgotPasswordController::class, 'forgetPassword']);
Route::post('/forgetPassword', [ForgotPasswordController::class, 'verifyPassword']);
Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm']);
Route::post('/updatePassword', [ForgotPasswordController::class, 'updatePassword']);

Route::post('/getwebservice', [CronController::class, 'getwebservice']);
Route::get('/api_curl', [CronController::class, 'api_curl']);
Route::get('/rawData', [CronController::class, 'rawData']);
Route::get('/rawData_v2', [CronController::class, 'rawData_v2']);
Route::get('/helper', [CronController::class, 'weightStampFunc']);

Route::group(['middleware' => 'auth'], function () {


    Route::get('/dashboard', [DashboardController::class, 'dashboard']);
    Route::get('/datalist', [DashboardController::class, 'datalist']);

    Route::get('/report_center', [ReportController::class, 'report_center']);
    Route::get('/reportList', [ReportController::class, 'reportList']);

    Route::get('location_map_new/{type}', [LocationMapController::class, 'location_map_new']);
    Route::post('/getMarkerData', [LocationMapController::class, 'getMarkerData']);

    // Add Area Routes
    Route::post('/getGeoFenceResults', [LocationMapController::class, 'getGeoFenceResults']);
    Route::post('/getGeoFenceLatLong', [LocationMapController::class, 'getGeoFenceLatLong']);

    // Area List Routes
    Route::get('/areaList', [LocationMapController::class, 'areaList']);
    Route::post('/getGeoFenceAreasList', [LocationMapController::class, 'getGeoFenceAreasList']);
    Route::post('/getGeoFenceLatLongAreas', [LocationMapController::class, 'getGeoFenceLatLongAreas']);

    // Area Detail Routes
    Route::post('/editAreaDetail', [LocationMapController::class, 'editAreaDetail']);
    Route::post('/updateAreaRecord', [LocationMapController::class, 'updateAreaRecord']);
});
