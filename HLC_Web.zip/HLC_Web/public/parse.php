<html>
<form method="post" action="parse.php">
    <br/>
    <label>Enter String : </label>
    <input type="text" style="width:500px" name="vardata" />
    <button>Submit</button>

</form>
</html>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['vardata'] != '')
{

    echo "INPUT : " ; echo $str = $_POST['vardata'];
    //echo $str= "AQEBAU0A2tmIBAAAAQAAAAAAagAAAAAAAABqAAAAQGM2A4CkDmMAAAAAAgIUroc/AQEIAO0RaoZUKUlAylLr/UZ7IECaGUpDAAAAPwAAqEEAAKBBAA==";
    $data = base64_decode($str);echo "<br/>";echo "<br/>";
    echo "OUTPUT : " ; print_r(unpack("H*",$data));echo "<br/><br/>";

    $hex_ary = array();
    foreach (str_split($data) as $chr) {
        $hex_ary[] = sprintf("%02X", ord($chr));
    }
    echo "OUTPUT ARR : " ; print_r($hex_ary);echo "<br/><br/>";
    $type = hexdec(arrSlice($hex_ary,0,1));
    echo "struct_type : " ; echo $struct_type = struct_type(hexdec(arrSlice($hex_ary,0,1)));echo "<br/>";
    echo "struct_version : " ; echo $struct_version = hexdec(arrSlice($hex_ary,1,1));echo "<br/>";
    echo "data_block : " ; echo $data_block = hexdec(arrSlice($hex_ary,2,1));echo "<br/>";
    echo "last_data_block : " ; echo $last_data_block = hexdec(arrSlice($hex_ary,3,1));echo "<br/>";
    echo "data_length : " ; echo $data_length = hexdec(reverseBits(arrSlice($hex_ary,4,2),2));echo "<br/>";
    echo "crc : " ; echo $crc = hexdec(reverseBits(arrSlice($hex_ary,6,2),2));echo "<br/>";
    if($type == 1)
    {
        weightStampFunc($hex_ary);
    }
    if($type == 2)
    {
        jobFunc($hex_ary);
    }
    if($type == 3)
    {
        headlineFunc($hex_ary);
    }

}

function weightStampFunc($hex_ary)
{
    echo "stamp_no : " ; echo $stamp_no = hexdec(reverseBits(arrSlice($hex_ary,8,4),2));echo "<br/>";
    echo "seq_job_no : " ; echo $seq_stamp_no = hexdec(reverseBits(arrSlice($hex_ary,12,4),2));echo "<br/>";
    echo "load_to : " ; echo $load_to = hexdec(reverseBits(arrSlice($hex_ary,16,2),2));echo "<br/>";
    echo "loaded_fleet : " ; echo $loaded_fleet =  loaded_fleet($load_to);echo "<br/>";

    echo "gross_value : " ; echo $gross_value = hexdec(reverseBits(arrSlice($hex_ary,18,4),2));echo "<br/>";
    echo "tata_value : " ;echo $tata_value = hexdec(reverseBits(arrSlice($hex_ary,22,4),2));echo "<br/>";
    echo "netto_value : " ;echo $netto_value = hexdec(reverseBits(arrSlice($hex_ary,26,4),2));echo "<br/>";
    $sec = msToSeconds(hexdec(reverseBits(arrSlice($hex_ary,30,4),2)));
    echo "Time : " ;echo $time = date('H:i:s',$sec);echo "<br/>";
    $timestamp = hexdec(reverseBits(arrSlice($hex_ary,34,4),2));
    echo "Date : " ;echo $date = date('Y-m-d',$timestamp);echo "<br/>";
    echo "signature : " ; echo $signature = hexdec(reverseBits(arrSlice($hex_ary,38,4),2));echo "<br/>";
    echo "unit : " ; echo $unit = weight_unit(hexdec(arrSlice($hex_ary,42,1)));echo "<br/>";
    echo "decimal_place : " ; echo $decimal_place = hexdec(arrSlice($hex_ary,43,1));echo "<br/>";

    echo "float : " ;echo $float = hex32float(reverseBits(arrSlice($hex_ary,44,4),2));echo "<br/>";
    echo "weight_valid : " ; echo $weight_valid = hexdec(arrSlice($hex_ary,48,1));echo "<br/>";
    echo "position_fix: " ; echo $position = hexdec(arrSlice($hex_ary,49,1));echo "<br/>";
    echo "position_satelite_count : " ;echo $position_satelite = hexdec(reverseBits(arrSlice($hex_ary,51,4),2));echo "<br/>";

    echo "latitude : " ;echo $latitude = hex64float(reverseBits(arrSlice($hex_ary,52,8),2));echo "<br/>";

    echo "longitude : " ;echo $long = hex64float(reverseBits(arrSlice($hex_ary,60,8),2));
    echo "<br/>";
    echo "altitude : " ;echo $altitude = hex32float(reverseBits(arrSlice($hex_ary,68,4),2));echo "<br/>";
    echo "Dillution : " ;echo $dillution = hex32float(reverseBits(arrSlice($hex_ary,72,4),2));echo "<br/>";
    echo "Oil Temperature1 : " ;echo $oil_temp = hex32float(reverseBits(arrSlice($hex_ary,76,4),2));echo "<br/>";
    echo "Oil Temperature2 : " ;echo $oil_temp2 = hex32float(reverseBits(arrSlice($hex_ary,80,4),2));echo "<br/>";
    echo "stamp state : " ;echo $stamp_state = stamp_state(hexdec(arrSlice($hex_ary,84,1)));echo "<br/>";
}

function jobFunc($hex_ary)
{
    $sec = hexdec(reverseBits(arrSlice($hex_ary,8,4),2));
    echo "Create time : " ;echo $create_time = date('Y-m-d H:i:s',$sec);echo "<br/>";
    echo "Start time : " ; echo $start_time = date('Y-m-d H:i:s',hexdec(reverseBits(arrSlice($hex_ary,12,4),2)));echo "<br/>";
    echo "End time : " ; echo $end_time = date('Y-m-d H:i:s',hexdec(reverseBits(arrSlice($hex_ary,16,4),2)));echo "<br/>";

    echo "Job id : " ; echo $job_id = hexdec(reverseBits(arrSlice($hex_ary,20,4),2));echo "<br/>";
    echo "First stamp id : " ; echo $first_stamp_id = hexdec(reverseBits(arrSlice($hex_ary,24,4),2));echo "<br/>";
    echo "Last stamp id : " ; echo $last_stamp_id = hexdec(reverseBits(arrSlice($hex_ary,28,4),2));echo "<br/>";

    echo "Job state : " ; echo $job_state = job_state(hexdec(reverseBits(arrSlice($hex_ary,32,2),2)));echo "<br/>";
    echo "Target weight : " ; echo $target_weight = hex32float(reverseBits(arrSlice($hex_ary,34,4),2));echo "<br/>";
    echo "Total Loaded weight : " ; echo $total_weight = hex32float(reverseBits(arrSlice($hex_ary,38,4),2));echo "<br/>";
    echo "Loaded weight Truck : " ; echo $loaded_weight = hex32float(reverseBits(arrSlice($hex_ary,42,4),2));echo "<br/>";

    echo "Loaded weight Trailer1 : " ; echo $target_weight = hex32float(reverseBits(arrSlice($hex_ary,46,4),2));echo "<br/>";
    echo "Loaded weight Trailer2 : " ; echo $total_weight = hex32float(reverseBits(arrSlice($hex_ary,50,4),2));echo "<br/>";
    echo "Loaded weight Trailer3 : " ; echo $loaded_weight = hex32float(reverseBits(arrSlice($hex_ary,54,4),2));echo "<br/>";
    echo "No of Trailer : " ; echo $no_trailer = hexdec(reverseBits(arrSlice($hex_ary,58,4),2));echo "<br/>";
    echo "No of bucket lifts : " ; echo $no_bucket_lifts = hexdec(reverseBits(arrSlice($hex_ary,60,2),2));echo "<br/>";
    echo "No of Texts : " ; echo $no_texts = hexdec(reverseBits(arrSlice($hex_ary,62,1),2));echo "<br/>";

    $text_arr = array_slice($hex_ary,63);
    echo "Text length : " ; echo $text_length = hexdec(reverseBits(arrSlice($text_arr,0,1),2));echo "<br/>";
    echo "Byte per character : " ; echo $byte_char = hexdec(reverseBits(arrSlice($text_arr,1,1),2));echo "<br/>";
    echo "Text : " ; echo $text = hex2text($text_arr);//hexdec(reverseBits(arrSlice($text_arr,2,10),2));echo "<br/>";
}

function headlineFunc($hex_ary)
{
    echo "No of Texts : " ; echo $no_texts = hexdec(reverseBits(arrSlice($hex_ary,8,1),2));echo "<br/>";
    $text_arr = array_slice($hex_ary,9);
    echo "Text length : " ; echo $text_length = hexdec(reverseBits(arrSlice($text_arr,0,1),2));echo "<br/>";
    echo "Byte per character : " ; echo $byte_char = hexdec(reverseBits(arrSlice($text_arr,1,1),2));echo "<br/>";
    echo "Text : " ; echo $text = hex2text($text_arr);
}
function hex2text($strHex)
{
    $length = count($strHex);
    $currentIndex = 0;
    $words = array();
    while ($length > $currentIndex) {
        $wordLength = hexdec($strHex[$currentIndex]);
        $wordType = hexdec($strHex[$currentIndex+1]);
        $word = iconv(($wordType == 2 ? 'UTF-16BE' : 'UTF-8'), 'UTF-8', hex2bin(arrSlice($strHex,$currentIndex+2,$wordLength)));
        $currentIndex = $currentIndex+2+$wordLength;
        $words[] = $word;
    }
    return implode(', ',$words);
}

function arrSlice($arr,$start,$len)
{
    $arr_slice = array_slice($arr,$start,$len);
    return implode('',$arr_slice);
}

function reverseBits($block, $bits)
{
    if ($block) {
        $output = str_split($block, $bits);
        $temp = array_reverse($output, true);
        return implode('', $temp);
    } else {
        return '';
    }
}

function struct_type($type)
{
    switch ($type) {
      case 1:
        echo "weighting-stamp";
        break;
      case 2:
        echo "job";
        break;
      case 3:
        echo "headline-list";
        break;
      default:
        echo "";
    }
}

function loaded_fleet($load_to)
{
    switch ($load_to) {
      case 0:
        echo "Truck";
        break;
      case 1:
        echo "Trailer1";
        break;
      case 2:
        echo "Trailer2";
        break;
      case 3:
        echo "Trailer3";
        break;
      default:
        echo "";
    }
}

function weight_unit($unit)
{
    switch ($unit) {
      case 0:
        echo "gramm";
        break;
      case 1:
        echo "kilo gramm";
        break;
      case 2:
        echo "tons";
        break;
      default:
        echo "";
    }
}

function stamp_state($state)
{
    switch ($state) {
        case 0:
            echo "job";
            break;
        case 1:
            echo "tip_off_pile";
            break;
        case 2:
            echo "tip_off_truck";
            break;
        case 3:
            echo "zero";
            break;
        case 4:
            echo "calibration";
            break;
        case 5:
            echo "deleted";
            break;
        default:
            echo "";
    }
}

function msToSeconds($ms)
{
    return $ms/1000;
}

function hex32float($strHex) {
    $hex = sscanf($strHex, "%02x%02x%02x%02x%02x%02x%02x%02x");
    $bin = implode('', array_map('chr', $hex));
    $array = unpack("Gnum", $bin);
    return $array['num'];
}

function hex64float($strHex) {
    $hex = sscanf($strHex, "%02x%02x%02x%02x%02x%02x%02x%02x");
    $hex = array_reverse($hex);
    $bin = implode('', array_map('chr', $hex));
    $array = unpack("dnum", $bin);
    return $array['num'];
}

function job_state($jstate)
{
    switch ($jstate) {
        case 0:
            echo "open";
            break;
        case 1:
            echo "in_work";
            break;
        case 2:
            echo "done";
            break;
        case 3:
            echo "template";
            break;
        case 4:
            echo "deleted";
            break;
        default:
            echo "";
    }
}

?>
