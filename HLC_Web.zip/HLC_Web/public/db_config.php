<?php

$hostname = '10.200.15.11:3306';
$username = 'hlcweb';
$password = 'E5KfM)3536*b3alrBsQp';
$database = 'hlcweb';

$now = date("Y-m-d H:i:s");
echo $now . " started successfully<br>";

try {
    $conn = new mysqli("p:" . $hostname, $username, $password, $database);

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        die;
    }
} catch (Exception $e) {
    echo 'Message: ' . $e->getMessage();
}