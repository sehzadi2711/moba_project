// password i button js
$(document).ready(function () {
    $("#show_hide_password a").on("click", function (event) {
        event.preventDefault();
        if ($("#show_hide_password input").attr("type") == "text") {
            $("#show_hide_password input").attr("type", "password");
            $("#show_hide_password i").addClass("fa-eye-slash");
            $("#show_hide_password i").removeClass("fa-eye");
        } else if ($("#show_hide_password input").attr("type") == "password") {
            $("#show_hide_password input").attr("type", "text");
            $("#show_hide_password i").removeClass("fa-eye-slash");
            $("#show_hide_password i").addClass("fa-eye");
        }
    });
});

const placeholder = document.querySelectorAll(".placeholder");
const input = document.querySelectorAll(".input");

console.log("Placeholder " + placeholder.length);
console.log("Input " + input.length);

$(".placeholder").click(function () {
    console.log("Input " + $(this).prev().val());
});

$(".input").on("blur", function () {
    var pl = $(this).next();
    if ($(this).val() != "") {
        pl.css("top", "-12px");
        pl.css("fontSize", ".8rem");
    } else {
        pl.css("top", "");
        pl.css("fontSize", "");
    }
    // console.log("Input " + $(this).val());
    // console.log("Pl " + $(this).next().html());
});
// sidebar
function toggleSidebar(ref) {
    document.getElementById("sidebar").classList.toggle("active");
}
$(".nav a").on("click", function () {
    $(".nav").find(".active").removeClass("active");
    $(this).parent().addClass("active");
    $(".dropdown").removeClass("active");
});
$(".dropdown").click(function (e) {
    $(".dropdown-menu-inner").toggle("slow");
    $(".dropdown").toggleClass("show");
    $(".dropdown").toggleClass("hide");

    $(".dropdown").find(".active").removeClass("active");
    $(this).parent().addClass("active");
    $(".dropdown-menu-inner").removeClass("active");
});
