       
<div class="area_sec_edit" style="display: none">
    
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 ">
                <div class="container-fluid  mb-4">
                    <div class="row g-4 pt-2">
                        <div class="col-sm-12 col-xl-7 col-lg-7 text-white">
                            <div class="row title-border mb-2" id="polyLinecolor" style="border-color: #ffcc00;">
            
                                <div  class="col-lg-11 pl-0">
                                    <h3 class="ml-2 mb-0" id="areaName">area</h3>
                                </div>
                                <div class="col-lg-6 p-0 pl-3"> 
                                    <div class="row w-100 p-0">
                                        <div class="col-lg-4 px-1 py-0">
                                            <div
                                                class="card m-0 inner-cardd-sidebar border-unset">
                                                <p class="mb-0">TODAY</p>
                                                <div
                                                    class="d-flex justify-content-between align-items-center">
                                                    <span class="icon-glyph_weight"></span><span id="load_today_area">0</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 px-1 py-0">
                                            <div
                                                class="card m-0 inner-cardd-sidebar border-unset">
                                                <p class="mb-0">WEEK</p>
                                                <div
                                                    class="d-flex justify-content-between align-items-center">
                                                    <span class="icon-glyph_weight"></span><span id="load_week_area">0</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 px-1 py-0">
                                            <div
                                                class="card m-0 inner-cardd-sidebar border-unset">
                                                <p class="mb-0">Month</p>
                                                <div
                                                    class="d-flex justify-content-between align-items-center">
                                                    <span class="icon-glyph_weight"></span><span id="load_month_area">0</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 p-0"> 
                                    <div class="progress_sec"> <i class="nav-icon icon-glyph_wheel_loader text-white mr-2"
                                        style="font-size: 20px;"></i><span>HLC 4000-MWeimer</span>
                                        <div class="progress w-100" style="background: #02e39499;">
                                            <div class="progress-bar" role="progressbar" style="width: 25%;background-color: #02e394;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>
                                        </div>
                                
                                        <span>25t</span>
                                    </div>
                                    <div class="progress_sec"> <i class="nav-icon icon-glyph_wheel_loader text-white mr-2"
                                        style="font-size: 20px;"></i><span>HLC 4000-Demo-Loader</span>
                                        <div class="progress w-100" style="background: #02e39499;">
                                            <div class="progress-bar" role="progressbar" style="width: 80%;background-color: #02e394;" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                                        </div>
                            
                                        <span>80t</span>
                                    </div>
                                    <div class="progress_sec"> <i class="nav-icon icon-glyph_wheel_loader text-white mr-2"
                                        style="font-size: 20px;"></i><span>HLC 4000-MSchdfer</span>
                                        <div class="progress w-100" style="background: #02e39499;">
                                            <div class="progress-bar" role="progressbar" style="width: 10%;background-color: #02e394;" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100">10%</div>
                                        </div>
                            
                                        <span>10t</span>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-0">
                                <div class="card-header info_header">
                                    <div
                                        class="d-flex align-items-center justify-content-start">
                                    </div>
                                </div>
                                <div class="card-body p-0">
                                    <div class="my_inner_card" style="height:68vh;">
                                        <button type="button" class="edit_button btn btn-warning" onclick="LoadGeoMap1();addPointfrm_Combo($('#area_id').val());"><i
                                            class="nav-icon icon-glyph_edit text-dark"
                                            style="font-size: 20px;"></i></button>
                                        <div id="areaDetailMap" style="height: 68vh;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xl-5 col-lg-5 text-white p-1 border-left">
                            <div class="d-flex" style="text-align:end;justify-content: end; height:20px;">
                                <button class="btn p-0 area_sec_edit_close" onclick="areaDataList();loadGeofencesDetail();
                                    LoadAreaListMap();"> 
                                    <span aria-hidden="true" style="font-size: 12px; font-weight:100; position:absolute;top:10px;font-family:FontAwesome;">x</span>
                                </button>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                 <h3 class="title">Properties</h3>
                                 <form id="update_area_form" method="post" >
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" id="area_id" name="areaId">
                                    <input type="hidden" id="area_lat" name="area_lat">
                                    <input type="hidden" id="area_lng" name="area_lng">
                                    <div class="row">
                                        <div class="col-lg-5">
                                            <input type="text" class="coloris" name="color" id="color_name" value="" onchange="Color(this.value)">
                                            <input type="hidden" id="color_name_val" name="color_name_val" value="" >
                                            <span class="icon-glyph_ctrl_down down_icon"
                                        style="font-size: 1rem; color: #fff;"></span>
                                        </div>
                                        <div class="offset-1 col-lg-5">
                                            <div class="checkbox-wrapper-42" style="text-align:end;">
                                                <input id="statusActive" name="status" type="checkbox" />
                                                <label class="cbx" for="statusActive"></label>
                                                <label class="lbl" for="statusActive">active</label>
                                              </div>
                                              
                                            
                                        </div>
                                        <div class="col-lg-11 mt-2">
                                            <div class="form-group">
                                                <input type="text" id="polyNameadd" name="polyname" class="form-control" value="" placeholder="POI NAME" required>
                                            </div>
                                        </div>
                                    </div>
                                        <div class="row mt-5">
                                        <div class="col-lg-11">
                                            <div class="checkbox-wrapper-42">
                                                <input  id="emailAlert" name="email_alert" type="checkbox" onclick="emailALert()" />
                                                <label class="cbx" for="emailAlert"></label>
                                                <label class="lbl" for="emailAlert">E-Mail Notification Active</label>
                                              </div>
                                            
                                        </div>
                                        <div class="col-lg-11">
                                            <div class="form-group">
                                                <input  type="text" name="area_email" id="area_email" value="" class="form-control" placeholder="ENTER  E-MAIL ADDRESS">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 d-flex align-center">
                                            <span class="p-2 "><i
                                                class="nav-icon icon-glyph_date text-white"
                                                style="font-size: 20px;"></i></span>
                                                <div class="input-container" id="notifyDiv">
                                                    <select id="notify_duration" name="notify_duration" class="select_2 js-states input form-control w-100 border-unset -select">
                                                        <option value="daily">Daily</option>
                                                        <option value="weekly">Weekly</option>
                                                        <option value="monthly">Monthly</option>
                                                    </select>
                                                </div>
                                       
                                        </div>
                                        <div class="col-lg-5 d-flex align-center">
                                            <span class="p-2 "><i
                                                class="nav-icon  icon-glyph_notify text-white"
                                                style="font-size: 20px;"></i></span>
                                                <div class="input-container form-group">
                                                    <div class="input-group date" id="timePicker">
                                                      <input type="text" id="notify_time" name="notify_time" class="form-control timePicker">
                                                      <span class="input-group-addon"><i class="fa fa-clock-o" aria-hidden="true"></i></span>
                                                    </div>
                                                  </div>
                                                
                                        </div>
                                        <div class="col-lg-12">
                                            <button type="button" class="btn btn-setting" data-toggle="modal" data-target="#poly_main_more">More<span class="icon-glyph_ctrl_right"
                                            style="font-size: 1rem; color: #fff;"></span></button>
                                        </div>
                                        <div class="col-lg-3 offset-9">      
                                            <button type="button" id="edit-area-btn" class="btn btn-setting" data-toggle="modal" data-target="#poly_main_edit_area"><span class="icon-glyph_save"
                                            style="font-size: 1rem; color: #fff;" ></span>save</button>
                                        </div>
                                    </div>
                                 </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="poly_main_edit_area" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-body">
                    <div class="row align-items-center">
                        <div class="col-md-3" style="text-align:center;">
                            <span class="icon-glyph_save save-icon" style="font-size: 80px; color: #fff;"></span>
                        </div>
                        <div class="col-md-9">
                            <h1 class="modal-title">Save Changes</h1>
                            <p>Are You Sure, You want To Save Your Changes?</p>
                        </div>
                    </div>
                    <div class="modal-footer p-0">
                        <button type="button" onclick="updateAreaRecord()" class="btn btn-warning d-flex align-item-center">
                            <span class="icon-glyph_save mr-2" style="font-size: 20px;"></span>Save
                        </button>
                        <button type="button" class="btn btn-succsess d-flex align-item-center" data-dismiss="modal">
                            <span class="icon-glyph_delete mr-2" aria-hidden="true" style="font-size: 20px;"></span>Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
   
    <script>
        
        function emailALert(){
            if($('input[name="email_alert"]').is(':checked'))
            {
                document.getElementById("area_email").disabled = false;
                document.getElementById("notify_duration").disabled = false;
                document.getElementById("notify_time").disabled = false;
            }else{
                document.getElementById("area_email").disabled = true;
                document.getElementById("notify_duration").disabled = true;
                document.getElementById("notify_time").disabled = true;
            }
        }
        
        function editAreaRecord(areaId) {
            $(".area_sec_list").hide();
            $(".area_sec").hide();
            $(".area_sec_edit").show();  
            $.ajax({
                url: "<?php echo e(url('editAreaDetail')); ?>",
                type: "post",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    areaId: areaId,
                },
                success: function (data) {
                    LoadAreaDetailMap();                    
                    var returnVal = jQuery.parseJSON(data);
                    $('.edit_button').hide();
                    $("#areaName").text('');
                    $("#polyNameadd").val('');
                    $("#color_name").val('');
                    $("#area_email").val('');
                    $("#load_today_area").val('0');
                    $("#load_week_area").val('0');
                    $("#load_month_area").val('0');
                    $("#polyLinecolor").css("border-color",'');
                    $("#aLinecolor").css("border-color",'');
                    $("#emailAlert").prop("checked", false);
                    $("#statusActive").prop("checked", false);
                    $("#area_lat").val('0');
                    $("#area_lng").val('0');
                    $("#area_id").val('0');
                    //$("#emailAlert").prop("checked", true);
                    //$("#statusActive").prop("checked", true);
                    if (returnVal.aaData) {
                        if (returnVal.aaData.areas_id == areaId) {
                            $("#area_id").val(returnVal.aaData.areaId);
                            if(returnVal.aaData.cost){
                                $("#load_today_area").text(returnVal.aaData.cost);
                            }
                            if(returnVal.aaData.week_cost){
                                $("#load_week_area").text(returnVal.aaData.week_cost);
                            }
                            if(returnVal.aaData.month_cost){
                                $("#load_month_area").text(returnVal.aaData.month_cost);
                            }
                            $("#areaName").text(returnVal.aaData.polyname);
                            $("#polyNameadd").val(returnVal.aaData.polyname);
                            $("#color_name").val(returnVal.aaData.color);
                            $("#area_email").val(returnVal.aaData.area_email);
                            if(returnVal.aaData.notify_duration){
                                $("#notify_duration").val(returnVal.aaData.notify_duration).change();
                            }
                            if(returnVal.aaData.notify_time){
                                $("#notify_time").val(returnVal.aaData.notify_time).change();
                            }else{
                                $("#notify_time").val('time');
                            }
                            
                            if(returnVal.aaData.color){
                                $("#polyLinecolor").css("border-color",returnVal.aaData.color);
                                $("#aLinecolor").css("border-color",returnVal.aaData.color);
                                $(".clr-field").attr('style',  'color:'+returnVal.aaData.color);
                                $("#color_name_val").val(returnVal.aaData.color);
                            }
                            if(returnVal.aaData.email_alert == 1){
                                $("#emailAlert").prop("checked", true);
                                document.getElementById("area_email").disabled = false;
                                document.getElementById("notify_duration").disabled = false;
                                document.getElementById("notify_time").disabled = false;
                            }else{
                                document.getElementById("area_email").disabled = true;
                                document.getElementById("notify_duration").disabled = true;
                                document.getElementById("notify_time").disabled = true;
                            }
                            if(returnVal.aaData.status == 1){
                                $("#statusActive").prop("checked", true);
                            }   
                            $("#area_lat").val(returnVal.aaData.lat);
                            $("#area_lng").val(returnVal.aaData.lng);                               
                                
                            $('.edit_button').show();     
                            if(returnVal.aaData.lat == null) 
                            {
                                console.log('in');
                                $('.my_inner_card .edit_button').attr('onclick', '');
                                $('.my_inner_card .edit_button').attr('onclick', 'LoadGeoMap1();addPointfrm_Combo("' + returnVal.aaData.areaId + '")');
                            }else{
                                $('.my_inner_card .edit_button').attr('onclick', '');
                                $('.my_inner_card .edit_button').attr('onclick', 'LoadGeoMap1();addPointfrm_Combo("' + returnVal.aaData.areaId + '")');
                            }                 
                        }
                    }
                    loadDetailGeofences();
                }
            });  
        }
        function updateAreaRecord() {

            var area_id = $('#area_id').val();
            var color_name = $('#color_name').val();
            var polyNameadd = $('#polyNameadd').val();
            var area_email = $('#area_email').val();
            var emailAlert = $('#emailAlert').val();
            var statusActive = $('#statusActive').val();
            var notify_duration = $('#notify_duration').val();
            var notify_time = $('#notify_time').val();

            if (!polyNameadd) {
                toastr.error("Please Add Area Name", "Error");
                return false;
            }
            if($("#emailAlert").is(":checked")){
                if (!area_email) {
                    toastr.error("Please Enter Email", "Error");
                    return false;
                }
            }
            var formData = new FormData($('#update_area_form')[0]);
            
            $("#edit-area-btn").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('updateAreaRecord')); ?>",
                data: formData,
                processData: false,
                contentType: false,
                success: function (data) {
                    $('#poly_main_edit_area').modal('hide');
                    $("#edit-area-btn").prop("disabled", false);
                    var returnVal = jQuery.parseJSON(data);
                    if (returnVal.responseCode == 200) {
                        toastr.success(returnVal.responseMessage, returnVal.responseStatus);
                        //editAreaRecord(area_id);
                        areaDataList();
                    } else {
                        toastr.error(returnVal.responseMessage, returnVal.responseStatus);
                    }
                }
            });

        }
        function LoadAreaDetailMap() {
            var mapOptions = {
                zoom: 5,
                center: new google.maps.LatLng(50.41149643, 8.06916572),
                mapTypeId: google.maps.MapTypeId.HYBRID,
                mapTypeControlOptions: {
                    style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                    position: google.maps.ControlPosition.TOP_CENTER
                },
                panControl: true,
                panControlOptions: {
                    position: google.maps.ControlPosition.RIGHT_TOP
                },
                zoomControl: true,
                zoomControlOptions: {
                    style: google.maps.ZoomControlStyle.SMALL,
                    position: google.maps.ControlPosition.RIGHT_BOTTOM
                },
                fullscreenControl: true,
                fullscreenControlOptions: {
                    position: google.maps.ControlPosition.RIGHT_BOTTOM,
                }
            }
            map_geo_detail = new google.maps.Map(document.getElementById("areaDetailMap"), mapOptions);

            polyImageDetail = {
                url: '<?php echo e(url("images/beachflag.png")); ?>',
                size: new google.maps.Size(20, 32),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(0, 32)
            };

            poly = new google.maps.Polygon({
                strokeWeight: 2,
                //fillOpacity: 0.0,
                strokeOpacity: 0.6,
                clickable: true,
                fillColor: '#ff0000'
            });

            poly.setMap(map_geo_detail);
            poly.setPaths(new google.maps.MVCArray([path]));

            refreshAreaDetailList();

        }
        function refreshAreaDetailList() {
            clearMarkerAreaDetailList();

            ajax_1 =   $.post(sUrl_list, {
                "_token": "<?php echo e(csrf_token()); ?>",
                "cmd": "refreshArea"
            },
            function (data) {
                clearPolyOverlaysAreaDetailList();
                if (data.plyId != null) {
                    for (k = 0; k < data.plyId.length; k++) {
                        polyId = data.plyId[k];
                        var bounds = new google.maps.LatLngBounds();
                        var pathArr = [];

                        if(data.plyLat[polyId].length > 0)
                        {
                            for (j = 0; j < data.plyLat[polyId].length; j++) {
                                pathArr.push(new google.maps.LatLng(data.plyLat[polyId][j], data.plyLng[polyId][j]));
                            }

                            for (i = 0; i < pathArr.length; i++) {
                                bounds.extend(pathArr[i]);
                            }
                            polygonsAreaDetail[polyId] = bounds.getCenter();
                            creatAreaRefreshAreaDetail(polyId, bounds.getCenter(), pathArr, data.plyName[polyId], data.plyColor[polyId], k);
                        }
                        
                        
                    }

                    focusAreaGeofence();
                }

            }, 'json');
        }
        function clearPolyOverlaysAreaDetailList() {

            if (polyVarr) {
                for (i in polyVarr) {
                    polyVarr[i].setMap(null);
                }
            }
            polyVarr = [];
        }
        function creatAreaRefreshAreaDetail(pid, center, pathArr, name, color, kk) {

            var marker_options = {
                position: center,
                map: map_geo_detail,
                title: name,
                icon: polyImageDetail,
            };

            //create marker
            var new_marker = new google.maps.Marker(marker_options);

            labelArr.push(new_marker);

            var polyV = new google.maps.Polygon({
                paths: pathArr,
                strokeWeight: 2,
                strokeOpacity: 0.6,
                fillColor: color
            });

            polyV.setMap(map_geo_detail);
            polyVarr.push(polyV);

            google.maps.event.addListener(new_marker, "click", function (event) {
                
                editAreaRecord(pid);
            });

        }
        function clearMarkerAreaDetailList() {
            if (labelArr) {
                for (i in labelArr) {
                    labelArr[i].setMap(null);
                }

                for (i in marker_htmlmap) {
                    marker_htmlmap[i].setMap(null);
                }

            }
        }

        function loadDetailGeofences() {

            //var data = $("#site_id").select2('data');
            //var site = data[0].id;

            var site = 1;
            var data = 1;
            
            $.post(sUrl_list, {
                "_token": "<?php echo e(csrf_token()); ?>",
                "cmd": "site_areas",
                "site": site
            },
            function (data) {
                //$("#areas").html('');
                //for (v = 0; v < data.coords.length; v++) {
                    //$("#areas").append('<option value="' + data.coords[v].id + '">' + data.coords[v].polyname + '</option>');
                //}

                //focusAreaGeofence();

            },
            'json');
        }

        function focusAreaGeofence() {

            var selGeo = $("#area_id").val();
            console.log('selGeo', selGeo);
            if (selGeo > 0) {
                map_geo_detail.panTo(polygonsAreaDetail[selGeo], 1000)
                map_geo_detail.setZoom(12);
            }

        }

        function Color(txt_color) {
            var n_match = ntc.name(txt_color);
            n_rgb = n_match[0]; // RGB value of closest match
            n_name = n_match[1]; // Text string: Color name
            n_exactmatch = n_match[2]; // True if exact color match
            //alert(txt_color);
            $("#color_name").val(n_match[1]);
            $("#color_name_val").val(txt_color);
            $(".clr-field").attr('style',  'color:'+txt_color);
        }
    </script>
    <?php /**PATH D:\wamp\www\HLC_Web\resources\views/area_detail.blade.php ENDPATH**/ ?>