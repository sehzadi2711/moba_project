
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" >

<div class="content-wrapper">
    <main class="content p-0">
        <div class="container-fluid pt-4">
            <div class="row">
                <div class="col-12 col-sm-12">
                    <div class="card card-tabs">
                        <div class="card-header p-0">
                            <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                                <li class="nav-item mb-0">
                                    <a class="nav-link mb-0 <?php echo e(((Request::segment(1) == 'location_map_new') && (Request::segment(2) == 'machines'))  ? 'active' : ''); ?>" id="custom-tabs-one-home-tab" data-toggle="pill" href="#machines" role="tab" onclick="getMapMarkers();" aria-controls="machines" aria-selected="false">
                                        <span class="icon-glyph_wheel_loader" style="font-size: 30px; color: #3c3c3b;"></span>
                                        Machines
                                    </a>
                                </li>
                                <li class="nav-item mb-0">
                                    <a class="nav-link mb-0 <?php echo e(((Request::segment(1) == 'location_map_new') && (Request::segment(2) == 'poi'))  ? 'active' : ''); ?>" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#poi-tab-list" role="tab" onclick="loadGeofencesDetail();LoadAreaListMap();areaDataList();" aria-controls="poi-tab-list" aria-selected="true"> <span class="icon-glyph_position" style="font-size: 30px; color: #3c3c3b;"></span>
                                        POI</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body p-0">
                            <div class="tab-content" id="custom-tabs-one-tabContent">
                                <div class="tab-pane fade show <?php echo e(($activeVar == 'machineActive') ? 'active' : ''); ?>" id="machines" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12">
                                            <div class="container-fluid px-4">
                                                <div class="row g-4">
                                                    <div class="col-sm-12 col-xl-7 col-lg-7 text-white p-1">
                                                        <div class="card mb-0">
                                                            <div class="card-header info_header">
                                                                <div class="d-flex align-items-center justify-content-start">
                                                                </div>
                                                            </div>
                                                            <div class="card-body p-0">
                                                                <div class="my_inner_card">
                                                                    <div id="map-canvas" style="height: 80vh;"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-12 col-xl-5 col-lg-5 text-white p-1">
                                                        <div class="card">
                                                            <div class="mt-2">
                                                                <div
                                                                    class="mb-0 form-group w-100 d-flex align-items-center bg-light">
                                                                    <span class="px-2 bg-light"><i
                                                                            class="nav-icon icon-glyph_wheel_loader text-white"
                                                                            style="font-size: 30px;"></i></span>
                                                                    <div class="input-container">
                                                                        <select
                                                                            class="select_2 js-states input form-control w-100 border-unset bg-light-select"
                                                                            id="machineValue" onchange="machineData(this)">
                                                                            <?php
                                                                                foreach ($machines as $machine) {
                                                                                echo "<option value='" . $machine->machine . "' mdate='" . $machine->lat_lng_date . "' 'selected'>" . $machine->machine ."</option>";
                                                                            }
                                                                            ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="card-body p-0">
                                                                <div class="d-flex align-items-center py-2 gap-2 mt-3">
                                                                    <span class="icon-glyph_date"
                                                                        style="font-size:20px; color: #fff;"></span><span
                                                                        id="create_date"></span>
                                                                </div>
                                                                <div class="mt-1">
                                                                    <fieldset>
                                                                        <legend>WEIGHT (t)</legend>
                                                                        <div class="row">
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">TODAY</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_weight"></span><span
                                                                                            id="load_today">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">WEEK</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_weight"></span><span
                                                                                            id="load_week">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">Month</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_weight"></span><span
                                                                                            id="load_month">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </fieldset>
                                                                </div>
                                                                <!--<div>
                                                                    <fieldset>
                                                                        <legend>DISTANCE (km)</legend>
                                                                        <div class="row">
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">TODAY</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_distance"></span><span
                                                                                            id="distance_today">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">WEEK</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_distance"></span><span
                                                                                            id="distance_week">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">Month</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_distance"></span><span
                                                                                            id="distance_month">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </fieldset>
                                                                </div>-->
                                                                <div class="mt-3">
                                                                    <fieldset>
                                                                        <legend>JOBS</legend>
                                                                        <div class="row">
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">TODAY</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_diagnosis"></span><span
                                                                                            id="today_jobs">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">WEEK</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_diagnosis"></span><span
                                                                                            id="week_jobs">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4 px-2 py-0">
                                                                                <div
                                                                                    class="card m-0 inner-cardd-sidebar border-unset">
                                                                                    <p class="mb-0">Month</p>
                                                                                    <div
                                                                                        class="d-flex justify-content-between align-items-center">
                                                                                        <span
                                                                                            class="icon-glyph_diagnosis"></span><span
                                                                                            id="month_jobs">0</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </fieldset>
                                                                </div>

                                                                <div class="mt-3">
                                                                    <div class="mt-2 gap-2 d-flex align-items-center">
                                                                        <span class="icon-glyph_position"
                                                                            style="font-size: 20px; color: #fff;"></span>
                                                                        POIs
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-sm-12 col-lg-12"
                                                                            id="poiDivItems">

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade show <?php echo e(($activeVar == 'poiActive') ? 'active' : ''); ?>" id="poi-tab-list" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                                    <?php echo $__env->make('area_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('area_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('add_area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
    <script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDXjauhT7MiNATaUUBR9cKx4APtpQ44He4"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/color.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/ntc.js')); ?>"></script>

	<script type="text/javascript">
    var map;
    var markers = [];
    var unit_id;
    var position = [];
    var delay = 10;
    var infWindows = [];
    var zoomlevel = 15;
    var mapcenter;
    var pin;
    var infWindow = null;
    var markerid = null;
    var polyImage = null;
    var polyImageList = null;  
    var polyImageDetail = null;  
    var polyVarr = [];

    var map_geo = null;
    var map_geo_list = null;  
    var map_geo_detail = null;  
    var polygons = [];
    var polygonsAreaList = [];  
    var polygonsAreaDetail = [];  
    var labelArr = [];
    var marker_htmlmap = [];
    var path = new google.maps.MVCArray;
    var path_area = new google.maps.MVCArray;
    var marker_cobmo_arr = [];
    var polyMarkers = [];
    var overlays = [];

    var polyLat = [];
    var polyLng = [];
    var editPoly = null;
    var oTable = null;

    $(".select_2").select2({
        placeholder: "Machines",
        allowClear: true,
    });
    $("#multiple").select2({
        placeholder: "Machines",
        allowClear: true,
    });
      $(".add").on('click', function(event){
        $(".area_sec_list").hide();
        $(".area_sec_edit").show();
      });
      $(".edit_button").on('click', function(event){
        $(".area_sec_edit").hide();
        $(".area_sec").show();
      });
      // $(".edit_button").on('click', function(event){
      // $(".area_sec_edit").hide();
      // $(".area_sec").show();
      // });
      $(".area_sec_edit_close").on('click', function(event){
        $(".area_sec_list").show();
        $(".area_sec_edit").hide();
      });
      $("button.btn.area_sec_close").on('click', function(event){
        $(".area_sec").hide();
        $(".area_sec_edit").show();
      });
      $(".save-btn").on('click', function(event){
        $(".area_sec_list").show();
        $(".area_sec").hide();
        $("#poly_main").modal("hide");
    });
    var seg2 = '<?php echo e(request()->segment(2)); ?>';
    var title = $("#machineValue").val();
    var lat_lng_date = $('#machineValue').find('option:selected').attr('mdate');
    if (seg2 == 'machines') {
        getMapMarkers();
        if(title){
            getMarkerData(title,pin=0,lat_lng_date,c=''); 
        }
    } else if (seg2 == 'poi') {
        loadGeofencesDetail();
        LoadAreaListMap();
        // areaDataList();
        // $('custom-tabs-one-profile-tab').attr('aria-selected', true);
        // $('custom-tabs-one-home-tab').attr('aria-selected', false);
    }

    function machineData(d) {
        var title = $("#machineValue").val();
        var lat_lng_date = $('option:selected', d).attr('mdate');
        console.log(lat_lng_date);
        if(title){
            getMarkerData(title,pin=0,lat_lng_date,c='change'); 
        }
    }
    function getMapMarkers(machines, machineId,title) {
        var machineId = 'all';
        var machines = <?php echo json_encode($machines); ?>;
        
            removeMarkers();
            const myLatLng = { lat: 50.41149643, lng: 8.06916572 };
            map = new google.maps.Map(document.getElementById("map-canvas"), {
                zoom: 15,
                center: myLatLng,
                mapTypeId: google.maps.MapTypeId.HYBRID,
            });
                
        var infowindow = new google.maps.InfoWindow();
        var bounds = new google.maps.LatLngBounds();
        $.each(machines, function (index, v) {
            if (v.latitude != 0 && v.longitude != 0) {
                var point = new google.maps.LatLng(v.latitude, v.longitude);
                markers[v.machine] = new google.maps.Marker({
                    position: new google.maps.LatLng(v.latitude, v.longitude),
                    icon: "<?php echo e(url('img/map_icon.png')); ?>",
                    map: map,
                    title: v.machine
                });
                markers[v.machine].markerindex = index;
                markers[v.machine].machineId = v.machine;                
                google.maps.event.addListener(markers[v.machine], 'click', function () {
                    machineId = markers[v.machine].machineId;
                    $("#machineValue").val(machineId).change();

                    if (this.machineId){                        
                        //getMarkerData(this.machineId,pin=1,v.lat_lng_date);
                    }
                    
                });

                if (machineId == 'all') {
                    bounds.extend(point);
            }
            }

        });
        if (machineId == 'all') {
            map.fitBounds(bounds);
        }
            
            setTimeout(function () {
                markerid = machineId;
                var location = markers.filter(function (marker) {
                    return marker.machineId == markerid
                });
                if (location.length > 0) {
                    var point = location[0].getPosition();
                    map.panTo(point, 1000);
                    map.setZoom(22);
                } 
            }, 3000);
            polyImage = {
                url: '<?php echo e(url("img/geofence.png")); ?>',
                size: new google.maps.Size(37, 51),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(0, 51)
            };
            if (typeof adata !== 'undefined') {
                for (k = 0; k < adata.plyId.length; k++) {
                    polyId = adata.plyId[k];
                    var bounds1 = new google.maps.LatLngBounds();
                    var pathArr = [];
                    if(adata.plyLat[polyId].length > 0)
                    {
                        for (j = 0; j < adata.plyLat[polyId].length; j++) {
                            pathArr.push(new google.maps.LatLng(adata.plyLat[polyId][j], adata.plyLng[polyId][j]));
                        }

                        for (i = 0; i < pathArr.length; i++) {
                            bounds1.extend(pathArr[i]);
                        }
                        creatAreaAfterRefresh(polyId, bounds1.getCenter(), pathArr, adata.plyName[polyId], adata.plyColor[polyId], k);
                    }
                }
            }
                
    }
    function creatAreaAfterRefresh(pid, center, pathArr, name, color, kk) {
        var marker_options = {
            position: center,
            map: map,
            title: name,
            icon: polyImage
        };
        //create marker
        var new_marker = new google.maps.Marker(marker_options);
        var polyV = new google.maps.Polygon({
            paths: pathArr,
            strokeWeight: 2,
            strokeOpacity: 0.6,
            fillColor: color
        });
        polyV.setMap(map);

        polyVarr.push(polyV);
    }
                            
    function removeMarkers() {
        for (var i = 0; i < markers.length; i++) {
            if (markers[i]) {
                markers[i].setMap(null);
            }
        }
        markers = [];
    }
    function getMarkerData(title,pin,last_date,c) {
        $("#poiDivItems").html('');
        $.post("<?php echo e(url('getMarkerData')); ?>", {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "title": title,
                },
                function (data) {
                    if (data.responseCode != 205) {
                        $("#load_today").html(data.data[0].today);
                        $("#load_month").html(data.data[0].month);
                        $("#load_week").html(data.data[0].week);

                        $("#today_jobs").html(data.data[0].today_jobs);
                        $("#month_jobs").html(data.data[0].month_jobs);
                        $("#week_jobs").html(data.data[0].week_jobs);

                        //$("#create_date").html(data.data[0].created_date);
                        $("#create_date").html(last_date);
                        var html = '';
                        if(data.data[0].area_details.length > 0){
                            $.each(data.data[0].area_details, function (index, value) {
                                html += '<div class="row"><div class="col-lg-6 col-md-6 d-flex align-items-center gap-2 px-4"><div class="color_swtches" style="background :'+value.color+'"></div><span id="area_name">'+value.polyname+'</span></div><div class="col-lg-6 col-md-6"><span id="area_weight">'+ value.total +'</span></div></div>';
                            });
                            $("#poiDivItems").append(html);
                        }
                        // $("#distance_today").html(data.data[0].Today);
                        // $("#distance_month").html(data.data[0].Month);
                        // $("#distance_week").html(data.data[0].Week);

                        if(c == 'change')
                        {
                            var machines = <?php echo json_encode($machines); ?>;
                            console.log(machines);
                            $.each(machines, function (index, v) {
                                if (v.latitude != 0 && v.longitude != 0) {
                                    var point = new google.maps.LatLng(v.latitude, v.longitude);
                                    markers[v.machine] = new google.maps.Marker({
                                        position: new google.maps.LatLng(v.latitude, v.longitude),
                                        icon: "<?php echo e(url('img/map_icon.png')); ?>",
                                        map: map,
                                        title: v.machine
                                    });
                                }

                                markers[v.machine].markerindex = index;
                                markers[v.machine].machineId = v.machine;  
                                //console.log(markers[v.machine]);              
                                google.maps.event.addListener(markers[v.machine], 'click', function () {
                                    machineId = markers[v.machine].machineId;
                                    $("#machineValue").val(machineId).change();

                                    if (this.machineId){                        
                                        //getMarkerData(this.machineId,pin=1,v.lat_lng_date);
                                    }
                                    
                                });
                            });                            
                        }

                        $("#machine_name").html(data.data[0].title);
                        markerid = title;
                        var point = markers[title].getPosition();
                            if(pin == 0){   
                                markers[title].setIcon('');
                                markers[title].setIcon('<?php echo e(url("img/map_icon.png")); ?>');
                                map.panTo(point, 1000);
                                map.setZoom(15);
                            }
                        }else{
                        }
            }, 'json');

    }

    $('#custom-tabs-one-tab li.nav-item a').on('shown.bs.tab', function(e) {
        $("#locationMap li").removeClass('active');
        var activeTabId = $(e.target).attr('id');
        if(activeTabId == 'custom-tabs-one-home-tab') {
            $("#machines_nav").addClass('active');
            $("#poi_nav").removeClass('active');
        } else {
            $("#poi_nav").addClass('active');
            $(".area_sec").hide();
            $(".area_sec_edit").hide();
            $("#machines_nav").removeClass('active');
        }
    });    
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\HLC_Web\resources\views/location_map_new.blade.php ENDPATH**/ ?>