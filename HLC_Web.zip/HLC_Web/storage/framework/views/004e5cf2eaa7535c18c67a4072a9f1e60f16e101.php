<style>
tr.disabled {
    pointer-events: none;
    opacity: 0.8;
}
</style>

<div class="area_sec_list">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 p-0">
            <div class="container-fluid px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6 col-lg-6 text-white pr-1">
                        <div class="card mb-0">
                            <div class="card-header info_header">
                                <div class="d-flex align-items-center justify-content-start">
                                    
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="my_inner_card">
                                    <div id="areaListMap" style="height: 80vh;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-xl-6 col-lg-6 text-white pl-2">
                        <div class="card bg-unset  mb-0">
                            <table id="poi-tab" class="" cellspacing="20px"
                                cellpadding="20px">
                                <thead>
                                    <tr>
                                        <td width="15%" align="center">Color</td>
                                        <td width="80%" align="center">POI</td>
                                        <td width="30%" align="center">Today(t)</td>
                                        <td width="30%" align="center">Weekly(t)</td>
                                        <td width="30%" align="center">Monthly(t)</td>
                                        <td width="30%" align="center">Notify</td>
                                        <td align="center"></td>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">

    var adata = <?php echo json_encode($coords); ?>;

    var sUrl_list = "<?php echo e(url('getGeoFenceAreasList')); ?>";
    var gUrl_list = "<?php echo e(url('getGeoFenceLatLongAreas')); ?>";
    $(document).ready(function () {
        
        function updateAreaListMapHeight() {
            var nav = $('#areaListMap');
            var contentNav = nav.offset();
            var divheight = $(window).height() - contentNav - 10;
            $("#areaListMap").css({
                height: divheight
            });
        }
        window.onresize = function () {
            updateAreaListMapHeight();
        }
        window.onload = function () {
            updateAreaListMapHeight();
        }
        //loadGeofencesDetail();
        //LoadAreaListMap();
        areaDataList();
    });

    function areaDataList()
    {       
        $(".area_sec_edit").hide();
        $(".area_sec_list").show();

        var url = "<?php echo e(url('/areaList')); ?>";
        dataTableConfigObj_v1.ajax.url = url;

        var columns = [
                        {
                            data: "color", 
                        },
                        {
                            data: "polyname",
                        },
                        {
                            data: "cost",
                            "bSortable": false,
                        },
                        {
                            data: "week_cost",
                            "bSortable": false,
                        },
                        {
                            data: "month_cost",
                            "bSortable": false,
                        },
                        {
                            data: "notify",
                            "bSortable": false,
                        },
                        {
                            data: "action",
                            "bSortable": false,
                        },
                    ];
        dataTableConfigObj_v1.order = [0, 'asc'];
        dataTableConfigObj_v1.columns = columns;
        dataTableConfigObj_v1.scrollX = false;
        dataTableConfigObj_v1.dom = "";
        dataTableConfigObj_v1.fnRowCallback = function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if(aData['color'] == "<div class=\"color_swtches\" style=\"background:#504f4f\"></div>") {
                $('td', nRow).addClass(aData['addClass']);
                // $(nRow).addClass('disabled');
                    return nRow;
            }
        };

        if ( $.fn.dataTable.isDataTable( '#poi-tab' ) ) {
            oTable = $('#poi-tab').DataTable();
            oTable.ajax.reload();
        }
        else{
            oTable = $('#poi-tab').dataTable(dataTableConfigObj_v1);
        }
        
    }

    function LoadAreaListMap() {
        var mapOptions = {
            zoom: 5,
            center: new google.maps.LatLng(50.41149643, 8.06916572),
            mapTypeId: google.maps.MapTypeId.HYBRID,
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                position: google.maps.ControlPosition.TOP_CENTER
            },
            panControl: true,
            panControlOptions: {
                position: google.maps.ControlPosition.RIGHT_TOP
            },
            zoomControl: true,
            zoomControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL,
                position: google.maps.ControlPosition.RIGHT_BOTTOM
            },
            fullscreenControl: true,
            fullscreenControlOptions: {
                position: google.maps.ControlPosition.RIGHT_BOTTOM,
            }
        }
        map_geo_list = new google.maps.Map(document.getElementById("areaListMap"), mapOptions);

        polyImageList = {
            url: '<?php echo e(url("images/beachflag.png")); ?>',
            size: new google.maps.Size(20, 32),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(0, 32)
        };

        poly = new google.maps.Polygon({
            strokeWeight: 2,
            //fillOpacity: 0.0,
            strokeOpacity: 0.6,
            clickable: true,
            fillColor: '#ff0000'
        });

        polyImageList = {
            url: '<?php echo e(url("images/beachflag.png")); ?>',
            size: new google.maps.Size(20, 32),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(0, 32)
        };

        poly = new google.maps.Polygon({
            strokeWeight: 2,
            strokeOpacity: 0.6,
            clickable: true,
            fillColor: '#ff0000'
        });
        poly.setMap(map_geo_list);
        poly.setPaths(new google.maps.MVCArray([path]));

        refreshAreaList();
    }
    function loadGeofencesDetail() {
        // var data = $("#site_id").select2('data');
        // var data = 'site01';
        var site = 1;
        var data = 1;
        var aid = 0;
        
        $.post(sUrl_list, {
            "_token": "<?php echo e(csrf_token()); ?>",
            "cmd": "site_areas",
            "site": site
        },
        function (data) {
            $("#areas").html('');
            for (v = 0; v < data.coords.length; v++) {
                $("#areas").append('<option value="' + data.coords[v].id + '">' + data.coords[v].polyname + '</option>');
            }
            if(data.coords.length > 0){
                aid = data.coords[0].id;
            }       
            focusGeofenceDetail(aid);
        },
                'json');
    }
    function focusGeofenceDetail(selGeo) {
        //var selGeo = $("#areas").val();
        if (selGeo > 0) {
            map_geo_list.panTo(polygonsAreaList[selGeo], 1000)
            map_geo_list.setZoom(12);
        }
    }
    function refreshAreaList() {
        clearMarkerAreaList();

        ajax_1 =   $.post(sUrl_list, {
            "_token": "<?php echo e(csrf_token()); ?>",
            "cmd": "refreshArea"
        },
        function (data) {
            clearPolyOverlaysAreaList();
            if (data.plyId != null) {
                for (k = 0; k < data.plyId.length; k++) {
                    polyId = data.plyId[k];
                    var bounds = new google.maps.LatLngBounds();
                    var pathArr = [];

                    for (j = 0; j < data.plyLat[polyId].length; j++) {
                        pathArr.push(new google.maps.LatLng(data.plyLat[polyId][j], data.plyLng[polyId][j]));
                    }

                    for (i = 0; i < pathArr.length; i++) {
                        bounds.extend(pathArr[i]);
                    }
                    polygonsAreaList[polyId] = bounds.getCenter();
                    creatAreaRefreshAreaList(polyId, bounds.getCenter(), pathArr, data.plyName[polyId], data.plyColor[polyId], k);
                }
                focusGeofenceDetail(data.plyId[0]);
            }

        }, 'json');
    }
    function clearPolyOverlaysAreaList() {

        if (polyVarr) {
            for (i in polyVarr) {
                polyVarr[i].setMap(null);
            }
        }
        polyVarr = [];
    }
    function creatAreaRefreshAreaList(pid, center, pathArr, name, color, kk) {

        var marker_options = {
            position: center,
            map: map_geo_list,
            title: name,
            icon: polyImageList,
        };

        //create marker
        var new_marker = new google.maps.Marker(marker_options);

        labelArr.push(new_marker);

        var polyV = new google.maps.Polygon({
            paths: pathArr,
            strokeWeight: 2,
            strokeOpacity: 0.6,
            fillColor: color
        });

        polyV.setMap(map_geo_list);
        polyVarr.push(polyV);

        google.maps.event.addListener(new_marker, "click", function (event) {
            
            editAreaRecord(pid);
        });

    }
    function clearMarkerAreaList() {
        if (labelArr) {
            for (i in labelArr) {
                labelArr[i].setMap(null);
            }

            for (i in marker_htmlmap) {
                marker_htmlmap[i].setMap(null);
            }

        }
    }
    
</script><?php /**PATH D:\wamp\www\HLC_Web\resources\views/area_list.blade.php ENDPATH**/ ?>