<aside class="control-sidebar control-sidebar-dark">
    
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<!-- jquery link -->
<!--bootstrap jquery link -->
<script type="text/javascript" src="<?php echo e(asset('js/adminltejs/adminlte.min.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/adminltejs/demo.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>

<!--fontawsome jquery link -->


<!-- data  table  js -->
<script type="text/javascript" src="<?php echo e(asset('js/datatable/jquery.dataTables.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>" defer></script>

<script type="text/javascript" src="<?php echo e(asset('js/datatable/jszip.min.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/datatable/dataTables.fixedColumns.min.js')); ?>" defer></script>
<script type="text/javascript" src="<?php echo e(asset('js/moment.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('js/daterangepicker.min.js')); ?>"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>" defer></script>


<script type="text/javascript">
$(document).ready(function () {
    $('#deshbord_masine_data').DataTable({
            "scrollX": true,
            "responsive": true,
            // fixedColumns: {
            //     left: 1,
            // },
            "dom": '<"dt-buttons">Blfrtip<"clear">',
            "lengthMenu": [10, 25, 50, 75, 100],
            "paging": true,
            "autoWidth": true,

            "buttons": [
            ]
        });
});

var today = new Date();
        var minDate = today.setDate(today.getDate() + 1);

        var firstOpen = true;
        var time;
        
        $('#notify_time').datetimepicker({
            defaultDate: new Date(),
            useCurrent: false,
            format: "hh:mm A"
        }).on('dp.show', function() {
        if(firstOpen) {
            time = moment().startOf('day');
            firstOpen = false;
        } else {
            time = "hh:mm A";
        }
        
        $(this).data('DateTimePicker').date(time);
        });
// $(".drop").click(function () {
//     $(".dropdown-menu").toggleClass("show");
// });
</script>
<script type="text/javascript" src="<?php echo e(asset('js/toastr.min.js')); ?>" defer></script>

<?php echo Toastr::message(); ?>


</body>
</html><?php /**PATH D:\wamp\www\HLC_Web\resources\views/layouts/footer.blade.php ENDPATH**/ ?>