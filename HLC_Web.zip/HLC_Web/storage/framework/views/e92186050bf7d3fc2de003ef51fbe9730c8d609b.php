<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo e(config('app.name')); ?>-Login</title>
    <!-- fav icon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" />

    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('img/favicon-32x32.png')); ?>" />
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/favicon-16x16.png')); ?>" />
     <!-- css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login.css')); ?>" >
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toastr.min.css')); ?>" >
     
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-3.6.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.js')); ?>" defer></script>
    <script type="text/javascript" src="<?php echo e(asset('js/moment.min.js')); ?>"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.13/moment-timezone-with-data.js"></script>

    <Style>
        .text-yellow {
            color: #fbba00;
        }
        
        .loader {
            position: relative;
        }
        
        img.loader_imgage {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-44%, -50%);
            height: 34px;
        }
        
        .loader_img {
            width: 100px;
            height: 100px;
            margin: 0 auto;
            animation-name: rotate;
            animation-duration: 35s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
            border-radius: 50%;
            border: 2px dashed #fff;
        }
        
        @keyframes rotate {
            from {
                transform: rotate(-360deg);
            }
            to {
                transform: rotate(360deg);
            }
        }
    </Style>
</head>
<body>
    <?php echo $__env->make('auth.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-0">
                <div class="login_bg">
                    <div class="header">
                        <div class="top_header">
                            <div class="col-sm-8 col-md-6 offset-md-6 p-0">
                                <div class="skew_header">
                                    <img src="<?php echo e(asset('img/moba_logo.png')); ?>" height="50px" class="logo" />
                                </div>
                            </div>
                        </div>
                        <div class="tagline_text">
                            <img src="<?php echo e(asset('img/hlc_web.png')); ?>" />
                        </div>
                    </div>
                    <div class="main">
                        <div class="login_form mb-5 mt-5">
                            <form class="form" method="POST" id="login-form" > 
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="input-container">
                                        <input type="hidden" name="timezone" id="timezone">
                                        <input type="text" id="username" name="username" class="input form-control" spellcheck="false" maxlength="25" />
                                        <div class="placeholder">
                                            Enter Username
                                        </div>
                                        <label class="error" style='display:none' for="username" id="username_error"></label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="input-group-password input-container" id="show_hide_password">
                                        <input class="input form-control error" id="password" name="password" type="password" />
                                        <div class="placeholder">
                                            Enter Password
                                        </div>
                                        <label class="error" style='display:none' for="password" id="password_error"></label>
                                    
                                        <div class="input-group-addon">
                                            <a href=""><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group pl-2">
                                    <a href="<?php echo e(url('forget-password')); ?>" class="link_fp">Forgot Password?</a>
                                </div>
                                <button type="submit" class="btn btn-primary text-right align-right login-btn">START</button>
                            </form>
                        </div>
                    </div>
                    <div class="footer">
                        <div class="text-right p-3">
                            <p class="mb-0">MOBA Mobile Automation AG</p>
                            <p class="mb-0">Kapellester, 15</p>
                            <p class="mb-0">65555 Limburg</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var container = $('#errors');
        var timezone = moment.tz.guess();
        $('#timezone').val(timezone);

        function updateErrorContainer(errorId, errorMsg) {
            if (typeof errorMsg != 'undefined' && errorMsg != '') {
                $("#" + errorId).removeClass("hidden").find("label").html(errorMsg);
                container.removeClass("hidden");
            }
        }
        $(document).ready(function($) {
            $("#login-form").validate({
                rules: {
                    username: {
                        required: true,
                        minlength: 5,
                        maxlength: 25,
                    },
                    password: {
                        required: true,
                        minlength: 6,
                        maxlength: 25,
                    },
                },
                messages: {
                    username: {
                        required: "Please Enter Your Username",
                        minlength: "Your Username must be at least 5 characters long",
                        maxlength: "Please Enter Username no more than 25 characters"
                    },
                    password: {
                        required: "Please Enter Your Password",
                        minlength: "Your Password must be at least 6 characters long",
                        maxlength: "Please enter Password no more than 25 characters"
                    },
                },
                errorPlacement: function(error, element) {
                    if (element.is(":radio")) {
                        error.appendTo(element.parents('.form-group'));
                    } else { // This is the default behavior 
                        // error.insertAfter(element);
                    }
                },
                submitHandler: function(form) {
                    $(".login-btn").prop("disabled", true);
                
                    $.ajax({
                        url: "<?php echo e(url('/appUserLogin')); ?>",
                        type: "POST",
                        data: 
                            $('#login-form').serialize(),
                            success: function(res) {
                                var returnVal = jQuery.parseJSON(res);
                                // console.log(returnVal.responseCode);
                                if (returnVal.responseCode == 200) {
                                    toastr.success(returnVal.responseMessage);
                                    window.location.href = '<?php echo e(url("/dashboard")); ?>';
                                    
                                }else{
                                    $(".login-btn"). attr("disabled", false);
                                    document.getElementById("login-form").reset(); 
                                    toastr.error(returnVal.responseMessage); 
                                }
                            }
                    });
                }

            });
        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" defer></script>
    
    
    <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>" defer></script>
    <script type="text/javascript" src="<?php echo e(asset('js/toastr.min.js')); ?>" defer></script>
    
    <?php echo Toastr::message(); ?>

</body>
</html><?php /**PATH D:\wamp\www\HLC_Web\resources\views/auth/login.blade.php ENDPATH**/ ?>