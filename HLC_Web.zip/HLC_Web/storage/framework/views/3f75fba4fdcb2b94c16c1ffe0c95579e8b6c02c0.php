    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-0">
                <div class="login_bg">
                    <div class="header">
                        <div class="top_header">
                            <div class="col-sm-8 col-md-6 offset-md-6 p-0">
                                <div class="skew_header">
                                    <img src="<?php echo e(asset('img/moba_logo.png')); ?>" height="50px" class="logo" />
                                </div>
                            </div>
                        </div>
                        <div class="tagline_text">
                            <img src="./img/hlc_web.png" />
                        </div>
                    </div>
                    <div class="main">
                        <div class="mb-5 mt-5 text-center">
                            <h3 class="text-yellow text-center mb-5">Welcome To Your MOBA HLC WEB User App</h3>
                            <div class="loader">
                                <div class="loader_img"></div><img src="<?php echo e(asset('img/wheelloader.svg')); ?>" class="loader_imgage">
                            </div>
                            <h5 class="text-white text-center mt-5">This might Take a few minutes please wait.....</h5>
                        </div>
                    </div>
                    <div class=" footer ">
                        <div class="text-right p-3 ">
                            <p class="mb-0 ">MOBA Mobile Automation AG</p>
                            <p class="mb-0 ">Kapellester, 15</p>
                            <p class="mb-0 ">65555 Limburg</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\wamp\www\HLC_Web\resources\views/auth/loader.blade.php ENDPATH**/ ?>