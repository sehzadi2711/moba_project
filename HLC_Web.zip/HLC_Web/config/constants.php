<?php

use App\Http\Controllers\Api\v1CommonApiController;


// COMMON CONSTANTS
return [
    'DOWNLOAD_EXCEL' => '1111',  
];
