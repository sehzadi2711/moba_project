<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Models\Clb_hlc_webservice;
use App\Lib\WnPoly;
use App\Lib\Point;


class CronController extends CommonAppController
{
    public function hlc_raw_data()
    {
        die("Test");
    }

    public function api_curl()
    {
        //die();
        $insert = array();
        $insert['api_name'] = 'api_curl';                
        //DB::table('api_log_details')->insert($insert);

        $webservice = DB::table('clb_hlc_webservice')
        ->select('*')
        ->where('is_active','ACTIVE')
        ->get(); 

        printData($webservice);

        if(isset($webservice))
        {
            foreach($webservice as $service)
            {
                $url = $service->webservice_url."/REST/GetMachinesWithData";
                $response = $this->curl_call($url,$service->auth);            
                
                $machines = json_decode($response);

                //dd($url);
                //dd($response);

                if(isset($machines))
                {    
                    DB::table('machines')->where('webservice_id', $service->id)->update(['is_active' => 'INACTIVE']);
                    $upsert = $machine_arr = array();
                    foreach($machines as $machine)
                    {                        
                        $machine_arr['webservice_id'] = $service->id;
                        $machine_arr['machine_name'] = $machine;
                        $machine_arr['is_active'] = "ACTIVE";
                        array_push($upsert,$machine_arr);
                        //DB::table('machines')->insert($machine_arr);
                        DB::table('machines')->upsert($upsert, 'machine_name');      
                                                
                        DB::enableQueryLog();
                        $machine_raw_data = DB::table('raw_data_split')
                            ->selectRaw('max(res_id) as id, machine')
                            ->where('machine',$machine)
                            ->first();

                        $from_id = 0;                 
                        $to_id = 0;                 

                        if(isset($machine_raw_data))
                        {
                            $from_id = $machine_raw_data->id + 1;
                        }

                        $url1 = $service->webservice_url."/REST/GetLastDataIdByMachine?machine=".urlencode($machine);
                        $res1 = $this->curl_call($url1,$service->auth,$machine);

                        if(isset($res1))
                        {
                            $to_id = $res1;   
                        }

                        $this->getDataByMachine($machine,$from_id,$to_id,$service->webservice_url,$service->auth);
                    }                    
                    //print_r($machines);             
                               
                }
            }            
        } 
        else
        {

        }               
    }

    public function getDataByMachine($machine,$from_id,$to_id,$webservice_url,$auth)
    {
        $url = $webservice_url."/REST/GetDataWithinIdsByMachine?machine=".urlencode($machine)."&fromId=".$from_id."&toId=".$to_id;
        $res = $this->curl_call($url,$auth,$machine);        
        $this->insertRawData($machine,$url,$res,$from_time='',$to_time='');
    }

    public function insertRawData($machine,$url,$response,$from_time='',$to_time='')
    {
        $raw_data = array();
        $raw_data['name'] = 'GetDataWithinIdsByMachine';
        $raw_data['machine'] = $machine;
        $raw_data['request_params'] = $url;
        $raw_data['response_params'] = $response;        
        //$raw_data['from_time'] = $from_time;
        //$raw_data['to_time'] = $to_time;
        DB::table('raw_data')->insert($raw_data);
        //$raw_data_id = DB::getPdo()->lastInsertId();

        //return $raw_data_id;
    }

    public function curl_call($url,$auth,$machine='')
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => array($auth),
            /*CURLOPT_HTTPHEADER => array(
                'Authorization: Basic U2VydmljZVVzZXJfSW5kaWE6N3E4Z0EyQ0o='
            )*/
        ));

        $result = '';
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if($machine) {
            //printData($response);
        }
        
        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            $result = $response;
        }
        return $result;
    }

    public function rawData()
    {
        //die();
        $insert = array();
        $insert['api_name'] = 'rawData';                
        DB::table('api_log_details')->insert($insert);

        $raw_data = DB::table('raw_data')
        ->select('*')
        ->where('status',0)
        //->where('id',202)
        ->limit(1000)
        ->get();

        //printData($raw_data);

        if(isset($raw_data))
        {
            foreach($raw_data as $raw)
            {
                $raw_res = json_decode($raw->response_params);
                //printData($raw_res);
                $status = 1;
                if(!isset($raw_res->Message))
                {
                    //printData($raw_res);
                    DB::table('raw_data')
                    ->where('id', $raw->id)
                    ->update(['status' => $status]);

                    if(isset($raw_res))
                    {
                        foreach($raw_res as $result)
                        {
                            //echo $result['VarData'];                           
                            if(isset($result->VarData) && $result->VarName == "Unspecified" )
                            {
                                //printData($result);
                                $this->insertRawDataSplit($raw,$result);
                            }   
                                         
                        }  
                    }                 
                    $status = 2;
                }
                else
                {
                    $status = 3;
                }
                DB::table('raw_data')
                    ->where('id', $raw->id)
                    ->update(['status' => $status]);
            }
        }
    } 
    
    public function rawData_v2()
    {
        //die();
        $insert = array();
        $insert['api_name'] = 'rawData_v2';                
        DB::table('api_log_details')->insert($insert);

        $raw_data = DB::table('raw_data')
        ->select('*')
        ->where('status',1)
        //->where('id',202)
        ->limit(1000)
        ->get();

        //printData($raw_data);

        if($raw_data)
        {
            foreach($raw_data as $raw)
            {
                $raw_res = json_decode($raw->response_params);
                //printData($raw_res);
                $status = 1;
                if(!isset($raw_res->Message))
                {
                    //printData($raw_res);
                    /*DB::table('raw_data')
                    ->where('id', $raw->id)
                    ->update(['status' => $status]);*/

                    if($raw_res)
                    {
                        foreach($raw_res as $result)
                        {
                            //echo $result['VarData'];                           
                            if(isset($result->VarData) && $result->VarName == "Unspecified" )
                            {
                                //printData($result);
                                $this->insertRawDataSplit($raw,$result);
                            }   
                                         
                        }  
                    }                 
                    $status = 2;
                }
                else
                {
                    $status = 3;
                }
                DB::table('raw_data')
                    ->where('id', $raw->id)
                    ->update(['status' => $status]);
            }
        }
    }
    
    public function insertRawDataSplit($raw,$raw_res)
    {
        $raw_data = array();
        $raw_data['raw_data_id'] = $raw->id;
        $raw_data['res_id'] = $raw_res->Id;

        $m = isset($raw_res->MessageHeader->Machine) ? $raw_res->MessageHeader->Machine : '';

        $raw_data_split = DB::table('raw_data_split')
        ->select('*')
        ->where('res_id',$raw_res->Id)
        ->where('machine',$m)
        ->get()
        ->toArray();

        //print_r($raw_data_split); die();

        if($raw_data_split)
        {
            $errorArr = array();
            $errorArr['raw_data_id'] = $raw->id;            
            $errorArr['split_id'] = 0;
            $errorArr['res_id'] = $raw_res->Id;
            $errorArr['machine'] = $m;
            $errorArr['var_data'] = $raw_res->VarData;
            $errorArr['type_id'] = 0;
            $errorArr['version'] = 0;
            $errorArr['error_type'] = 'duplicate_id';
            DB::table('parse_error_log')->insert($errorArr);
            return;
        }

        $messageHeader = $raw_res->MessageHeader;
        if(isset($messageHeader))
        {
            $raw_data['data_class'] = isset($messageHeader->DataClass) ? $messageHeader->DataClass : '';
            $raw_data['machine'] = isset($messageHeader->Machine) ? $messageHeader->Machine : '';
            $raw_data['cpid'] = isset($messageHeader->CPID) ? $messageHeader->CPID : '';
            $raw_data['msg_id'] = isset($messageHeader->Id) ? $messageHeader->Id : '';        
            $raw_data['data_flags'] = isset($messageHeader->DataFlags) ? $messageHeader->DataFlags : '';
            $raw_data['date_time_utc'] = isset($messageHeader->DateTimeUTC) ? $messageHeader->DateTimeUTC : '';
            $raw_data['msg_version'] = isset($messageHeader->MessageVersion) ? $messageHeader->MessageVersion : '';
            $raw_data['gps_longitude'] = isset($messageHeader->GPSLongitude) ? $messageHeader->GPSLongitude : '';
            $raw_data['gps_latitude'] = isset($messageHeader->GPSLatitude) ? $messageHeader->GPSLatitude : '';
            $raw_data['gps_quality'] = isset($messageHeader->GPSQuality) ? $messageHeader->GPSQuality : '';
            $raw_data['gps_heading'] = isset($messageHeader->GPSHeading) ? $messageHeader->GPSHeading : '';
            $raw_data['gps_speed'] = isset($messageHeader->GPSSpeed) ? $messageHeader->GPSSpeed : '';
            $raw_data['gps_sat_count'] = isset($messageHeader->GPSSatCount) ? $messageHeader->GPSSatCount : '';
            $raw_data['gps_altitude'] = isset($messageHeader->GPSAltitude) ? $messageHeader->GPSAltitude : '';
            $raw_data['gp_io_state'] = isset($messageHeader->GPIOState) ? $messageHeader->GPIOState : '';
            $raw_data['gp_io_state_readable_str'] = isset($messageHeader->GPIOStateReadableString) ? $messageHeader->GPIOStateReadableString : '';
            $raw_data['gps_distance'] = isset($messageHeader->GPSDistance) ? $messageHeader->GPSDistance : '';
        }        

        $raw_data['slew_interval1'] = isset($raw_res->SlewIntervall) ? $raw_res->SlewIntervall : '';
        $raw_data['var_state'] = isset($raw_res->VarState) ? $raw_res->VarState : '';
        $raw_data['var_transfer_reason'] = isset($raw_res->VarTransferReason) ? $raw_res->VarTransferReason : '';
        $raw_data['var_data_type'] = isset($raw_res->VarDataType) ? $raw_res->VarDataType : '';
        $raw_data['var_name'] = isset($raw_res->VarName) ? $raw_res->VarName : '';
        $raw_data['old_var_data'] = isset($raw_res->OldVarData) ? $raw_res->OldVarData : '';
        $raw_data['var_data'] = $raw_res->VarData;

        //print_r($raw_data); die();

        DB::table('raw_data_split')->insert($raw_data);
        $split_id = DB::getPdo()->lastInsertId();

        if($raw_res->VarData != '' && is_string($raw_res->VarData))
        {
            $this->parseData($raw,$raw_res->VarData,$raw_res->Id,$raw_data['machine'],$split_id);
        }
        
        //$raw_data_id = DB::getPdo()->lastInsertId();

        //return $raw_data_id;
    }

    public function parseData($raw_data,$vardata,$res_id,$machine,$split_id)
    {
        $raw_data_id = $raw_data->id;
        $str = $vardata;
        $data = base64_decode($str);
        $hex_ary = array();
        foreach (str_split($data) as $chr) {
            $hex_ary[] = sprintf("%02X", ord($chr));
        }

        if($hex_ary)
        {
            $insertArr = array();
            $insertArr['raw_data_id'] = $raw_data_id;
            $insertArr['split_id'] = $split_id;
            $insertArr['res_id'] = $res_id;
            $insertArr['machine'] = $machine;
            //$insertArr['type'] = hexdec(arrSlice($hex_ary,0,1));
            $insertArr['struct_type'] = hexdec(arrSlice($hex_ary,0,1));
            $insertArr['struct_version'] = hexdec(arrSlice($hex_ary,1,1));
            $insertArr['data_block'] = hexdec(arrSlice($hex_ary,2,1));
            $insertArr['last_data_block'] = hexdec(arrSlice($hex_ary,3,1));
            $insertArr['data_length'] = hexdec(reverseBits(arrSlice($hex_ary,4,2),2));
            $insertArr['crc'] = hexdec(reverseBits(arrSlice($hex_ary,6,2),2));

            $is_type = 0;

            if($insertArr['struct_type'] == 1 && $insertArr['struct_version'] == 1)
            {
                $is_type = 1;
                $this->weightStampFunc($insertArr,$hex_ary);
            }
            if($insertArr['struct_type'] == 2 && $insertArr['struct_version'] == 1)
            {                
                $is_type = 1;
                $this->jobFunc($insertArr,$hex_ary,$machine);
            }
            if($insertArr['struct_type'] == 3 && $insertArr['struct_version'] == 1)
            {
                $is_type = 1;
                $this->headlineFunc($insertArr,$hex_ary);
            }
            // weight stamp version 2
            if($insertArr['struct_type'] == 1 && $insertArr['struct_version'] == 2)
            {
                $is_type = 1;
                $this->weightStampFuncV2($insertArr,$hex_ary);
            }

            if($is_type == 0)
            {
                $errorArr = array();
                $errorArr['raw_data_id'] = $raw_data_id;            
                $errorArr['split_id'] = $split_id;
                $errorArr['res_id'] = $res_id;
                $errorArr['machine'] = $machine;
                $errorArr['var_data'] = $vardata;
                $errorArr['type_id'] = $insertArr['struct_type'];
                $errorArr['version'] = $insertArr['struct_version'];
                $errorArr['error_type'] = 'version_change';
                DB::table('parse_error_log')->insert($errorArr);
            }

        }
        
    }

    public function weightStampFunc($insertArr,$hex_ary)
    {
        $insertArr['seq_stamp_id'] = hexdec(reverseBits(arrSlice($hex_ary,8,4),2));
        $insertArr['seq_job_id'] = hexdec(reverseBits(arrSlice($hex_ary,12,4),2));
        $insertArr['load_to'] = hexdec(reverseBits(arrSlice($hex_ary,16,2),2));
        //$insertArr['$loaded_fleet'] =  loaded_fleet($load_to);

        $insertArr['gross_value'] = hexdec(reverseBits(arrSlice($hex_ary,18,4),2));
        $insertArr['tata_value'] = hexdec(reverseBits(arrSlice($hex_ary,22,4),2));
        $insertArr['netto_value'] = hexdec(reverseBits(arrSlice($hex_ary,26,4),2));
        $sec = msToSeconds(hexdec(reverseBits(arrSlice($hex_ary,30,4),2)));
        $insertArr['stamp_time'] = date('H:i:s',$sec);
        $timestamp = hexdec(reverseBits(arrSlice($hex_ary,34,4),2));
        $insertArr['stamp_date'] = date('Y-m-d',$timestamp);
        $insertArr['stamp_sign'] = hexdec(reverseBits(arrSlice($hex_ary,38,4),2));
        $insertArr['stamp_unit'] = hexdec(arrSlice($hex_ary,42,1));
        $insertArr['decimal_place'] = hexdec(arrSlice($hex_ary,43,1));

        $insertArr['calculated_weight'] = hex32float(reverseBits(arrSlice($hex_ary,44,4),2));
        $insertArr['weight_valid'] = hexdec(arrSlice($hex_ary,48,1));
        $insertArr['position_fix'] = hexdec(arrSlice($hex_ary,49,1));
        $insertArr['position_satelite_count'] = hexdec(reverseBits(arrSlice($hex_ary,51,4),2));

        $insertArr['latitude'] = hex64float(reverseBits(arrSlice($hex_ary,52,8),2));

        $insertArr['longitude'] = hex64float(reverseBits(arrSlice($hex_ary,60,8),2));
        $insertArr['altitude'] = hex32float(reverseBits(arrSlice($hex_ary,68,4),2));
        $insertArr['dillution'] = hex32float(reverseBits(arrSlice($hex_ary,72,4),2));
        $insertArr['oil_temp1'] = hex32float(reverseBits(arrSlice($hex_ary,76,4),2));
        $insertArr['oil_temp2'] = hex32float(reverseBits(arrSlice($hex_ary,80,4),2));
        $insertArr['stamp_state'] = hexdec(arrSlice($hex_ary,84,1));

        $area_id = 0;

        if($insertArr['latitude'] > 0 && $insertArr['longitude'] > 0)
        {            
            $poly=new WnPoly();
            $P = new Point($insertArr['latitude'], $insertArr['longitude']);
            $areas = DB::table('areas')
                    ->select('*')
                    ->where('status',1)
                    ->orderBy('id','asc')
                    ->get();
            
            if(isset($areas))
            {
                foreach ($areas as $key => $row) {
                    $area_detail = DB::table('area_details')
                        ->select('*')
                        ->where('area_id',$row->id)
                        ->get();

                    $V = array();
                    if(isset($area_detail))
                    {
                        foreach ($area_detail as $r) {

                            //printData($row,false);
                            $V[] = new Point($r->lat, $r->lng);
                        }

                        if ($poly->wn_PnPoly($P, $V)) {
                            $area_id = $row->id;
                        }
                    }
                }                 
            }
        }

        $insertArr['area_id'] = $area_id;

        DB::table('weight_stamp_raw_data')->insert($insertArr);
    }

    public function weightStampFuncV2($insertArr,$hex_ary)
    {
        $insertArr['seq_stamp_id'] = hexdec(reverseBits(arrSlice($hex_ary,8,4),2));
        $insertArr['seq_job_id'] = hexdec(reverseBits(arrSlice($hex_ary,12,4),2));
        $insertArr['load_to'] = hexdec(reverseBits(arrSlice($hex_ary,16,2),2));
        //$insertArr['$loaded_fleet'] =  loaded_fleet($load_to);

        $insertArr['gross_value'] = hexdec(reverseBits(arrSlice($hex_ary,18,4),2));
        $insertArr['tata_value'] = hexdec(reverseBits(arrSlice($hex_ary,22,4),2));
        $insertArr['netto_value'] = hexdec(reverseBits(arrSlice($hex_ary,26,4),2));
        $sec = msToSeconds(hexdec(reverseBits(arrSlice($hex_ary,30,4),2)));
        $insertArr['stamp_time'] = date('H:i:s',$sec);
        $timestamp = hexdec(reverseBits(arrSlice($hex_ary,34,4),2));
        $insertArr['stamp_date'] = date('Y-m-d',$timestamp);
        $insertArr['stamp_sign'] = hexdec(reverseBits(arrSlice($hex_ary,38,4),2));
        $insertArr['stamp_unit'] = hexdec(arrSlice($hex_ary,42,1));
        $insertArr['decimal_place'] = hexdec(arrSlice($hex_ary,43,1));

        $insertArr['calculated_weight'] = hex32float(reverseBits(arrSlice($hex_ary,44,4),2));
        $insertArr['weight_valid'] = hexdec(arrSlice($hex_ary,48,1));
        $insertArr['position_fix'] = 0;
        $insertArr['position_satelite_count'] = 0;

        $insertArr['latitude'] = 0;

        $insertArr['longitude'] = 0;
        $insertArr['altitude'] = 0;
        $insertArr['dillution'] = 0;
        $insertArr['oil_temp1'] = hex32float(reverseBits(arrSlice($hex_ary,49,4),2));
        $insertArr['oil_temp2'] = hex32float(reverseBits(arrSlice($hex_ary,53,4),2));
        $insertArr['stamp_state'] = hexdec(arrSlice($hex_ary,57,1));

        DB::table('weight_stamp_raw_data')->insert($insertArr);
    }

    public function jobFunc($insertArr,$hex_ary,$machine)
    {
        $sec = hexdec(reverseBits(arrSlice($hex_ary,8,4),2));
        $insertArr['create_time'] = date('Y-m-d H:i:s',$sec);
        $insertArr['start_time'] = date('Y-m-d H:i:s',hexdec(reverseBits(arrSlice($hex_ary,12,4),2)));
        $insertArr['end_time'] = date('Y-m-d H:i:s',hexdec(reverseBits(arrSlice($hex_ary,16,4),2)));

        $insertArr['job_id'] = hexdec(reverseBits(arrSlice($hex_ary,20,4),2));
        $insertArr['first_stamp_id'] = hexdec(reverseBits(arrSlice($hex_ary,24,4),2));
        $insertArr['last_stamp_id'] = hexdec(reverseBits(arrSlice($hex_ary,28,4),2));

        $insertArr['job_state'] = hexdec(reverseBits(arrSlice($hex_ary,32,2),2));
        $insertArr['target_weight'] = hex32float(reverseBits(arrSlice($hex_ary,34,4),2));
        $insertArr['total_loaded_weight'] = hex32float(reverseBits(arrSlice($hex_ary,38,4),2));
        $insertArr['truck_loaded_weight'] = hex32float(reverseBits(arrSlice($hex_ary,42,4),2));

        $insertArr['trailer1_loaded_weight'] = hex32float(reverseBits(arrSlice($hex_ary,46,4),2));
        $insertArr['trailer2_loaded_weight'] = hex32float(reverseBits(arrSlice($hex_ary,50,4),2));
        $insertArr['trailer3_loaded_weight'] = hex32float(reverseBits(arrSlice($hex_ary,54,4),2));
        $insertArr['no_of_trailer'] = hexdec(reverseBits(arrSlice($hex_ary,58,2),2));
        $insertArr['no_of_bucket_lifts'] = hexdec(reverseBits(arrSlice($hex_ary,60,2),2));
        $insertArr['no_of_texts'] = hexdec(reverseBits(arrSlice($hex_ary,62,1),2));

        $text_arr = array_slice($hex_ary,63);
        $insertArr['text_length'] = hexdec(reverseBits(arrSlice($text_arr,0,1),2));
        $insertArr['byte_per_char'] = hexdec(reverseBits(arrSlice($text_arr,1,1),2));
        $insertArr['text'] = hex2text($text_arr);//hexdec(reverseBits(arrSlice($text_arr,2,10),2));
        
        //DB::table('job_raw_data')->insert($insertArr);
        $id = DB::table('job_raw_data')->insertGetId($insertArr);

        $headline_raw_data = DB::table('headline_raw_data')
        ->select('*')
        ->where('machine',$machine)        
        ->orderBy('id', 'desc')
        ->first();

        if($insertArr['text'])
        {
            $arr = explode(',',$insertArr['text']);

            $jobarr = array();
            $jobarr['job_raw_id'] = $id;            
            $jobarr['job_id'] = $insertArr['job_id'];
            $jobarr['headline_id'] = isset($headline_raw_data) ? $headline_raw_data->id : 0;
            $jobarr['machine'] = $machine;
            $jobarr['text1'] = isset($arr[0]) ? $arr[0] : '';
            $jobarr['text2'] = isset($arr[1]) ? $arr[1] : '';
            $jobarr['text3'] = isset($arr[2]) ? $arr[2] : '';
            $jobarr['text4'] = isset($arr[3]) ? $arr[3] : '';
            $jobarr['text5'] = isset($arr[4]) ? $arr[4] : '';
            $jobarr['text6'] = isset($arr[5]) ? $arr[5] : '';
            $jobarr['text7'] = isset($arr[6]) ? $arr[6] : '';
            $jobarr['text8'] = isset($arr[7]) ? $arr[7] : '';
            DB::table('job_master')->insert($jobarr);
        }
    }

    public function headlineFunc($insertArr,$hex_ary)
    {
        $insertArr['no_of_texts'] = hexdec(reverseBits(arrSlice($hex_ary,8,1),2));
        $text_arr = array_slice($hex_ary,9);
        $insertArr['text_length'] = hexdec(reverseBits(arrSlice($text_arr,0,1),2));
        $insertArr['byte_per_char'] = hexdec(reverseBits(arrSlice($text_arr,1,1),2));
        $insertArr['text'] = hex2text($text_arr);

        if($insertArr['text'])
        {
            $arr1 = explode(',',$insertArr['text']);

            $insertArr['headline1'] = isset($arr1[0]) ? $arr1[0] : '';
            $insertArr['headline2'] = isset($arr1[1]) ? $arr1[1] : '';
            $insertArr['headline3'] = isset($arr1[2]) ? $arr1[2] : '';
            $insertArr['headline4'] = isset($arr1[3]) ? $arr1[3] : '';
            $insertArr['headline5'] = isset($arr1[4]) ? $arr1[4] : '';
            $insertArr['headline6'] = isset($arr1[5]) ? $arr1[5] : '';
            $insertArr['headline7'] = isset($arr1[6]) ? $arr1[6] : '';
            $insertArr['headline8'] = isset($arr1[7]) ? $arr1[7] : '';
            //DB::table('job_master')->insert($jobarr);
        }

        DB::table('headline_raw_data')->insert($insertArr);
    }

    public function getwebservice(Request $request)
    {
        try {
            
            CommonAppController::isJsonRequest($request);

            $validator = Validator::make($request->all(), [
                        'webservice_url' => 'required',
                        'user_name' => 'required',
                        'password' => 'required',
                        'customer_id' => 'required',
                        'customer_upd_id' => 'required',
                        'is_active' => 'required',
            ]);

            //dd($validator);

            CommonAppController::checkValidation($validator);
            
            Clb_hlc_webservice::updateOrCreate(
                [                    
                    'customer_id' => $request->customer_id,
                ],
                [
                    'webservice_url' => $request->webservice_url,
                    'user_name' => $request->user_name,
                    'password' => $request->password,
                    'customer_id' => $request->customer_id,
                    'customer_upd_id' => $request->customer_upd_id,
                    'is_active' => $request->is_active,
                ],
            );

            CommonAppController::endRequest(true, 200, "Webservice updated.");
        } catch (Exception $e) {
            CommonAppController::endRequest(false, 205, $e->getMessage());
        }
    }

}
