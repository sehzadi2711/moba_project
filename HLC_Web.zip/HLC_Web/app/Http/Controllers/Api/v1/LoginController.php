<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Brian2694\Toastr\Facades\Toastr;
use DataTables;
use App\Models\User;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Carbon\Carbon;

class LoginController extends CommonApiController
{
    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct()
    {
        $this->middleware('guest')->except('appUserLogout');
    }
    public function login()
    {
        return view('auth/login');
    }
    /**
     * The user has been authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  mixed  $user
     * @return mixed
     */
    protected function authenticated(Request $request, $user)
    {
        session(['timezone' => $request->timezone]); // saving to session
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  CHECK USER LOGIN
     * @date 2022-10-03
     */
    public function appUserLogin(Request $request)
    {
        $timeZone = $request->timezone;
        $credentials = $request->only('username', 'password');
        if (Auth::attempt($credentials)) {
            try {

                $user = User::where('username', $request->username)->first();
                if ($user) {
                    if (Hash::check($request->password, $user->password)) {

                        $user_access_token = $user->createToken('HLC Password Grant Client')->accessToken;

                        $response = [
                            'user_access_token' => $user_access_token,
                            'user' => $user,
                            'timezone' => $timeZone,
                        ];

                        $request->session()->put('user', $response);

                        $api_response = CommonApiController::endRequest(true, 200, 'Login successfully.');

                        insertApiLog('App Login', 'UserLogin', $request->header('user-agent'), $api_response);
                        return CommonApiController::endRequest(true, 200, 'Login successfully.', array($response));
                    } else {
                        return CommonApiController::endRequest(false, 205, 'Invalid Credentials.');
                    }
                }
            } catch (Exception $ex) {
                return CommonApiController::endRequest(false, 205, $ex->getMessage());
            }
        } else {
            $validator = Validator::make($request->all(), [
                'username' => 'required|max:25|exists:users',
                'password' => 'required|string|min:6|exists:users',
            ]);
            $message = CommonApiController::checkValidation($validator);
            return CommonApiController::endRequest(false, 205, $message);
        }
    }

    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  USER LOGOUT FROM APP
     * @date 2022-10-04
     */
    public function appUserLogout(Request $request)
    {
        auth()->logout();
        $request->session()->flush();
        $request->session()->regenerate();
        return CommonApiController::endRequest(true, 200, 'User Logout Successfully.');
    }
}
