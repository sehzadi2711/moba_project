<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr; 
use Illuminate\Support\Facades\Session;
use DataTables;
use App\Models\User;
use App\Models\Machines;
use App\Models\RawData;
use App\Models\JobRawData;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportHeadlineData;
use Carbon\Carbon;


class LocationController extends CommonApiController
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  DASHBOARD PAGE
     * @date 2022-10-04
     */
    public function location_map(Request $request) {
        $title = 'LOCATION MAP';
        //DB::enableQueryLog();  

        //dd(Session::get('user.user.id'));

        $user_machines = CommonApiController::getuserMachines(); 
        //printData($user_machines);
        if(empty($user_machines))
        {
            $user_machines = CommonApiController::getMachines(); 
        }
        //printData($user_machines);
        
        $machines = DB::table("weight_stamp_raw_data as w")
            ->join("weight_stamp_raw_data as latest, machine", function($join){
                $join;
            })
            ->select("w.machine", "w.latitude", "w.longitude", "w.res_id")
            ->where('w.latitude','>',0)
            ->where('w.longitude','>',0)
            ->whereIn('w.machine',$user_machines)
            ->orderBy("w.res_id","desc")
            ->groupBy("machine")
            ->get();
        
        //dd(getLastSql());    
        //printData($machines);

        $area = DB::table('areas')->select('*')->where('status',1)->get();

        $coords = array();
        $plyId = array();
        $plyDev = array();
        $plyLat = array();
        $plyLng = array();
        $plyName = array();
        $plyColor = array();
        foreach ($area as $row) {
                $pid = $row->id;
                $plyId[] = $pid;
                $plyDev[] = $pid;
                $det_res = DB::table('area_details')->select('lat','lng')->where('area_id',$pid)->orderBy('pointid','asc')->get();
                $lats = array();
                $lngs = array();
                foreach ($det_res as $det_row) {
                    $lats[] = $det_row->lat;
                    $lngs[] = $det_row->lng;
                }
                $plyLat[$pid] = $lats;
                $plyLng[$pid] = $lngs;
                $plyName[$pid] = $row->polyname;
                $plyColor[$pid] = ($row->color != "") ? $row->color : "#ffcc00";
        }
        $coords['plyId'] = $plyId;
        $coords['plyDev'] = $plyDev;
        $coords['plyLat'] = $plyLat;
        $coords['plyLng'] = $plyLng;
        $coords['plyName'] = $plyName;
        $coords['plyColor'] = $plyColor;
        // printData($coords);
    
        return view('locationMap')->with('machines',$machines)->with('title',$title)->with('area',$area)->with('coords',$coords);
    }
    public function getMarkerData(Request $request) {
        $title = $request->title;
        $today = Carbon::now()->format('Y-m-d');
        $week =  Carbon::today()->subDays(7)->format('Y-m-d');
        $month = date('Y-m-01');
        $getMonth = date('m');

        // DB::enableQueryLog();
        $lastthreemonth= JobRawData::selectRaw('sum(total_loaded_weight) as total,DATE_FORMAT(end_time,"%Y-%m-%d") as end_time,machine')
            ->where('machine',$title)
            ->whereBetween(DB::raw("DATE_FORMAT(end_time, '%Y-%m-%d')"),[$month,$today])
            ->groupBy(DB::raw("DATE_FORMAT(end_time, '%d-%m-%Y')"))
            ->get()->toArray();
        $todayTotal = 0;
        $monthTotal = 0;
        $weekTotal = 0;
        $data = [
            'today' => 0,
            'week' => 0,
            'month' => 0,
            'title' => $title,
            'created_date' => '',
            'created_time' => '',

        ];
        
        foreach($lastthreemonth as $todayData){
           
            // printdata($todayData['machine']);

            if($todayData['machine'] == $title){
                
                if($todayData['end_time'] == $today){
                    $todayTotal = $todayData['total'];
                    $data['today'] = round($todayTotal,2);
                    
                }
                $create_time_month = date('m', strtotime($todayData['end_time']));
                if($create_time_month == $getMonth){
                    $monthTotalround = $todayData['total'];
                    $monthTotal += $monthTotalround;
                    $data['month'] = round($monthTotal,2);
                }
                if(($todayData['end_time'] >= $week) && ($todayData['end_time'] <= $today)){
                    $weekTotalround = $todayData['total'];
                    $weekTotal += round($weekTotalround,2);
                    $data['week'] = round($weekTotal,2);
                }
            }
        }
        $query = DB::table('weight_stamp_raw_data as w');
        $query->select('w.machine', 'w.stamp_date', 'w.stamp_time');
        $query->where('machine',$title);
        $query->orderBy('w.stamp_date','desc');
        $query->limit(1);

        $getDate = $query->get()->toArray();
        $data['created_date'] = $getDate[0]->stamp_date;
        $data['created_time'] = $getDate[0]->stamp_time;

        return CommonApiController::endRequest(true, 200, 'Get Data succesfully!!.', array($data));
    }
}
