<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Session;
use DataTables;
use App\Models\User;
use App\Models\Machines;
use App\Models\RawData;
use App\Models\JobRawData;
use App\Models\WeightStampRawData;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportHeadlineData;
use Carbon\Carbon;

class LocationMapController extends CommonApiController
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  DASHBOARD PAGE
     * @date 2022-10-04
     */
    public function location_map_new(Request $request)
    {
        $segments = $request->segments();
        $activeVar = '';
        if ($segments[1] == "machines") {
            $activeVar = 'machineActive';
        } else if ($segments[1] == "poi") {
            $activeVar = 'poiActive';
        }
        $title = 'LOCATION MAP';
        $user_machines = CommonApiController::getuserMachines();
        if (empty($user_machines)) {
            $user_machines = CommonApiController::getMachines();
        }

        $machines1 = DB::table("weight_stamp_raw_data as w")
            ->join("weight_stamp_raw_data as latest, machine", function ($join) {
                $join;
            })
            ->select("w.machine", "w.latitude", "w.longitude", "w.res_id", DB::raw("concat(w.stamp_date,' ',w.stamp_time) as lat_lng_date"))
            ->where('w.latitude', '>', 0)
            ->where('w.longitude', '>', 0)
            ->whereIn('w.machine', $user_machines)
            ->orderBy("w.res_id", "desc")
            ->groupBy("machine")
            ->get();
        //$machine1 = $this->convertObjectToArray($machines1);
        $machine1 = json_decode(json_encode($machines1), true);
        //printData($machine1);

        $machines2 = DB::table('machine_metadata')
            ->select('machine', 'gps_lat as latitude', 'gps_lng as longitude', 'lat_lng_date')
            ->where('gps_lat', '!=', 0)
            ->where('gps_lng', '!=', 0)
            ->whereIn('machine', $user_machines)
            ->orderBy('machine', 'asc')
            ->get();

        $machine2 = json_decode(json_encode($machines2), true);
        $machines_arr = array();

        if (isset($machine1)) {
            foreach ($machine1 as $machine) {
                if (array_key_exists($machine['machine'], $machines_arr)) {
                    $date = $machines_arr[$machine['machine']]['lat_lng_date'];
                    if ($machine['lat_lng_date'] > $date) {
                        $machines_arr[$machine['machine']] = $machine;
                    }
                } else {
                    $machines_arr[$machine['machine']] = $machine;
                }
            }
        }

        if (isset($machine2)) {
            foreach ($machine2 as $machine) {
                if (array_key_exists($machine['machine'], $machines_arr)) {
                    $date = $machines_arr[$machine['machine']]['lat_lng_date'];
                    if ($machine['lat_lng_date'] > $date) {
                        $machines_arr[$machine['machine']] = $machine;
                    }
                } else {
                    $machines_arr[$machine['machine']] = $machine;
                }
            }
        }

        $machines = json_decode(json_encode($machines_arr));

        $area = DB::table('areas')->select('*')->where('status', 1)->get();

        $coords = array();
        $plyId = array();
        $plyDev = array();
        $plyLat = array();
        $plyLng = array();
        $plyName = array();
        $plyColor = array();
        foreach ($area as $row) {
            $pid = $row->id;
            $plyId[] = $pid;
            $plyDev[] = $pid;
            $det_res = DB::table('area_details')->select('lat', 'lng')->where('area_id', $pid)->orderBy('pointid', 'asc')->get();
            $lats = array();
            $lngs = array();
            foreach ($det_res as $det_row) {
                $lats[] = $det_row->lat;
                $lngs[] = $det_row->lng;
            }
            $plyLat[$pid] = $lats;
            $plyLng[$pid] = $lngs;
            $plyName[$pid] = $row->polyname;
            $plyColor[$pid] = ($row->color != "") ? $row->color : "#ffcc00";
        }
        $coords['plyId'] = $plyId;
        $coords['plyDev'] = $plyDev;
        $coords['plyLat'] = $plyLat;
        $coords['plyLng'] = $plyLng;
        $coords['plyName'] = $plyName;
        $coords['plyColor'] = $plyColor;
        $area_detail = [
            'polyname' => ['Moba AG', 'area 2'],
            'color' => ['#ffcc00', '#ffcc00']
        ];
        return view('location_map_new')->with('machines', $machines)->with('title', $title)->with('activeVar', $activeVar)->with('area', $area)->with('area_detail', $area_detail)->with('coords', $coords);
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  AREA LIST POI PAGE
     * @date 2023-03-01
     */
    public function areaList(Request $request)
    {
        $today = Carbon::now()->format('Y-m-d');
        $week =  Carbon::today()->subDays(7)->format('Y-m-d');
        $month = date('Y-m-01');
        $getMonth = date('m');

        $query = "SELECT ts.cost,wt.week_cost,mt.month_cost,ws.stamp_date,ws.machine,ws.area_id,ar.id as areaId,ar.polyname,ar.color,ar.email_alert
                    FROM `weight_stamp_raw_data` ws
                    LEFT JOIN (SELECT area_id,ROUND(SUM(calculated_weight),2) as cost ,stamp_date FROM weight_stamp_raw_data WHERE stamp_date='" . $today . "' group by area_id) AS ts ON ws.area_id = ts.area_id
                    LEFT JOIN (SELECT area_id,ROUND(SUM(calculated_weight),2) as week_cost ,stamp_date FROM weight_stamp_raw_data WHERE stamp_date between '" . $week . "' and '" . $today . "' group by area_id) AS wt ON ws.area_id = wt.area_id
                    LEFT JOIN (SELECT area_id,ROUND(SUM(calculated_weight),2) as month_cost ,stamp_date FROM weight_stamp_raw_data WHERE stamp_date between '" . $month . "' and '" . $today . "' group by area_id) AS mt ON ws.area_id = mt.area_id
                    LEFT JOIN areas ar ON ar.id = ws.area_id
                    WHERE ws.stamp_date between '" . $month . "' and '" . $today . "'
                    AND ws.area_id != 0
                    GROUP BY ws.area_id";
        $result = DB::select($query);

        //printData($result);
        if (!$result) {
            $query = "SELECT '0' as cost,'0' as week_cost,'0' as month_cost,ar.id as areaId,ar.polyname,ar.color,ar.email_alert FROM areas ar ";
            $result = DB::select($query);
        }

        $data = array();
        if (isset($result)) {
            foreach ($result as $key => $row) {

                $data[$key]['cost'] = ($row->cost != '') ? $row->cost : "0";
                $data[$key]['week_cost'] = ($row->week_cost != '') ? $row->week_cost : "0";
                $data[$key]['month_cost'] = ($row->month_cost != '') ? $row->month_cost : "0";
                $data[$key]['color'] = "<div class='color_swtches' style='background:$row->color'></div>";
                $data[$key]['polyname'] = $row->polyname;
                if ($row->email_alert == 1) {
                    $data[$key]['notify'] = "<button type='button' class='btn button-transpart'><span class='icon-glyph_notify_filled' style='font-size: 20px; color: #ffcc00;'></span></button>";
                }
                if ($row->email_alert == 0) {
                    $data[$key]['notify'] = "<button type='button' class='btn button-transpart'><span class='icon-glyph_notify' style='font-size: 20px; color: #fff;'></span></button>";
                }
                $data[$key]['action'] = "<button type='button' class='btn button-transpart add' onclick='editAreaRecord(" . $row->areaId . ")'><span class='icon-glyph_ctrl_right' style='font-size: 20px; color: #ffcc00;'></span></button>";
                $data[$key]['addClass'] = "";
            }
        }
        // printData($data);
        $dataCount = count($data);

        for ($i = $dataCount + 1; $i < 10; $i++) {
            array_push($data, array(
                'cost' => 0,
                'week_cost' => 0,
                'month_cost' => 0,
                'color' => '<div class="color_swtches" style="background:#504f4f"></div>',
                'polyname' => 'UnUsed' . $i,
                'notify' => '<button type="button" class="btn button-transpart"><span class="icon-glyph_notify_filled" style="font-size: 20px; color: #5c5151;"></span></button>',
                'action' => "<button type='button' class='btn button-transpart' onclick='editAreaRecord(0)'><span class='icon-glyph_ctrl_right' style='font-size: 20px; color: #ffcc00;'></span></button>",
                'addClass' => 'disabled'
            ));
        }
        // printData($data);


        $result_data['aaData'] = $data;
        $result_data['iTotalRecords'] = count($data);
        echo json_encode($result_data);
        exit;
    }
    public function getMarkerData(Request $request)
    {
        ini_set('memory_limit', '-1');

        $title = $request->title;
        $today = Carbon::now()->format('Y-m-d');
        $week =  Carbon::today()->subDays(7)->format('Y-m-d');
        $month = date('Y-m-01');
        $getMonth = date('m');

        $query2 = DB::table('weight_stamp_raw_data');
        $query2->select(DB::raw('count(distinct(seq_job_id)) as count'), 'seq_job_id', DB::raw('group_concat(seq_job_id) as seq_id'), DB::raw('sum(calculated_weight) as total'), 'stamp_date', 'machine');
        $query2->where('machine', $title);
        $query2->groupBy('stamp_date');
        $query2->whereBetween('stamp_date', [$month, $today]);
        $lastweight = $query2->get()->toArray();

        $query1 = DB::table('weight_stamp_raw_data as ws');
        $query1->select(DB::raw('ROUND(sum(ws.calculated_weight),2) as total'), 'ws.stamp_date', 'ws.machine', 'ws.area_id', 'as.polyname', 'as.color');
        $query1->leftJoin('areas as as', 'as.id', '=', 'ws.area_id');
        $query1->where('machine', $title);
        $query1->where('ws.stamp_date', $today);
        $query1->where('ws.area_id', '!=', '');
        $query1->groupBy('ws.area_id');
        $areas_details = $query1->get()->toArray();

        $todayTotal = 0;
        $monthTotal = 0;
        $weekTotal = 0;

        $todayJobs = 0;
        $monthJobs = 0;
        $weekJobs = 0;

        $data = [
            'today' => 0,
            'week' => 0,
            'month' => 0,
            'title' => $title,
            'created_date' => '',
            'created_time' => '',
            'today_jobs' => 0,
            'week_jobs' => 0,
            'month_jobs' => 0,

        ];
        $job_array = array();
        $job_week_array = array();
        if (isset($lastweight)) {
            foreach ($lastweight as $todayData) {
                $seq_job_id = explode(',', $todayData->seq_id);

                if ($todayData->machine == $title) {
                    if ($todayData->stamp_date == $today) {
                        $todayTotal = $todayData->total;
                        $data['today'] = round($todayTotal, 2);
                        $data['today_jobs'] = $todayData->count;
                    }
                    $create_time_month = date('m', strtotime($todayData->stamp_date));
                    if ($create_time_month == $getMonth) {
                        $monthTotalround = $todayData->total;
                        $monthTotal += $monthTotalround;
                        $data['month'] = round($monthTotal, 2);

                        if (!in_array($seq_job_id, $job_array)) {
                            $monthJobs++;
                            array_push($job_array, $seq_job_id);
                            $data['month_jobs'] = $monthJobs;
                        }
                    }
                    if (($todayData->stamp_date >= $week) && ($todayData->stamp_date <= $today)) {
                        $weekTotalround = $todayData->total;
                        $weekTotal += round($weekTotalround, 2);
                        $data['week'] = round($weekTotal, 2);

                        if (!in_array($seq_job_id, $job_week_array)) {
                            $weekJobs++;
                            array_push($job_week_array, $seq_job_id);
                            $data['week_jobs'] = $weekJobs;
                        }
                    }
                }
            }
        }
        /*$query = DB::table('weight_stamp_raw_data as w');
        $query->select('w.machine', 'w.stamp_date');
        $query->where('machine',$title);
        $query->orderBy('w.stamp_date','desc');
        $query->limit(1);
        $getDate = $query->get()->toArray();

        if($getDate[0]->stamp_date == $today){
            $data['created_date'] = $getDate[0]->stamp_date;
        }else{
            $data['created_date'] = $getDate[0]->stamp_date." (Last Active)";
        }*/
        $data['area_details'] = $areas_details;

        return CommonApiController::endRequest(true, 200, 'Get Data succesfully!!.', array($data));
    }
    public function getGeoFenceLatLong(Request $request)
    {

        if ($request->ajax()) {
            $asset_id = $request->input('asset_id');
            // $data['lat_long'] = DB::table('lastpoint')->select('lat', 'lng')->where('assets_id', '=', $asset_id)->get();
            $det_res = DB::table('area_details')->select('lat', 'lng')->where('area_id', $asset_id)->orderBy('pointid', 'asc')->get();
            $data = array();
            foreach ($det_res as $det_row) {
                $lats[] = $det_row->lat;
                $lngs[] = $det_row->lng;
                $data['lat_long'][] = array(
                    'lat' => $det_row->lat,
                    'lng' => $det_row->lng
                );
            }
            //$data['lat_long'][] = ['lat'=>'22.1095867','lng'=>'69.2705307'];
            //dd($data);
            echo json_encode($data);
            exit;
        }
    }
    public function getGeoFenceResults(Request $request)
    {
        $user_id = Session::get('user.id');
        $sites = ['site01', 'site02', 'site03'];
        $cmd = $request->cmd;
        $ar_id = $request->ar_id;
        // $site_id = $request->site;
        // $site_ids = array();

        $coords = array();
        $plyId = array();
        $plyDev = array();
        $plyLat = array();
        $plyLng = array();
        $plyName = array();
        $plyColor = array();

        if ($cmd == "site_areas") {
            $coords = array();
            $query = DB::table('areas as aa');
            $query->select('aa.id', 'aa.polyname');
            $query->where('aa.status', '=', 1);
            $query->where('aa.del_date', '=', NULL);
            // $query->whereIn('aa.site_id', $site_ids);
            $query->orderBy('id', 'desc');
            $rs = $query->get();

            foreach ($rs as $row) {
                $coords[] = $row;
            }
            $data['coords'] = $coords;
            die(json_encode($data));
        }

        if ($cmd == "refreshArea") {
            $query = DB::table('areas as aa');
            $query->select('aa.id', 'aa.polyname', 'aa.site_id', 'aa.color');
            $query->where('aa.status', '=', 1);
            $query->where('aa.del_date', '=', NULL);
            $query->where('aa.id', '=', $ar_id);
            // $query->whereIn('aa.site_id', $site_ids);
            $rs = $query->get();

            foreach ($rs as $row) {
                $pid = $row->id;
                $plyId[] = $pid;

                $query1 = DB::table('area_details');
                $query1->select('lat', 'lng');
                $query1->where('area_id', '=', $pid);
                $query1->orderBy('pointid', 'asc');
                $det_res = $query1->get();

                $lats = array();
                $lngs = array();

                foreach ($det_res as $det_row) {
                    $lats[] = $det_row->lat;
                    $lngs[] = $det_row->lng;
                }

                $plyLat[$pid] = $lats;
                $plyLng[$pid] = $lngs;

                $plyName[$pid] = $row->polyname;
                $plyDev[$pid] = '';
                $plyColor[$pid] = ($row->color != "") ? $row->color : "#ff0000";
            }

            $data['plyId'] = $plyId;
            $data['plyDev'] = $plyDev;
            $data['plyLat'] = $plyLat;
            $data['plyLng'] = $plyLng;
            $data['plyName'] = $plyName;
            $data['plyColor'] = $plyColor;

            die(json_encode($data));
        }
        if ($cmd == "addpoly") {

            $id = $request->id;
            $site_id = $request->site_id;
            $lat = $request->latAdd;
            $lng = $request->lngAdd;
            //$geo_type = $request->geo_type;

            if (count($lat) == 0 || count($lng) == 0) {
                die("Parameters Missing");
            }
            $site_id = 1;

            $rs = DB::table('area_details')->where('area_id', $id)->delete();
            //$area_id = DB::getPdo()->lastInsertId();

            for ($i = 0; $i < count($lat); $i++) {

                $insert1 = array();
                $insert1['area_id'] = $id;
                $insert1['lat'] = $lat[$i];
                $insert1['lng'] = $lng[$i];
                $insert1['pointid'] = $i + 1;
                $insert1['add_date'] = currentDT();
                $insert1['add_uid'] = $user_id;
                $rs = DB::table('area_details')->insert($insert1);
            }

            if ($rs) {
                die("true");
            } else {
                die("false");
            }
        }
        if ($cmd == "edit") {
            $id = $request->id;

            $query = DB::table('areas as aa');
            $query->select('aa.id', 'aa.polyname', 'aa.site_id', 'aa.color');
            $query->where('aa.id', '=', $id);
            $rs = $query->get();
            //dd($rs);
            die(json_encode($rs));
        }

        if ($cmd == "updateArea") {

            $array1['cmd'] = "geofence";
            $array1['id'] = $id = $request->id;
            //$array1['name'] = $name = $this->input->post('name');
            //$array1['color'] = $color = $this->input->post('color');
            //$site_id = $this->input->post('site_id');
            //$device = $this->input->post('device');
            //$array1['email_alert'] = $email_alert = $this->input->post('email_alert') == 'true' ? 1 : 0;
            //$array1['sms_alert'] = $sms_alert = $this->input->post('sms_alert') == 'true' ? 1 : 0;
            //$array1['in_alert'] = $in_alert = $this->input->post('in_alert') == 'true' ? 1 : 0;
            //$array1['out_alert'] = $out_alert = $this->input->post('out_alert') == 'true' ? 1 : 0;
            $array1['latAdd'] = $lat    = $request->latAdd; //$this->input->post('latAdd');
            $array1['lngAdd'] = $lng    = $request->lngAdd; //$this->input->post('lngAdd');
            //$array1['area_size'] = $area_size   = $this->input->post('area_size');
            //$array1['geo_type'] = $geo_type = $this->input->post('geo_type');

            /*if (trim($name) == '') {
                die("Parameters Missing");
            }*/

            //$siteid = getTableRecords(array('company_site_id' => $site_id), 'company_site_master',array(),'flms_site_id');
            //$array1['site_id'] =  $c_site_id = $siteid[0]['flms_site_id'];

            /*$upd = "UPDATE areas SET color = '".($color)."', polyname = '".($name)."', in_alert = '" . $in_alert . "'
            , out_alert = '" . $out_alert . "', sms_alert = '" . $sms_alert . "', email_alert = '" . $email_alert . "'
            , area_type_opt = '".($geo_type)."' WHERE id = '$id'";

            $rs = $this->db->query($upd);

            $del_sql = "DELETE FROM area_details WHERE area_id = '".$id."'";
            $del = $this->db->query($del_sql);*/

            $rs = DB::table('area_details')->where('area_id', $id)->delete();

            for ($i = 0; $i < count($lat); $i++) {

                /*$insert = "INSERT INTO area_details (area_id, lat, lng, pointid, add_date)
              values('".$id."', '".($lat[$i])."', '".($lng[$i])."', '".($i+1)."', '".$date_time."')";

                $rs = $this->db->query($insert);*/

                $insert1 = array();
                $insert1['area_id'] = $id;
                $insert1['lat'] = $lat[$i];
                $insert1['lng'] = $lng[$i];
                $insert1['pointid'] = $i + 1;
                $insert1['add_date'] = currentDT();
                $rs = DB::table('area_details')->insert($insert1);
            }

            if ($rs) {
                die("true");
            } else {
                die("false");
            }
        }
    }
    public function getGeoFenceAreasList(Request $request)
    {
        $user_id = Session::get('user.id');
        $site_ids = [1, 2];
        $cmd = $request->cmd;
        $coords = array();
        $plyId = array();
        $plyDev = array();
        $plyLat = array();
        $plyLng = array();
        $plyName = array();
        $plyColor = array();

        if ($cmd == "site_areas") {
            $coords = array();
            $query = DB::table('areas as aa');
            $query->select('aa.id', 'aa.polyname');
            $query->where('aa.status', '=', 1);
            $query->where('aa.del_date', '=', NULL);
            // $query->whereIn('aa.site_id', $site_ids);
            $query->orderBy('id', 'desc');
            $rs = $query->get();

            foreach ($rs as $row) {
                $coords[] = $row;
            }
            $data['coords'] = $coords;
            die(json_encode($data));
        }

        if ($cmd == "refreshArea") {
            $query = DB::table('areas as aa');
            $query->select('aa.id', 'aa.polyname', 'aa.site_id', 'aa.color');
            $query->where('aa.status', '=', 1);
            $query->where('aa.del_date', '=', NULL);
            $query->whereIn('aa.site_id', $site_ids);
            $rs = $query->get();

            foreach ($rs as $row) {
                $pid = $row->id;
                $plyId[] = $pid;
                $query1 = DB::table('area_details');
                $query1->select('lat', 'lng');
                $query1->where('area_id', '=', $pid);
                $query1->orderBy('pointid', 'asc');
                $det_res = $query1->get();
                // printData($det_res);

                $lats = array();
                $lngs = array();

                foreach ($det_res as $det_row) {
                    $lats[] = $det_row->lat;
                    $lngs[] = $det_row->lng;
                }

                $plyLat[$pid] = $lats;
                $plyLng[$pid] = $lngs;

                $plyName[$pid] = $row->polyname;
                $plyDev[$pid] = '';
                $plyColor[$pid] = ($row->color != "") ? $row->color : "#ff0000";
            }
            $data['plyId'] = $plyId;
            $data['plyDev'] = $plyDev;
            $data['plyLat'] = $plyLat;
            $data['plyLng'] = $plyLng;
            $data['plyName'] = $plyName;
            $data['plyColor'] = $plyColor;

            die(json_encode($data));
        }
    }
    public function getGeoFenceLatLongAreas(Request $request)
    {

        if ($request->ajax()) {
            $asset_id = $request->input('asset_id');
            // $data['lat_long'] = DB::table('lastpoint')->select('lat', 'lng')->where('assets_id', '=', $asset_id)->get();
            $data['lat_long'][] = ['lat' => '22.1095867', 'lng' => '69.2705307'];
            echo json_encode($data);
            exit;
        }
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  AREA EDIT POI PAGE
     * @date 2023-03-03
     */
    public function editAreaDetail(Request $request)
    {
        $timezone = Session::get('user.timezone');
        $area_id = $request->areaId;
        $today = Carbon::now()->format('Y-m-d');
        $week =  Carbon::today()->subDays(7)->format('Y-m-d');
        $month = date('Y-m-01');

        $query = "SELECT ts.cost,wt.week_cost,mt.month_cost,ws.stamp_date,ws.machine,ws.area_id,ar.id as areaId,ar.polyname,ar.color,ar.email_alert,ar.status,ar.area_email,ar.notify_duration,ar.notify_time,ad.lat,ad.lng
                    FROM `weight_stamp_raw_data` ws
                    LEFT JOIN (SELECT area_id,ROUND(SUM(calculated_weight),2) as cost ,stamp_date FROM weight_stamp_raw_data WHERE stamp_date='" . $today . "' group by area_id) AS ts ON ws.area_id = ts.area_id
                    LEFT JOIN (SELECT area_id,ROUND(SUM(calculated_weight),2) as week_cost ,stamp_date FROM weight_stamp_raw_data WHERE stamp_date between '" . $week . "' and '" . $today . "' group by area_id) AS wt ON ws.area_id = wt.area_id
                    LEFT JOIN (SELECT area_id,ROUND(SUM(calculated_weight),2) as month_cost ,stamp_date FROM weight_stamp_raw_data WHERE stamp_date between '" . $month . "' and '" . $today . "' group by area_id) AS mt ON ws.area_id = mt.area_id
                    LEFT JOIN areas ar ON ar.id = ws.area_id
                    LEFT JOIN (select lat,lng,area_id from area_details where area_id = 1 limit 1 ) as ad on ad.area_id = ar.id
                    WHERE ws.stamp_date between '" . $month . "' and '" . $today . "'
                    AND ws.area_id != 0
                    AND ar.id = '" . $area_id . "'";
        $result = DB::select($query);

        //printData($result);
        if (!$result) {
            $query = "SELECT '0' as cost,'0' as week_cost,'0' as month_cost,ar.id as areaId,ar.polyname,ar.color,ar.email_alert,ar.status,ar.area_email,ar.notify_duration,ar.notify_time,ad.lat,ad.lng FROM areas ar left join area_details ad on ad.area_id = ar.id  where ar.id ='" . $area_id . "' limit 1";
            $result = DB::select($query);
        }

        $data = array();
        if ($result) {
            $data['cost'] = $result[0]->cost;
            $data['week_cost'] = $result[0]->week_cost;
            $data['month_cost'] = $result[0]->month_cost;
            $data['polyname'] = $result[0]->polyname;
            $data['color'] = $result[0]->color;
            $data['email_alert'] = $result[0]->email_alert;
            $data['area_email'] = $result[0]->area_email;
            $data['notify_duration'] = $result[0]->notify_duration;
            if (isset($result[0]->notify_time) && $result[0]->notify_time != "00:00:00") {
                $time = Carbon::parse($result[0]->notify_time)->setTimezone($timezone);
                $data['notify_time'] =  $time->format('H:i A');
            } else {
                $data['notify_time'] =  '';
            }
            $data['status'] = $result[0]->status;
            $data['areas_id'] = $result[0]->areaId;
            $data['lat'] = $result[0]->lat;
            $data['lng'] = $result[0]->lng;
        }
        $data['areaId'] = $area_id;

        $result_data['aaData'] = $data;
        echo json_encode($result_data);
        exit;
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment UPDATE RECORDS AREA EDIT POI PAGE
     * @date 2023-03-06
     */

    public function updateAreaRecord(Request $request)
    {
        $timezone  = Session::get('user.timezone');
        $timestamp = $request->notify_time;
        $date = Carbon::createFromFormat('H:i A', $timestamp, $timezone);
        $date->setTimezone('UTC');

        $id = $request->areaId;
        if ($id < 1) {
            $response['status'] = 0;
            $response['responseCode'] = 205;
            $response['responseStatus'] = 'Error';
            $response['responseMessage'] = 'Something went wrong. Please try again';
        }
        $values = array();
        $values['site_id'] = 1;
        $values['polyname'] = $request->polyname;
        $values['area_email'] = $request->area_email ? $request->area_email : '';
        $values['notify_duration'] = $request->notify_duration;
        $values['notify_time'] = $request->notify_time ? date('H:i A', strtotime($date)) : '';
        $values['email_alert'] = ($request->email_alert == 'on' ? 1 : 0);
        $values['status'] = ($request->status == 'on' ? 1 : 0);

        //$values['color'] = $request->color ? $request->color : '#ff0000';
        $values['color'] = $request->color_name_val ? $request->color_name_val : '#ff0000';
        $values['add_uid'] = Session::get('user.userid') ? Session::get('user.userid') : 0;
        $values['add_date'] = currentDT();
        $area_data = DB::table('areas')->select('id as area_id')->where('id', $id)->first();
        //printData($area_data);
        if (isset($area_data)) {
            DB::table('areas')
                ->where('id', $id)
                ->update($values);
            $response['responseMessage'] = 'Record updated';
        } else {
            DB::table('areas')->insert($values);
            $response['responseMessage'] = 'Record Inserted';
        }
        // printData($values);

        $response['status'] = 1;
        $response['responseCode'] = 200;
        $response['responseStatus'] = 'Success';

        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
}
