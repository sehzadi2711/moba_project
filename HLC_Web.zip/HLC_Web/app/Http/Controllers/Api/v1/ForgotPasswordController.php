<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Brian2694\Toastr\Facades\Toastr;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Auth;

class ForgotPasswordController extends CommonApiController
{
    public function forgetPassword()
    {
        return view('auth/passwords/email');
    }
    public function verifyPassword(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'email' => 'required|email|exists:users',
            ],
            [
                'email.exists' => 'Email Does not Exist!.',
            ]
        );
        $message = CommonApiController::checkValidation($validator);
        if ($message) {
            return CommonApiController::endRequest(false, 205, $message);
        }
        $token = Str::random(64);

        DB::table('password_resets')->insert([
            'email' => $request->email,
            'token' => $token,
            'created_at' => Carbon::now()
        ]);
        $url = URL::to('/reset-password') . '/' . $token;

        $sendMail = Mail::send('auth.verify', ['token' => $token, 'url' => $url], function ($message) use ($request) {
            $message->to($request->email);
            $message->subject('Reset Password');
        });
        if (isset($sendMail)) {
            return CommonApiController::endRequest(true, 200, 'We have e-mailed your password reset link!');
        } else {
            return CommonApiController::endRequest(false, 205, 'Something Went To Wrong!');
        }
    }
    public function showResetPasswordForm($token)
    {
        $updatePassword = DB::table('password_resets')->select('email')->where('token', $token)->get()->toArray();
        if (Auth::check()) {
            return redirect()->intended('dashboard');
        } else {
            if ($updatePassword) {
                return view('auth/passwords/reset', ['token' => $token]);
            } else {
                return redirect()->intended('login');
            }
        }
    }
    public function updatePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'password' => 'required|min:6|same:confirm_password',
            'confirm_password' => 'required|min:6'
        ]);
        $message = CommonApiController::checkValidation($validator);
        if ($message) {
            return CommonApiController::endRequest(false, 205, $message);
        }
        $updatePassword = DB::table('password_resets')->select('email')->where('token', $request->token)->get()->toArray();
        if (!$updatePassword) {
            return CommonApiController::endRequest(false, 205, 'Invalid token!');
        } else {
            $user = DB::table('users')->where('email', $updatePassword[0]->email)->update(['password' => Hash::make($request->password)]);
            $data = DB::table('password_resets')->where(['email' => $updatePassword[0]->email])->delete();
            if ($user) {
                return CommonApiController::endRequest(true, 200, 'Your password has been changed!');
            } else {
                return CommonApiController::endRequest(false, 205, 'Invalid token!');
            }
        }
    }
}
