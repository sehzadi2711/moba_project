<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr; 
use Illuminate\Support\Facades\Session;
use DataTables;
use App\Models\User;
use App\Models\Machines;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends CommonApiController
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  REPORT INDEX PAGE
     * @date 2022-10-12
     */
    public function report_center(Request $request) {
        $title = 'REPORT CENTER';
        $machineData = CommonApiController::getuserMachinesData(); 
        if(empty($machineData))
        {
            $machineData = DB::table('machines')->where('is_active','ACTIVE')->get()->toArray();
        }
        
        // DB::enableQueryLog();
        $text1 = DB::table('job_master as jm')->select('jm.text1')->groupBy('jm.text1')->get();   
        $text2 = DB::table('job_master as jm')->select('jm.text2')->groupBy('jm.text2')->get();   
        $text3 = DB::table('job_master as jm')->select('jm.text3')->groupBy('jm.text3')->get();  
        $text4 = DB::table('job_master as jm')->select('jm.text4')->groupBy('jm.text4')->get();   
        $text5 = DB::table('job_master as jm')->select('jm.text5')->groupBy('jm.text5')->get();   
        $text6 = DB::table('job_master as jm')->select('jm.text6')->groupBy('jm.text6')->get();   
        $text7 = DB::table('job_master as jm')->select('jm.text7')->groupBy('jm.text7')->get();   
        $text8 = DB::table('job_master as jm')->select('jm.text8')->groupBy('jm.text8')->get();   
        // dd(getLastSQL());
        return view('report_center')->with('title',$title)->with('machineData',$machineData)
            ->with('text1',$text1)->with('text2',$text2)->with('text3',$text3)->with('text4',$text4)->with('text5',$text5)->with('text6',$text6)->with('text7',$text7)->with('text8',$text8);
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  REPORT PAGE DATA
     * @date 2022-10-12
     */
    public function reportList(Request $request) {
        $machineName = $request->machineName;
        $product = $request->product;
        $customer = $request->customer;
        $destination = $request->destination;
        $truckNo = $request->truckNo;
        $list5info = $request->list5info;
        $list6info = $request->list6info;
        $list7info = $request->list7info;
        $list8info = $request->list8info;
        $sdate = $request->sdate;
        $edate = $request->edate;
        $start_time = '';
        $end_time = '';

        if($sdate && $edate){
            $start_time = $sdate . ' 00:00:00';
            $end_time = $edate . ' 23:59:59';
        }

        $user_machines = CommonApiController::getuserMachines(); 
        if(empty($user_machines))
        {
            $user_machines = CommonApiController::getMachines(); 
        }
    
        if ($request->ajax()) {
            // DB::enableQueryLog();
            $query = DB::table('job_raw_data as jrd');
            $query->select('jrd.job_id', 'jrd.res_id','jrd.create_time','jrd.start_time', 'jrd.end_time','jrd.no_of_bucket_lifts','jrd.total_loaded_weight','jrd.target_weight','jrd.no_of_trailer','jrd.trailer1_loaded_weight','jrd.trailer2_loaded_weight','jrd.trailer3_loaded_weight',
            'jm.job_raw_id','jm.headline_id','jm.text1','jm.text2','jm.text3','jm.text4','jm.text5','jm.text6','jm.text7','jm.text8','jds.cpid','jds.machine','jds.res_id');

            //$query->leftJoin('raw_data_split as jds','jds.res_id','=','jrd.res_id');
            $query->leftJoin('raw_data_split as jds', function($join){
                $join->on('jds.res_id', '=', 'jrd.res_id')
                ->on('jds.machine', '=', 'jrd.machine');
                });
            //$query->leftJoin('job_master as jm','jm.job_raw_id','=','jrd.id');
            $query->leftJoin('job_master as jm', function($join){
                $join->on('jm.job_raw_id', '=', 'jrd.id')
                ->on('jm.machine', '=', 'jrd.machine');
                });
            
            if ($start_time != '' && $end_time != '') {
                $query->whereBetween('jrd.end_time', [$start_time, $end_time]);
            }
            if ($machineName != '') {
                $query->where('jds.machine','LIKE', "%{$machineName}%");
            }   
            else{
                $query->whereIn('jds.machine',$user_machines);
            }
            if ($product != '') {
                $query->where('jm.text1','LIKE', "%{$product}%");
            }  
            if ($customer != '') {
                $query->where('jm.text2','LIKE', "%{$customer}%");
            }  
            if ($destination != '') {
                $query->where('jm.text4','LIKE', "%{$destination}%");
            }  
            if ($truckNo != '') {
                $query->where('jm.text3','LIKE', "%{$truckNo}%");
            }  
            if ($list5info != '') {
                $query->where('jm.text5','LIKE', "%{$list5info}%");
            }  
            if ($list6info != '') {
                $query->where('jm.text6','LIKE', "%{$list6info}%");
            }  
            if ($list7info != '') {
                $query->where('jm.text7','LIKE', "%{$list7info}%");
            }  
            if ($list8info != '') {
                $query->where('jm.text8','LIKE', "%{$list8info}%");
            }  
                
            $result = $query->get();
            $data = array();
            // dd(getLastSQL());
            foreach ($result as $key => $row) {
                $data[$key]['cpid'] = $row->cpid;
                $data[$key]['machine'] = $row->machine;
                $data[$key]['job_id'] = $row->job_id;
                $data[$key]['start_time'] = $row->start_time;
                $data[$key]['end_time'] = $row->end_time;
                $data[$key]['no_of_bucket_lifts'] = $row->no_of_bucket_lifts;
                $data[$key]['total_loaded_weight'] = $row->total_loaded_weight;
                $data[$key]['target_weight'] = $row->target_weight;
                $data[$key]['text1'] = $row->text1;
                $data[$key]['text2'] = $row->text2;
                $data[$key]['text3'] = $row->text3;
                $data[$key]['text4'] = $row->text4;
                $data[$key]['text5'] = $row->text5;
                $data[$key]['text6'] = $row->text6;
                $data[$key]['text7'] = $row->text7;
                $data[$key]['text8'] = $row->text8;
                $data[$key]['no_of_trailer'] = $row->no_of_trailer;
                $data[$key]['trailer1_loaded_weight'] = $row->trailer1_loaded_weight;
                $data[$key]['trailer2_loaded_weight'] = $row->trailer2_loaded_weight;
                $data[$key]['trailer3_loaded_weight'] = $row->trailer3_loaded_weight;
            }
            $result_data['aaData'] = $data;
            echo json_encode($result_data);
            exit;
        
        }
    }
}
