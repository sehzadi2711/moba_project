<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Str;
use Brian2694\Toastr\Facades\Toastr; 

class CommonApiController extends Controller {
    /*
     * @category WEBSITE
     * @author Original Author ksanghavi@moba.de
     * @author Another Author <ksanghavi@moba.de>
     * @copyright MOBA
     * @comment  END API REQUEST
     * @date 2021-10-18
     */

    public function endRequest($status, $responseCode, $responseMessage, $data = '') {
        $response['responseStatus'] = $status;
        $response['responseCode'] = $responseCode;
        $response['responseMessage'] = $responseMessage;
        $response['data'] = $data;
        return json_encode($response); 
    }

    /*
     * @category WEBSITE
     * @author Original Author ksanghavi@moba.de
     * @author Another Author <ksanghavi@moba.de>
     * @copyright MOBA
     * @comment  CHECK JSON REQUEST
     * @date 2021-10-18
     */

    public function isJsonRequest($request) {
        if (!$request->isJson()) {
            //NOT VALID INPUT
            $response['status'] = 0;
            $response['responseCode'] = 205;
            $response['responseMessage'] = "No direct script access allowed.";
            return json_encode($response);
        }
    }

    /*
     * @category WEBSITE
     * @author Original Author ksanghavi@moba.de
     * @author Another Author <ksanghavi@moba.de>
     * @copyright MOBA
     * @comment  CHECK REQUEST VALIDATION
     * @date 2021-10-18
     */

    public function checkValidation($validator) {
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            return $message;
        }
    }

    /*
     * @category WEBSITE
     * @author Original Author ksanghavi@moba.de
     * @author Another Author <ksanghavi@moba.de>
     * @copyright MOBA
     * @comment  CHECK USER IS VALIDATE OR NOT
     * @date 2021-11-09
     */

    public function checkvalidateUser($userid) {
        $user = auth()->user();
        
        if ($userid != $user->userid) {
            CommonApiController::endRequest(true, 200, 'No user found.', array());
        }
    }

    public function getuserMachines()
    {
        $user_id = Session::get('user.user.id');
        
        $query = DB::table('user_machines as um');
        $query->select('m.machine_name');
        $query->leftJoin('machines as m','m.id','=','um.machine_id');
        $query->where('um.user_id','=',$user_id);
        $query->where('um.is_active','ACTIVE');
        $query->where('m.is_active','ACTIVE');
        $result = $query->pluck('machine_name')->toArray();

        return $result;
    }

    public function getMachines()
    {
        $query = DB::table('machines as m');
        $query->select('m.machine_name'); 
        $query->where('m.is_active','ACTIVE');
        $result = $query->pluck('machine_name')->toArray();
        return $result;
    }

    public function getuserMachinesData()
    {
        $user_id = Session::get('user.user.id');
        
        $query = DB::table('user_machines as um');
        $query->select('m.id','m.machine_name','m.webservice_id','m.is_active');
        $query->leftJoin('machines as m','m.id','=','um.machine_id');
        $query->where('um.user_id','=',$user_id);
        $query->where('um.is_active','ACTIVE');
        $query->where('m.is_active','ACTIVE');
        $result = $query->get()->toArray();

        return $result;
    }

    public function getHashPassword($str)
    {
        $password = Hash::make($str);
        return $password;
    }

}
