<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr; 
use Illuminate\Support\Facades\Session;
use DataTables;
use App\Models\User;
use App\Models\JobRawData;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;

class DashboardController extends CommonApiController
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  DASHBOARD PAGE
     * @date 2022-10-04
     */
    public function dashboard(Request $request) {
        $title = 'DASHBOARD';
        $today = Carbon::now()->format('Y-m-d');
        $yesterday = Carbon::yesterday()->format('Y-m-d');
        $week =  Carbon::today()->subDays(7)->format('Y-m-d');

        //$user_password = CommonApiController::getHashPassword('123456');
        //dd($user_password);

        $year = date('Y-01-01');
        $getMonth = date('m');
        $getYear = date('Y');

        $user_machines = CommonApiController::getuserMachines(); 
        if(empty($user_machines))
        {
            $user_machines = CommonApiController::getMachines(); 
        }
        
        $currentYear= JobRawData::selectRaw('sum(total_loaded_weight) as total,DATE_FORMAT(end_time,"%Y-%m-%d") as end_time,machine')
            ->whereIn('machine',$user_machines)
            ->whereBetween(DB::raw("DATE_FORMAT(end_time, '%Y-%m-%d')"),[$year,$today])
            ->groupBy(DB::raw("DATE_FORMAT(end_time, '%d-%m-%Y')"))
            ->get()->toArray();
        $weekTotal = 0;
        $monthTotal = 0;
        $yearTotal = 0;
        $counts = [
            'daily_total' => '0',
            'yesterday_total' => '0',
            'weekly_total' => '0',
            'monthly_total' => '0',
            'yearly_total' => '0',
        ];
        if($currentYear){
            
            foreach($currentYear as $allData){
                if($allData['end_time'] == $today){
                    $counts['daily_total'] = $allData['total'];
                }
                if($allData['end_time'] == $yesterday){
                    $counts['yesterday_total'] = $allData['total'];
                }
                if(($allData['end_time'] >= $week) && ($allData['end_time'] <= $today)){
                    $weekTotal = $allData['total'];
                    $counts['weekly_total'] += $weekTotal;
                }
                $create_time_month = date('m', strtotime($allData['end_time']));
                if($create_time_month == $getMonth){
                    $monthTotal = $allData['total'];
                    $counts['monthly_total'] += $monthTotal;
                }
                $create_time_year = date('Y', strtotime($allData['end_time']));
                if($create_time_year == $getYear){
                    $yearTotal = $allData['total'];
                    $counts['yearly_total'] += $yearTotal;
                }
            }
        }
        return view('dashboard')->with('counts',$counts)->with('title',$title);
    }
     /*
     * @category WEBSITE
     * @author Original Author <rjain@moba.de>
     * @author Another Author <megha@moba.de>
     * @copyright MOBA
     * @comment  DASHBOARD PAGE DATA
     * @date 2022-10-04
     */
    public function datalist(Request $request) {
        if ($request->ajax()) {
            // DB::enableQueryLog();
            $user_machines = CommonApiController::getuserMachines(); 
            if(empty($user_machines))
            {
                $user_machines = CommonApiController::getMachines(); 
            }
        
            $query = DB::table('job_raw_data as jrd');
            $query->select('jrd.job_id', 'jrd.res_id','jrd.create_time','jrd.start_time', 'jrd.end_time','jrd.no_of_bucket_lifts','jrd.total_loaded_weight','jrd.target_weight','jrd.no_of_trailer','jrd.trailer1_loaded_weight','jrd.trailer2_loaded_weight','jrd.trailer3_loaded_weight',
            'jm.job_raw_id','jm.headline_id','jm.text1','jm.text2','jm.text3','jm.text4','jm.text5','jm.text6','jm.text7','jm.text8','jds.cpid','jds.machine','jds.res_id');

            //$query->leftJoin('raw_data_split as jds','jds.res_id','=','jrd.res_id');
            $query->leftJoin('raw_data_split as jds', function($join){
                $join->on('jds.res_id', '=', 'jrd.res_id')
                ->on('jds.machine', '=', 'jrd.machine');
                });
            //$query->leftJoin('job_master as jm','jm.job_raw_id','=','jrd.id');
            $query->leftJoin('job_master as jm', function($join){
                $join->on('jm.job_raw_id', '=', 'jrd.id')
                ->on('jm.machine', '=', 'jrd.machine');
                });
            $query->whereIn('jds.machine',$user_machines);
               
            $result = $query->get();

            // dd(getLastSQL());
            foreach ($result as $key => $row) {
                $data[$key]['cpid'] = $row->cpid;
                $data[$key]['machine'] = $row->machine;
                $data[$key]['job_id'] = $row->job_id;
                $data[$key]['start_time'] = $row->start_time;
                $data[$key]['end_time'] = $row->end_time;
                $data[$key]['no_of_bucket_lifts'] = $row->no_of_bucket_lifts;
                $data[$key]['total_loaded_weight'] = $row->total_loaded_weight;
                $data[$key]['target_weight'] = $row->target_weight;
                $data[$key]['text1'] = $row->text1;
                $data[$key]['text2'] = $row->text2;
                $data[$key]['text3'] = $row->text3;
                $data[$key]['text4'] = $row->text4;
                $data[$key]['text5'] = $row->text5;
                $data[$key]['text6'] = $row->text6;
                $data[$key]['text7'] = $row->text7;
                $data[$key]['text8'] = $row->text8;
                $data[$key]['no_of_trailer'] = $row->no_of_trailer;
                $data[$key]['trailer1_loaded_weight'] = $row->trailer1_loaded_weight;
                $data[$key]['trailer2_loaded_weight'] = $row->trailer2_loaded_weight;
                $data[$key]['trailer3_loaded_weight'] = $row->trailer3_loaded_weight;
            }
            $result_data['aaData'] = $data;
            echo json_encode($result_data);
            exit;

        }
    }         
}
