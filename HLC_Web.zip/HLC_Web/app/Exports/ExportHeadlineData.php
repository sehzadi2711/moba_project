<?php

namespace App\Exports;

use App\Models\HeadlineRawData;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ExportHeadlineData implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function headings():array
    {
        return ["System ID", "Machine designation", "Ticket Nr.", "Job start", "Job end","bucket lifts","total weight","target weight","Product","Customer"];
    }
    public function collection()
    {
        return HeadlineRawData::all();
    }
    
}
