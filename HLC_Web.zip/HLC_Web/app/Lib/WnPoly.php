<?php

namespace App\Lib;

class Point
{
    public $x;
    public $y;

    public function __construct($x, $y)
    {
        $this->x = $x;
        $this->y = $y;
    }
}

class WnPoly
{
    private static function isLeft(Point $P0, Point $P1, Point $P2)
    {
        return (($P1->x - $P0->x) * ($P2->y - $P0->y) - ($P2->x - $P0->x) * ($P1->y - $P0->y));
    }

// wn_PnPoly(): winding number test for a point in a polygon
//      Input:   P = a point,
//               V[] = vertex points of a polygon V[n+1] with V[n]=V[0]
    /**
     * @param Point   $P
     * @param Point[] $V
     * @return int
     */
    public static function wn_PnPoly(Point $P, array $V)
    {
        $wn = 0;
        $n = count($V);

        // loop through all edges of the polygon
        for ($i = 0; $i < $n; $i++) {   // edge from V[i] to  V[i+1]
            if ($V[$i]->y <= $P->y) {          // start y <= P->y
                if ($V[($i + 1) % $n]->y > $P->y)      // an upward crossing
                    if (self::isLeft($V[$i], $V[($i + 1) % $n], $P) > 0)  // P left of  edge
                        ++$wn;            // have  a valid up intersect
            } else {                        // start y > P->y (no test needed)
                if ($V[($i + 1) % $n]->y <= $P->y)     // a downward crossing
                    if (self::isLeft($V[$i], $V[($i + 1) % $n], $P) < 0)  // P right of  edge
                        --$wn;            // have  a valid down intersect
            }
        }
        return $wn;
    }
}

?>