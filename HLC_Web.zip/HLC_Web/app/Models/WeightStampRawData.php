<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WeightStampRawData extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    // use SoftDeletes;
    public $table = 'weight_stamp_raw_data';
    protected $fillable = [
        'id', 'raw_data_id', 'res_id','struct_type','struct_version','data_block','last_data_block','data_length','crc','seq_stamp_id','seq_job_id','load_to','gross_value','tata_value','net_value','stamp_time','stamp_date','stamp_sign','stamp_unit',
        'decimal_place','calculated_weight','weight_valid','position_fix','position_satelite_count','latitude','longitude','altitude','dillution','oil_temp1','oil_temp2','stamp_state'
    ];
    public $timestamps = true;
}
