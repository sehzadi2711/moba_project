<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RawDataSplit extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    // use SoftDeletes;
    public $table = 'raw_data_split';
    protected $fillable = [
        'id', 'raw_data_id', 'res_id','data_class','machine','cpid','msg_id'];
    public $timestamps = true;
}
