<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Clb_hlc_webservice extends Model {

    protected $table = 'clb_hlc_webservice';
    public $timestamps = false;
    protected $fillable = [
        'webservice_url', 'user_name', 'password', 'customer_id', 'customer_upd_id'
    ];

}
