<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RawData extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    // use SoftDeletes;
    public $table = 'raw_data';
    protected $fillable = [
        'id', 'name', 'machine','request_params','response_params','from_time','to_time'];
    public $timestamps = true;
    public function MachineData() {
        return $this->belongsTo(WeightStampRawData::class, 'raw_data_id', 'id');
    }
}
