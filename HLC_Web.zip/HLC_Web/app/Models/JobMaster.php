<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class JobMaster extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    // use SoftDeletes;
    public $table = 'job_master';
    protected $fillable = [
        'id', 'job_id', 'job_raw_id','headline_id','machine','text1','text2','text3','text4','text5','text6','text7','text8'];
    public $timestamps = true;
}
