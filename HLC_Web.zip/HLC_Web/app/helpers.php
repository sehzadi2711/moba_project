<?php

use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Models\ApiLogs;
use Illuminate\Support\Facades\Validator;

/* Store Api Log Activity */

function insertApiLog($api_type, $api_name, $request_data, $response_data)
{
    $log['api_type'] = $api_type;
    $log['user_id'] = auth()->check() ? auth()->user()->id : 1;
    $log['api_name'] = $api_name;
    $log['request_data'] = $request_data;
    $log['response_data'] = $response_data;
    // dd($response_data);
    // dd($log);
    $activityLog = new ApiLogs($log);
    $activityLog->save();
}
/* PRINT DATA */
function printData($data, $break = true)
{
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    if ($break) {
        die;
    }
}

function getLastSQL($break = true)
{
    $queries = DB::getQueryLog();
    $last_query = 'No query found.';
    if ($queries) {
        $last_query = end($queries);
        $last_query = bindDataToQuery($last_query);
    }
    echo $last_query;
    if ($break) {
        die;
    }
}
function bindDataToQuery($queryItem)
{
    $query = $queryItem['query'];
    $bindings = $queryItem['bindings'];
    $arr = explode('?', $query);
    $res = '';
    foreach ($arr as $idx => $ele) {
        if ($idx < count($arr) - 1) {
            $res = $res . $ele . "'" . $bindings[$idx] . "'";
        }
    }
    $res = $res . $arr[count($arr) - 1];
    return $res;
}
/* GET CURRENT DATETIME */

function currentDT()
{
    return date('Y-m-d H:i:s');
}

/* GET PAGE TITLE */
function getPageTitle()
{
    $title = '';
    if (SEG2()) {
        if (SEG2() == 'poi') {
            $title = "Location Map : POI";
        } else if (SEG2() == 'machines') {
            $title = "Location Map : MACHINES";
        } else {
            $title .= ucfirst(getModuleName(SEG2()));
        }
    } else {
        $title .= ucfirst(getModuleName(SEG1()));
    }

    return $title;
}
/* GET MODULE NAME */
function getModuleName($uri)
{
    switch ($uri) {
        case "report_center":
            return "Report Center";
        case "location_map_new/machines":
            return "Location Map : MACHINES";
        case "location_map_new/poi":
            return "Location Map : POI";
        default:
            return $uri;
    }
}
/* GET SEMENT 1 */
function SEG1()
{
    return request()->segment(1);
}
/* GET SEMENT 2 */
function SEG2()
{
    return request()->segment(2);
}
