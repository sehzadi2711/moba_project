@extends('layouts.app')
@section('content')

<main>
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 p-0">
            <div class="container-fluid px-4 mb-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-8 col-lg-8 pr-1 text-white">
                        <div class="card">
                            <div class="card-header info_header">
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="col-12 col-md-6 col-lg-6 d-flex justify-content-start p-0">
                                        <img src="{{ asset('img/machine-icon.svg') }}" class="icon-card mr-3"
                                            height="50" />
                                        <?php 
                                            //  printData($machines[0]);
                                            ?>
                                        <div class="mb-0 form-group w-100 align-center">
                                            <div class="input-container">
                                                <select class="select_2 js-states input form-control w-100"
                                                    id="machineValue" onchange="machineData()">
                                                    <?php
                                                                foreach ($machines as $machine) {
                                                                    echo "<option value='" . $machine->machine . "''selected'>" . $machine->machine ."</option>";
                                                                }
                                                                ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    {{-- <div class="col-md-2 set-two-btn">
                                        <button type="button" class="btn btn-block btn-warning search-btn get-records">
                                            <i class="fa fa-play loader-class"></i>
                                        </button>
                                    </div> --}}
                                </div>
                            </div>
                            <div class="card-body">
                                <div id="map-canvas"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-xl-4 col-lg-4 text-white pl-1">
                        <div class="card info_card_inner">
                            <div class="card-header info_header d-flex justify-content-between">
                                <div class="left">
                                    <img src="{{ asset('img/machine-icon.svg') }}" class="icon-card mr-3" height="50" />
                                    <span id="machine_name"></span>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="card">
                                    <div class="card-body">
                                        <img src="{{ asset('img/date-time.svg') }}" class="icon-card mr-3"
                                            height="50" /><span id="create_date"></span>&nbsp;<span
                                            id="created_time"></span>
                                    </div>
                                </div>
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <span>Loadt (t)</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-around ">
                                            <div class="text-center">
                                                <p class="text-white lable_map_card text-left">Today</p>
                                                <div id="load_today" class="value_lable text-right">0</div>
                                            </div>
                                            <div class="text-center">
                                                <p class="text-white lable_map_card text-left">Week</p>
                                                <div id="load_week" class="value_lable text-right">0</div>
                                            </div>
                                            <div class="text-center">
                                                <p class="text-white lable_map_card text-left">Month</p>
                                                <div id="load_month" class="value_lable text-right">0</div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <span>Distance (Km)</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-around ">
                                            <div class="text-center">
                                                <p class="text-white lable_map_card text-left">Today</p>
                                                <div id="distance_today" class="value_lable text-right">0</div>
                                            </div>
                                            <div class="text-center">
                                                <p class="text-white lable_map_card text-left">Week</p>
                                                <div id="distance_week" class="value_lable text-right">0</div>
                                            </div>
                                            <div class="text-center">
                                                <p class="text-white lable_map_card text-left">Month</p>
                                                <div id="distance_month" class="value_lable text-right">0</div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <span>POI-Generation</span>
                                    </div>
                                    <div class="card-body info_header mx-2 mb-2">
                                        <img src="{{ asset('img/poi-icon.svg') }}" class="icon-card mr-3"
                                            height="50" /><span>Dummy</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--   <div class="col-sm-12 col-xl-6 col-lg-6 text-white" id="info"></div> -->
                </div>
            </div>
        </div>
    </div>
</main>
<script type="text/javascript"
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDXjauhT7MiNATaUUBR9cKx4APtpQ44He4"></script>
<script type="text/javascript" src="{{ asset('js/select2.min.js') }}"></script>
<script type="text/javascript">
    var map;
    var markers = [];
    var unit_id;
    var position = [];
    var delay = 10;
    var infWindows = [];
    var zoomlevel = 15;
    var mapcenter;
    var pin;
     var infWindow = null;
     var markerid = null;
     var polyImage = null;
     var polyVarr = [];
     var adata = <?php echo json_encode($coords); ?>;
                $(".select_2").select2({
                    placeholder: "Machines",
                    allowClear: true,
                });
                $("#multiple").select2({
                    placeholder: "Machines",
                    allowClear: true,
                });
                var title = $("#machineValue").val();
                if(title){
                    getMarkerData(title,pin=0); 
                }
                getMapMarkers();
                function machineData(){
                    var title = $("#machineValue").val();
                    if(title){
                        getMarkerData(title,pin=0); 
                    }
                }
                function getMapMarkers(machines, machineId,title) {
                    var machineId = 'all';
                    var machines = <?php echo json_encode($machines); ?>;
                    
                            removeMarkers();
                            const myLatLng = { lat: 50.3229, lng: 8.24078 };
                            map = new google.maps.Map(document.getElementById("map-canvas"), {
                                zoom: 5,
                                center: myLatLng,
                                mapTypeId: google.maps.MapTypeId.HYBRID,
                            });
                            
                            var infowindow = new google.maps.InfoWindow();
                            var bounds = new google.maps.LatLngBounds();
                            $.each(machines, function (index, v) {
                                if (v.latitude > 0 && v.longitude > 0) {
                                    var point = new google.maps.LatLng(v.latitude, v.longitude);
                                    markers[v.machine] = new google.maps.Marker({
                                        position: new google.maps.LatLng(v.latitude, v.longitude),
                                        icon: "img/map_icon.png",
                                        map: map,
                                        title: v.machine
                                    });
                                    markers[v.machine].markerindex = index;
                                    markers[v.machine].machineId = v.machine;
                                   
                                    google.maps.event.addListener(markers[v.machine], 'click', function () {
                                        machineId = markers[v.machine].machineId;

                                        if (this.machineId)
                                        getMarkerData(this.machineId,pin=1);
                                        
                                    });

                                    if (machineId == 'all') {
                                        bounds.extend(point);
                                }
                                }

                            });
                            if (machineId == 'all') {
                               map.fitBounds(bounds);
                            }
                                
                                setTimeout(function () {
                                    markerid = machineId;
                                    var location = markers.filter(function (marker) {
                                        return marker.machineId == markerid
                                    });
                                    if (location.length > 0) {
                                        var point = location[0].getPosition();
                                        map.panTo(point, 1000);
                                        map.setZoom(22);
                                    } 
                                }, 3000);
                                polyImage = {
                                    url: 'img/geofence.png',
                                    size: new google.maps.Size(37, 51),
                                    origin: new google.maps.Point(0, 0),
                                    anchor: new google.maps.Point(0, 51)
                                };
                                if (typeof adata !== 'undefined') {
                                    for (k = 0; k < adata.plyId.length; k++) {
                                        polyId = adata.plyId[k];
                                        var bounds1 = new google.maps.LatLngBounds();
                                        var pathArr = [];
                                        for (j = 0; j < adata.plyLat[polyId].length; j++) {
                                            pathArr.push(new google.maps.LatLng(adata.plyLat[polyId][j], adata.plyLng[polyId][j]));
                                        }

                                        for (i = 0; i < pathArr.length; i++) {
                                            bounds1.extend(pathArr[i]);
                                        }
                                        creatAreaAfterRefresh(polyId, bounds1.getCenter(), pathArr, adata.plyName[polyId], adata.plyColor[polyId], k);
                                    }
                                }
                           
                }
                function creatAreaAfterRefresh(pid, center, pathArr, name, color, kk) {
                            var marker_options = {
                                position: center,
                                map: map,
                                title: name,
                                icon: polyImage
                            };
                            //create marker
                            var new_marker = new google.maps.Marker(marker_options);
                            var polyV = new google.maps.Polygon({
                                paths: pathArr,
                                strokeWeight: 2,
                                strokeOpacity: 0.6,
                                fillColor: color
                            });
                            polyV.setMap(map);

                            polyVarr.push(polyV);
                }
                                       
                function removeMarkers() {
                            for (var i = 0; i < markers.length; i++) {
                                if (markers[i]) {
                                    markers[i].setMap(null);
                                }
                            }
                            markers = [];
                        }
                function getMarkerData(title,pin) {
                    $.post("{{ url('getMarkerData') }}", {
                                "_token": "{{ csrf_token() }}",
                                "title": title,
                            },
                            function (data) {
                                
                                if (data.responseCode != 205) {
                                    $("#load_today").html(data.data[0].today);
                                    $("#load_month").html(data.data[0].month);
                                    $("#load_week").html(data.data[0].week);
                                    $("#create_date").html(data.data[0].created_date);
                                    $("#created_time").html(data.data[0].created_time);
                                    // $("#distance_today").html(data.data[0].Today);
                                    // $("#distance_month").html(data.data[0].Month);
                                    // $("#distance_week").html(data.data[0].Week);
                                    $("#machine_name").html(data.data[0].title);
                                    markerid = title;
                                    var point = markers[title].getPosition();
                                        if(pin == 0){   
                                            map.panTo(point, 1000);
                                            map.setZoom(13);
                                        }
                                    }else{
                                    }
                        }, 'json');

                    }

</script>

@endsection