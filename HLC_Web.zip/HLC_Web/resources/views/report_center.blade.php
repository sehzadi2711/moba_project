@extends('layouts.app')
@section('content')
<style type="text/css">
    /* .collapsed i.fa.fa-minus.loader-class:before{
        content: "\f067";
    } */
    i.fa.fa-minus.loader-class {
color: #000;
text-decoration: unset;
}span.select2.select2-container.select2-container--default {
        width: 100% !important;
        
    }
</style>
<div class="content-wrapper">
<main class="content p-1">
    <div class="row pt-4">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <!-- top labels -->
            <div class="container-fluid">
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div class="card-header p-0" id="headingOne">
                            <div class="row">
                                <div class="col-sm-12 col-xl-12 ">
                                    <div class=" d-flex bg-secondary align-items-center justify-content-start p-2 ">
                                        <div class="col-12 col-md-5 col-lg-5">
                                            <div class="mb-0 form-group w-100 align-center">
                                                <div class="input-container d-flex align-items-center">
                                                    <i class="nav-icon icon-glyph_date text-white mr-2" style="font-size: 25px;"></i>
                                                    <input type="text" class="form-control datetime" id="daterange"
                                                        name="datetimes" placeholder="Select Date/Time" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-5 col-lg-5 machineDrop">
                                            <div class="mb-0 form-group w-100 align-center">
                                                <div class="input-container d-flex align-items-center">
                                                    <i class="nav-icon icon-glyph_wheel_loader text-white mr-2" style="font-size: 25px;"></i>
                                                    <select class="select_2 js-states input form-control w-100"
                                                        id="machineName">
                                                        <option></option>
                                                        <?php
                                                            foreach ($machineData as $machines) {
                                                                echo "<option value='" . $machines->machine_name . "'>" .$machines->machine_name ."</option>";
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-1 set-two-btn d-flex align-items-center">
                                            <button type="button"
                                                class="btn btn-warning search-btn get-records"
                                                onclick="getReportsData()">
                                                <i class="fa fa-play loader-class"></i>
                                            </button>
                                            <button class="ml-2 btn  d-flex align-items-center justify-content-start btn-warning search-btn get-records collapsed" style="width: 38px;
                                            height: 38px;padding: 10px; flex: 0;" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne"> <i class="fa fa-filter loader-class" aria-hidden="true"></i></button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                            data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 ">
                                        <div class="bg-secondary d-flex align-items-center justify-content-start p-2 ">
                               
                                            
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="product">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text1 as $texts1) {
                                                                    if($texts1->text1 != '' && $texts1->text1 != null){
                                                                        echo "<option value='" . $texts1->text1 . "'>" .$texts1->text1 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="customer">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text2 as $texts2) {
                                                                    if($texts2->text2 != '' && $texts2->text2 != null){
                                                                        echo "<option value='". $texts2->text2 . "'>" . $texts2->text2 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="truckNo">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text3 as $texts3) {
                                                                    if($texts3->text3 != '' && $texts3->text3 != null){
                                                                        echo "<option value='" . $texts3->text3 . "'>" .$texts3->text3 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="destination">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text4 as $texts4) {
                                                                    if($texts4->text4 != '' && $texts4->text4 != null){
                                                                        echo "<option value='" . $texts4->text4 . "'>" .$texts4->text4 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                             </div>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 col-xl-12 ">
                                        <div class="bg-secondary d-flex align-items-center justify-content-start p-2 ">
                               
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="list5info" >
                                                            <option></option>
                                                            <?php
                                                                foreach ($text5 as $texts5) {
                                                                    if($texts5->text5 != '' && $texts5->text5 != null){
                                                                        echo "<option value='" . $texts5->text5 . "'>" .$texts5->text5 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="list6info">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text6 as $texts6) {
                                                                    if($texts6->text6 != '' && $texts6->text6 != null){
                                                                        echo "<option value='" . $texts6->text6 . "'>".$texts6->text6 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="list7info">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text7 as $texts7) {
                                                                    if($texts7->text7 != '' && $texts7->text7 != null){
                                                                        echo "<option value='" . $texts7->text7 . "'>". $texts7->text7 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-3 col-lg-3">
                                                <div class="mb-0 form-group w-100 align-center">
                                                    <div class="input-container">
                                                        <select class=" select_2 js-states input form-control w-100" id="list8info">
                                                            <option></option>
                                                            <?php
                                                                foreach ($text8 as $texts8) {
                                                                    if($texts8->text8 != '' && $texts8->text8 != null){
                                                                        echo "<option value='" . $texts8->text8 . "'>" .$texts8->text8 ."</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                             </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- top labels end-->
            <div class="container-fluid pt-2 mb-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12 col-lg-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="w-100 d-flex align-items-center">
                                    <img src="{{ asset('img/machine-icon.svg') }}" class="icon-card mr-2" height="50">
                                    <span>Machine Data</span>
                                </div>
                                <div class="export-section">
                                    <button class="btn btn_sm p-0" onclick="javascript:exportCsv()"
                                        title="Download Excel">
                                        <img class="icon-card mr-0" height="50"
                                            src="{{ asset('img/EXCEL-G-ICON.svg') }}">
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <table id="reportData" class="table table-striped table-bordered" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th>Ticket Nr.</th>
                                            <th>Machine Designation </th>
                                            <th>Job End</th>
                                            <th>Total Weight</th>
                                            <th>Customer</th>
                                            <th>Product</th>
                                            <th>Destination</th>
                                            <th>Truck No.</th>
                                            <th>List 5 info</th>
                                            <th>List 6 info</th>
                                            <th>List 7 info</th>
                                            <th>List 8 info</th>
                                            <th>Target Weight</th>
                                            <th>Bucket Lifts</th>
                                            <th>System ID </th>
                                            <th>Job Start</th>
                                            <th>Total Truck</th>
                                            <th>Total Trailer 1</th>
                                            <th>Total Trailer 2</th>
                                            <th>Total Trailer 3</th>
                                        </tr>
                                    </thead>
                                    <thead class="column-search">
                                        <tr>
                                            <th class="dtfc-fixed-left first"><i class="fas fa-user-tag"
                                                title="Ticket Nr."></i></th>
                                            <th class="dtfc-fixed-left sec"><i class="fas fa-user-tag"
                                                    title="Machine designation"></i></th>
                                            <th class="dtfc-fixed-left third"><i class="fas fa-user-tag" title="Job End"></i></th>
                                            <th><i class="fas fa-user-tag" title="Total Weight"></i></th>
                                            <th><i class="fas fa-user-tag" title="Customer"></i></th>
                                            <th><i class="fas fa-user-tag" title="Product"></i> </th>
                                            <th><i class="fas fa-user-tag" title="Destination"></i> </th>
                                            <th><i class="fas fa-user-tag" title="Truck No."></i></th>
                                            <th><i class="fas fa-user-tag" title="List 5 Info"></i> </th>
                                            <th><i class="fas fa-user-tag" title="List 6 Info"></i></th>
                                            <th><i class="fas fa-user-tag" title="List 7 Info"></i> </th>
                                            <th><i class="fas fa-user-tag" title="List 8 Info"></i> </th>
                                            <th><i class="fas fa-user-tag" title="Target Weight"></i></th>
                                            <th><i class="fas fa-user-tag" title="Bucket Lifts"></i></th>
                                            <th><i class="fas fa-user-tag" title="System ID"></i></th>
                                            <th><i class="fas fa-user-tag" title="Job Start"></i></th>
                                            <th><i class="fas fa-user-tag" title="Total Truck"></i> </th>
                                            <th><i class="fas fa-user-tag" title="Total Trailer 1"></i> </th>
                                            <th><i class="fas fa-user-tag" title="Total Trailer 2"></i></th>
                                            <th><i class="fas fa-user-tag" title="Total Trailer 3"></i></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
<script type="text/javascript" src="{{ asset('js/select2.min.js') }}"></script>

<script type="text/javascript">
                $("#machineName").select2({
                    placeholder: "Machines",
                    allowClear: true,
                });
                $("#product").select2({
                    placeholder: "Product",
                    allowClear: true,
                });
                $("#customer").select2({
                    placeholder: "Customer",
                    allowClear: true,
                });
                $("#destination").select2({
                    placeholder: "Destination",
                    allowClear: true,
                });
                $("#truckNo").select2({
                    placeholder: "TruckNo",
                    allowClear: true,
                });
                $("#list5info").select2({
                    placeholder: "List 5 Info",
                    allowClear: true,
                });
                $("#list6info").select2({
                    placeholder: "List 6 Info",
                    allowClear: true,
                });
                $("#list7info").select2({
                    placeholder: "List 7 Info",
                    allowClear: true,
                });
                $("#list8info").select2({
                    placeholder: "List 8 Info",
                    allowClear: true,
                });
               
           
            $("#multiple").select2({
                placeholder: "Select a programming language",
                allowClear: true
            });
            
            $(function () {
                var d = new Date();
                    d.setDate(d.getDate() - 6); 
                    d.setHours(0, 0, 0, 0);
                        $('#daterange').daterangepicker({
                                timePicker: true,
                                timePicker24Hour: false,
                                timePickerIncrement: 1,
                                "startDate": d,
                                locale: {
                                    format: 'DD/MM/YYYY HH:mm A'
                                }
                            }, function (start, end, label) {
                        });
                
                    var url = "{{ url('/reportList') }}";
                    dataTableConfigObj.ajax.url = url;

                    var columns = [
                        // raw_data_split
                        {
                            data: "job_id", 
                        },
                        {
                            data: "machine",
                        },
                        // job_raw_data
                        {
                            data: "end_time",
                        },
                        {
                            data: "total_loaded_weight",
                        },
                        // dummy data
                        {
                            data: "text2",
                        },
                        {
                            data: "text1",
                           
                        },
                        {
                            data: "text4",
                        },
                        {
                            data: "text3",
                        },
                        {
                            data: "text5",
                        },
                        {
                            data: "text6",
                        },
                        {
                            data: "text7",
                        },
                        {
                            data: "text8",
                        },
                        {
                            data: "target_weight",
                        },
                        {
                            data: "no_of_bucket_lifts",
                        },
                        {
                            data: "cpid",
                        },
                        {
                            data: "start_time",
                        },
                        // job_raw_data
                        {
                            data: "no_of_trailer",
                        },
                        {
                            data: "trailer1_loaded_weight",
                        },
                        {
                            data: "trailer2_loaded_weight",
                        },
                        {
                            data: "trailer3_loaded_weight",
                        },
                    ];
                    dataTableConfigObj.order = [2, 'desc'];
                    dataTableConfigObj.columns = columns;
                    dataTableConfigObj.dom = "<'row'<'col-sm-5'l><'col-sm-2 text-center btn-export 'B><'col-sm-5'f>>" +
                                                        "<'row'<'col-sm-12'tr>>" +
                                                        "<'row'<'col-sm-6'i><'col-sm-6'p>>";
                    dataTableConfigObj.buttons = [
                        {
                            extend: 'excelHtml5',
                            title: function () {
                                return 'Hlc Report Center Data';
                            },
                            
                            footer: false,
                            className: 'btn-field',
                            text: '<img width="35" src="img/Group 15371.svg">',
                            titleAttr: 'Hlc Report Center Data',
                            oSelectorOpts: {filter: 'applied', order: 'current'},
                            exportOptions: {
                                modifier: {
                                    page: 'all'
                                },
                                format: {
                                    header: function (data, columnIdx) {
                                        return data;
                                    },
                                }
                            },
                            customize: function (xlsx) {
                                $('sheets sheet', xlsx.xl['workbook.xml']).attr('name', 'Hlc Report Center Data');
                            },
                        }
                    ];
                    dataTableConfigObj.drawCallback = function () {
                                                var hasRows2 = this.api().rows({filter: 'applied'}).data().length > 0;
                                                if (hasRows2) {
                                                    $('.export-section').show();
                                                    $('#select-all').show();
                                                } else {
                                                    $('.export-section').hide();
                                                    $('#select-all').hide();
                                                }
                                            };
                                            oTable = $('#reportData').dataTable(dataTableConfigObj);
                    // $(".btn-field").hide();
                });
                $('#reportData thead.column-search th').each(function (i) {
                    var title = $(this).find("i").attr("title");
                    if (title)
                    $(this).html('<input type="text" id="table2_id_' + i + '" class="form-control column-search frm-con-bg" placeholder="' + title + '" title="' + title + '" />');
        
                });

                $('#reportData thead input').keyup(delay(function (e) {
                    var temp1 = this.id.indexOf("table2_id_");
                    if (temp1 > -1) {
                        oTable.fnFilter(this.value, this.id.replace('table2_id_', ''));
                    }
                }, 750));
                function delay(callback, ms) {
                    var timer = 0;
                    return function () {
                        var context = this, args = arguments;
                        clearTimeout(timer);
                        timer = setTimeout(function () {
                            callback.apply(context, args);
                        }, ms || 0);
                    };
                }
                function exportCsv() {
                    $(".btn-field").click();
                }
                function getReportsData() {
    
                        var sdate = $('#daterange').data('daterangepicker').startDate.format('DD-MM-YYYY');
                        var edate = $('#daterange').data('daterangepicker').endDate.format('DD-MM-YYYY');

                        var filter_title = sdate + ' To ' + edate;

                        $(".date-range-text").html(filter_title);

                        $('#reportData').DataTable().clear().draw();
                        var url = createAjaxURL();
                        if (url != '') {
                            var oTable1 = $('#reportData').DataTable();
                            oTable1.ajax.url(url).load();
                        }
                }
                function createAjaxURL() {
                    var token = "{{csrf_token()}}";
                    var machineName = $('#machineName').val();
                    var product = $('#product').val();
                    var customer = $('#customer').val();
                    var destination = $('#destination').val();
                    var truckNo = $('#truckNo').val();

                    var list5info = $('#list5info').val();
                    var list6info = $('#list6info').val();
                    var list7info = $('#list7info').val();
                    var list8info = $('#list8info').val();
                    var sdate = $('#daterange').data('daterangepicker').startDate.format('YYYY-MM-DD');
                    var edate = $('#daterange').data('daterangepicker').endDate.format('YYYY-MM-DD');

                    var start = new Date(sdate);
                    var end = new Date(edate);

                    var diffDate = (end - start) / (1000 * 60 * 60 * 24);
                    var days = Math.round(diffDate);
                    var url = "reportList?_token=" + token + "&sdate=" + sdate + "&edate=" + edate+ "&machineName=" + machineName+"&product=" + product + "&customer=" + customer + "&destination=" + destination + "&truckNo=" + truckNo + "&list5info=" + list5info + "&list6info=" + list6info + "&list7info=" + list7info + "&list8info=" + list8info;
                    return url;
                }
                
</script>
@endsection