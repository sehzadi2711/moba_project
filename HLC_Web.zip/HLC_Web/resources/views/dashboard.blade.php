@extends('layouts.app')
@section('content')
<style>
    
    .dashboard_data_wrapper .dt-buttons {width: 100%    }
    </style>
<div class="content-wrapper">
<main class="content p-0">
                    <div class="row pt-4">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <div class="container-fluid mb-4">
                                <div class="row g-4">
                                    <div class="col-sm-12 col-xl-12 data_card">
                                        <div class="bg-secondary  d-flex align-items-center justify-content-start p-2">
                                            <img src="{{ asset('img/ton-icon.svg') }}" class="icon-card mr-2">
                                            <!--  <i class="fa fa-chart-line fa-3x text-primary"></i> -->
                                            <div class="ms-3">
                                                <p class="mb-2 text-white">Daily Total</p>
                                                <h6 class="mb-0 Green">{{ round($counts['daily_total'],3) }} t</h6>  
                                            </div>
                                        </div>

                                        <div class="bg-secondary  d-flex align-items-center justify-content-start p-2">
                                            <img src="{{ asset('img/ton-icon.svg') }}" class="icon-card mr-2">
                                            <div class="ms-3">
                                                <p class="mb-2 text-white">Yesterday Total</p>
                                                <h6 class="mb-0 yellow">{{ round($counts['yesterday_total'],3) }} t</h6>
                                            </div>
                                        </div>

                                        <div class="bg-secondary  d-flex align-items-center justify-content-start p-2">
                                            <img src="{{ asset('img/ton-icon.svg') }}" class="icon-card mr-2">
                                            <div class="ms-3">
                                                <p class="mb-2 text-white">Weekly Total</p>
                                                <h6 class="mb-0 blue">{{ round($counts['weekly_total'],3) }} t</h6>
                                            </div>
                                        </div>

                                        <div class="bg-secondary  d-flex align-items-center justify-content-start p-2">
                                            <img src="{{ asset('img/ton-icon.svg') }}" class="icon-card mr-2">
                                            <div class="ms-3">
                                                <p class="mb-2 text-white">Monthly Total</p>
                                                <h6 class="mb-0 red">{{ round($counts['monthly_total'],3) }} t</h6>
                                            </div>
                                        </div>

                                        <div class="bg-secondary  d-flex align-items-center justify-content-start p-2">
                                            <img src="{{ asset('img/ton-icon.svg') }}" class="icon-card mr-2">
                                            <div class="ms-3">
                                                <p class="mb-2 text-white">Yearly Total</p>
                                                <h6 class="mb-0 darkblue">{{ round($counts['yearly_total'],3) }} t</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="container-fluid p-0 mb-4">
                                <div class="row g-4 inner_row">
                                    <div class="col-sm-12 col-xl-12 col-lg-12 p-0">
                                        <div class="card">
                                            <div class="card-header d-flex justify-content-between">
                                                <div class="w-100 d-flex align-items-center">
                                                    <img src="{{ asset('img/machine-icon.svg') }}" class="icon-card mr-2" height="50">
                                                    <span>Machine Data</span>
                                                </div>
                                                <div class="export-section">
                                                    <button class="btn btn_sm p-0" onclick="javascript:exportCsv()" title="Download Excel">
                                                        <img class="icon-card mr-0" height="50" src="{{ asset('img/EXCEL-G-ICON.svg') }}">
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="card-body">
        
                                                <table id="dashboard_data" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th>Ticket Nr.</th>
                                                            <th>Machine Designation </th>
                                                            <th>Job End</th>
                                                            <th>Total Weight</th>
                                                            <th>Customer</th>
                                                            <th>Product</th>
                                                            <th>Destination</th>
                                                            <th>Truck No.</th>
                                                            <th>List 5 info</th>
                                                            <th>List 6 info</th>
                                                            <th>List 7 info</th>
                                                            <th>List 8 info</th>
                                                            <th>Target Weight</th>
                                                            <th>Bucket Lifts</th>
                                                            <th>System ID </th>
                                                            <th>Job Start</th>
                                                            <th>Total Truck</th>
                                                            <th>Total Trailer 1</th>
                                                            <th>Total Trailer 2</th>
                                                            <th>Total Trailer 3</th>
                                                        </tr>
                                                    </thead>
                                                    <thead class="column-search">
                                                        <tr>
                                                            <th class="dtfc-fixed-left first"><i class="fas fa-user-tag"
                                                                title="Ticket Nr."></i></th>
                                                            <th class="dtfc-fixed-left sec"><i class="fas fa-user-tag"
                                                                    title="Machine designation"></i></th>
                                                            <th class="dtfc-fixed-left third"><i class="fas fa-user-tag" title="Job End"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Total Weight"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Customer"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Product"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="Destination"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="Truck No."></i></th>
                                                            <th><i class="fas fa-user-tag" title="List 5 Info"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="List 6 Info"></i></th>
                                                            <th><i class="fas fa-user-tag" title="List 7 Info"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="List 8 Info"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="Target Weight"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Bucket Lifts"></i></th>
                                                            <th><i class="fas fa-user-tag" title="System ID"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Job Start"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Total Truck"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="Total Trailer 1"></i> </th>
                                                            <th><i class="fas fa-user-tag" title="Total Trailer 2"></i></th>
                                                            <th><i class="fas fa-user-tag" title="Total Trailer 3"></i></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody></tbody>
                                                    
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
</div>
                <script type="text/javascript">
                $(function () {
                    var url = "{{ url('/datalist') }}";
                    dataTableConfigObj.ajax.url = url;

                    var columns = [
                        // raw_data_split
                        {
                            data: "job_id", 
                        },
                        {
                            data: "machine",
                        },
                        // job_raw_data
                        {
                            data: "end_time",
                        },
                        {
                            data: "total_loaded_weight",
                        },
                        // dummy data
                        {
                            data: "text2",
                        },
                        {
                            data: "text1",
                           
                        },
                        {
                            data: "text4",
                        },
                        {
                            data: "text3",
                        },
                        {
                            data: "text5",
                        },
                        {
                            data: "text6",
                        },
                        {
                            data: "text7",
                        },
                        {
                            data: "text8",
                        },
                        {
                            data: "target_weight",
                        },
                        {
                            data: "no_of_bucket_lifts",
                        },
                        {
                            data: "cpid",
                        },
                        {
                            data: "start_time",
                        },
                        // job_raw_data
                        {
                            data: "no_of_trailer",
                        },
                        {
                            data: "trailer1_loaded_weight",
                        },
                        {
                            data: "trailer2_loaded_weight",
                        },
                        {
                            data: "trailer3_loaded_weight",
                        },
                    ];
                    dataTableConfigObj.order = [2, 'desc'];
                                              
                    dataTableConfigObj.columns = columns;
                    dataTableConfigObj.dom = "<'row'<'col-sm-5'l><'col-sm-2 text-center btn-export 'B><'col-sm-5'f>>" +
                                                        "<'row'<'col-sm-12'tr>>" +
                                                        "<'row'<'col-sm-6'i><'col-sm-6'p>>";
                    dataTableConfigObj.buttons = [
                        {
                            extend: 'excelHtml5',
                            title: function () {
                                return 'Hlc Dashboard Data';
                            },
                            
                            footer: false,
                            className: 'btn-field',
                            text: '<img width="35" src="img/Group 15371.svg">',
                            titleAttr: 'Hlc Dashboard Data',
                            oSelectorOpts: {filter: 'applied', order: 'current'},
                            exportOptions: {
                                modifier: {
                                    page: 'all',
                                },
                                format: {
                                    header: function (data, columnIdx) {
                                        return data;
                                    },
                                }
                            },
                            customize: function (xlsx) {
                                $('sheets sheet', xlsx.xl['workbook.xml']).attr('name', 'HLC Dashboard Data');
                            },
                        }
                    ];
                    dataTableConfigObj.drawCallback = function () {
                                                var hasRows2 = this.api().rows({filter: 'applied'}).data().length > 0;
                                                if (hasRows2) {
                                                    $('.export-section').show();
                                                    $('#select-all').show();
                                                } else {
                                                    $('.export-section').hide();
                                                    $('#select-all').hide();
                                                }
                                            };
                                            
                                            oTable = $('#dashboard_data').dataTable(dataTableConfigObj);
                });
                $('#dashboard_data thead.column-search th').each(function (i) {
                    var title = $(this).find("i").attr("title");
                    if (title)
                    $(this).html('<input type="text" id="table2_id_' + i + '" class="form-control column-search frm-con-bg" placeholder="' + title + '" title="' + title + '" />');
        
                });

                $('#dashboard_data thead input').keyup(delay(function (e) {
                    var temp1 = this.id.indexOf("table2_id_");
                    if (temp1 > -1) {
                        oTable.fnFilter(this.value, this.id.replace('table2_id_', ''));
                    }
                }, 750));
                function delay(callback, ms) {
                                                var timer = 0;
                                                return function () {
                                                    var context = this, args = arguments;
                                                    clearTimeout(timer);
                                                    timer = setTimeout(function () {
                                                        callback.apply(context, args);
                                                    }, ms || 0);
                                                };
                                            }
                function exportCsv() {
                    $(".btn-field").click();
                }
               
                </script>
                @endsection