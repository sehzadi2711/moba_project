{{-- add Area section start --}}
<div class="area_sec" style="display: none">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12" style="height:38px;">
            <div class="d-flex align-items-center w-100 title-sec">
                <div class="title d-flex">
                    <span class="title-border" id="aLinecolor"
                        style="border-color: #ffcc00;"></span>
                    <h3 class="ml-2 mb-0" id="polyname"></h3>
                </div>
                <div>
                    <button class="btn area_sec_close">                         
                        <span aria-hidden="true" style="font-size: 12px; font-weight:100;font-family:FontAwesome;" onclick="editAreaRecord($('#area_id').val());">x</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="row align-items-center mt-2">
        <div class="col-sm-6 col-md-6 col-lg-6">
            <div class="">
                <button class="btn btn-tab active">Freestyle</button>
                <button class="btn btn-tab">Circle</button>
                <button class="btn btn-tab">Rectangle</button>
            </div>
        </div>
        <div class="col-sm-6 col-md-6 col-lg-6 d-flex justify-content-end">
            <button class="btn btn-setting d-none" onclick="removeLineSegment()"
                id='undoBtn'><span class="icon-glyph_redo"
                    style="font-size: 30px; color: #fff;"></span>undo</button>
            <button class="btn btn-setting d-none" onclick="removeLineSegment()"><span
                    class="icon-glyph_undo"
                    style="font-size: 30px; color: #fff;"></span>redo</button>
            <button type="button" class="btn btn-setting" data-toggle="modal"
                data-target="#poly_main"><span class="icon-glyph_save"
                    style="font-size: 30px; color: #fff;"></span>save</button>
        </div>
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div id="addAreaMap" style="height: 70vh;"></div>
        </div>
    </div>
</div>

<div class="modal fade" id="poly_main" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body">
                <div class="row align-items-center">
                    <div class="col-md-3" style="text-align:center;">
                        <input type="hidden" id="txtPoly1" name="txtPoly1" value="Moba AG">
                        <span class="icon-glyph_save save-icon" style="font-size: 80px; color: #fff;"></span>
                    </div>
                    <div class="col-md-9">
                        <h1 class="modal-title">Save Changes</h1>
                        <p>Are You Sure, You want To Save Your Changes?</p>
                    </div>
                </div>
                <div class="modal-footer p-0">
                    <button type="button" id="add_update" onclick="updatePoly($('#area_id').val());" class="btn btn-warning d-flex align-item-center">
                        <span class="icon-glyph_save mr-2" style="font-size: 20px;"></span>Save
                    </button>
                    <button type="button" id="" class="btn btn-succsess d-flex align-item-center" data-dismiss="modal" aria-label="Close">
                        <span class="icon-glyph_delete mr-2" style="font-size: 20px;"></span>Close
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    var adata = <?php echo json_encode($coords); ?>;

    var sUrl = "{{ url('getGeoFenceResults') }}";
    var gUrl = "{{ url('getGeoFenceLatLong') }}";
    $(document).ready(function () {       

        function updateHeight() {
            var nav = $('#addAreaMap');
            var contentNav = nav.offset();
            var divheight = $(window).height() - contentNav - 10;
            $("#addAreaMap").css({
                height: divheight
            });
        }

        window.onresize = function () {
            updateHeight();
        }
        window.onload = function () {
            updateHeight();
        }
        //LoadGeoMap1();
        //addPointfrm_Combo();
        //loadGeofences1();
    });
    function LoadGeoMap1() {
        //alert("in");
        var mapOptions = {
            zoom: 12,
            center: new google.maps.LatLng(50.41149643, 8.06916572),
            mapTypeId: google.maps.MapTypeId.HYBRID,
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
                position: google.maps.ControlPosition.TOP_CENTER
            },
            panControl: true,
            panControlOptions: {
                position: google.maps.ControlPosition.RIGHT_TOP
            },
            zoomControl: true,
            zoomControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL,
                position: google.maps.ControlPosition.RIGHT_BOTTOM
            },
            fullscreenControl: true,
            fullscreenControlOptions: {
                position: google.maps.ControlPosition.RIGHT_BOTTOM,
            }
        }

        map_geo = new google.maps.Map(document.getElementById("addAreaMap"), mapOptions);

        polyImage = {
            url: '{{ url("images/beachflag.png") }}',
            size: new google.maps.Size(20, 32),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(0, 32)
        };

        poly = new google.maps.Polygon({
            strokeWeight: 2,
            strokeOpacity: 0.6,
            clickable: true,
            fillColor: '#ff0000'
        });

        polyImage = {
            url: '{{ url("images/beachflag.png") }}',
            size: new google.maps.Size(20, 32),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(0, 32)
        };

        poly.setMap(map_geo);
        var poly_lat = $('#area_lat').val();
        if(poly_lat != '')
        {
            console.log('poly_lat',poly_lat);
            path_area = [];
            newPoly = false;
            path_area = new google.maps.MVCArray;
        }
        else
        {
            console.log('path_area',path_area);
            poly.setPaths(new google.maps.MVCArray([path_area]));
            google.maps.event.addListener(map_geo, 'click', addPoint);
            newPoly = true;
        }

        refreshArea();

    }
    function loadGeofences1() {
        // var data = $("#site_id").select2('data');
        // var data = 'site01';
        var site = 1;
        var data = 1;
        
        $.post(sUrl, {
            "_token": "{{ csrf_token() }}",
            "cmd": "site_areas",
            "site": site
        },
        function (data) {
            $("#areas").html('');
            for (v = 0; v < data.coords.length; v++) {
                $("#areas").append('<option value="' + data.coords[v].id + '">' + data.coords[v].polyname + '</option>');
            }
            focusGeofence();
        },
                'json');
    }
    function addPointfrm_Combo(area_id) {

        clearMarker();
        var data = $('#areas').select2('data');
        // var asset_id = data[0].id;
        //var asset_id = 3;
        // console.log(asset_id,'gff');
        $.ajax({
            type: "POST",
            url: gUrl,
            data: {asset_id: area_id, "_token": "{{ csrf_token() }}"},
            success: function (data) {
                var returnVal = jQuery.parseJSON(data);
                if(returnVal.length > 0)
                {
                    if (returnVal.lat_long[0]) {
                        var lt1 = returnVal.lat_long[0].lat;
                        var lng1 = returnVal.lat_long[0].lng;
                        if (lt1 != 0 && lng1 != 0) {
                            markerLatLng(lt1, lng1);
                        }
                    } else {
                        alert("Location not Found");
                    }
                }else{
                    newPoly = true;
                    var poly_lat = $('#area_lat').val();
                    if(poly_lat != '') 
                    {
                        $('#add_update').attr('onclick', '');
                        $('#add_update').attr('onclick', 'updatePoly($("#area_id").val());');
                    }else{
                        $('#add_update').attr('onclick', '');
                        $('#add_update').attr('onclick', 'addPoly($("#area_id").val());');
                    }
                }
                
            }
        });
    }

    function markerLatLng(lt1, lng1)
    {
        if (marker_cobmo_arr) {
            for (i in marker_cobmo_arr) {
                marker_cobmo_arr[i].setMap(null);
            }
        }
        /*var marker = new google.maps.Marker({
            position: new google.maps.LatLng(lt1, lng1),
            map: map_geo,
        });
        marker_cobmo_arr.push(marker);*/
        //map_geo.setCenter(new google.maps.LatLng(lt1, lng1));
        //marker.setMap(map_geo);
        //map_geo.setZoom(12);
        $("#poly_help").modal('hide');
        $("#btnCreate").val("Save");
        $('#btnCreatePoly').show();
        $('#btnCancelPoly').show();

        if(editPoly != null) {
            editPoly.setOptions({
                editable: true
            });
        }

        newPoly = false;
    }

    function addPoly(aid) {
        var polyname = $('#polyname').val();
        console.log(polyname,'fff');
        for (i = 0; i < polyMarkers.length; i++) {
            polyLat.push(polyMarkers[i].getPosition().lat());
            polyLng.push(polyMarkers[i].getPosition().lng());
        }

        if (polyMarkers.length < 3) {
            toastr.error("Please select area on map", "Error");
            return false;
        }
        //var data1 = $('#cmbSite').select2('data');
        siteId = 1;
        //cmbgType = $("#cmbgType").val();

        // var area_size = $("#span-area").text();


        $.post(sUrl, {
            "_token": "{{ csrf_token() }}",
            "cmd": 'addpoly',
            "id": aid,
            "latAdd": polyLat,
            "lngAdd": polyLng,
            //"geo_type": cmbgType
        },
        function (data) {

            clearSelection();
            $("#poly_main").modal('hide');
            if (data == 'true') {
                toastr.success("Geofence Saved Successfully", "Success");
            } else {
                toastr.error(data, "Error");
            }
            newPoly = true;
            polyLat = [];
            polyLng = [];

            //refreshArea();
            editAreaRecord(aid);
        });
    }
    function addPoint(event) {
        console.log('newPoly', newPoly);
        if (newPoly == true) {
            var PolygonOptions = {
                fillColor: $("#color").val(),
                fillOpacity: 0.5,
                strokeWeight: 2,
                strokeColor: '#57ACF9',
                clickable: false,
                editable: false,
                strokeOpacity: 0.6,
                zIndex: 1
            }
            poly.setOptions(PolygonOptions);
            path_area.insertAt(path_area.length, event.latLng);
            var image = new google.maps.MarkerImage("images/markers/kicon48.png", new google.maps.Size(24, 24), new google.maps.Point(0, 0), new google.maps.Point(12, 12));
            var marker = new google.maps.Marker({
                position: event.latLng,
                map: map_geo,
                draggable: true,
                icon: image
            });

            polyMarkers.push(marker);
            marker.setTitle("#" + path_area.length);

            google.maps.event.addListener(marker, 'click', function () {
                marker.setMap(null);
                for (var i = 0, I = polyMarkers.length; i < I && polyMarkers[i] != marker; ++i);
                polyMarkers.splice(i, 1);
                path_area.removeAt(i);
                //measureCalc();
            });

            google.maps.event.addListener(marker, 'dragend', function () {
                for (var i = 0, I = polyMarkers.length; i < I && polyMarkers[i] != marker; ++i);
                path_area.setAt(i, marker.getPosition());
                // measureCalc();
            });
        }
    }
    function refreshArea() {
        clearMarker();
        $('#btnCreatePoly').hide();
        $('#btnCancelPoly').hide();

        ajax_1 =   $.post(sUrl, {
            "_token": "{{ csrf_token() }}",
            "cmd": "refreshArea",
            "ar_id": $('#area_id').val(),
        },
        function (data) {
            //clearPolyOverlays();
            
            if (data.plyId != null) {
                for (k = 0; k < data.plyId.length; k++) {
                    polyId = data.plyId[k];
                    var bounds = new google.maps.LatLngBounds();
                    var pathArr = [];

                    $('#polyname').text(data.plyName[polyId]);

                    if(data.plyLat[polyId].length > 0)
                    {

                        for (j = 0; j < data.plyLat[polyId].length; j++) {
                            pathArr.push(new google.maps.LatLng(data.plyLat[polyId][j], data.plyLng[polyId][j]));
                        }

                        for (i = 0; i < pathArr.length; i++) {
                            bounds.extend(pathArr[i]);
                        }

                        polygons[polyId] = bounds.getCenter();
                        //console.log(pathArr);
                        creatAreaAfterRefresh1(polyId, bounds.getCenter(), pathArr, data.plyName[polyId], data.plyColor[polyId], k);
                    }
                }
                focusGeofence($('#area_id').val());
            }

        }, 'json');
    }

    function creatAreaAfterRefresh1(pid, center, pathArr, name, color, kk) {

        //console.log(pathArr);

        var marker_options = {
            position: center,
            map: map_geo,
            title: name,
            icon: polyImage,
        };

        //create marker
        var new_marker = new google.maps.Marker(marker_options);
        labelArr.push(new_marker);

        var polyV = new google.maps.Polygon({
            paths: pathArr,
            strokeWeight: 2,
            //fillOpacity: 0.0,
            strokeOpacity: 0.6,
            fillColor: color,
            clickable:false
        });

        polyV.setMap(map_geo);
        polyVarr.push(polyV);

        google.maps.event.addListener(new_marker, "click", function (event) {
            //$("#del_geo").val(pid);
            //$('#confirm-delete').modal('show');
            //if($('input[type=radio][name=geofence]:checked').val() == 'edit')
            //{
            editArea(pid,polyV);
            //}
        });
        google.maps.event.addListener(new_marker,  'rightclick',  function(mouseEvent) {
        //$("#del_geo").val(pid);
        //$('#confirm-delete').modal('show');
        });
    }

    function clearMarker() {
        if (labelArr) {
            for (i in labelArr) {
                labelArr[i].setMap(null);
            }
            for (i in marker_htmlmap) {
                marker_htmlmap[i].setMap(null);
            }
        }
    }
    function clearPolyOverlays() {
        if (polyVarr) {
            for (i in polyVarr) {
                polyVarr[i].setMap(null);
            }
        }
        polyVarr = [];
    }
    function clearSelection() {
        if (polyMarkers) {
            for (i in polyMarkers) {
                polyMarkers[i].setMap(null);
                path_area.removeAt(i);
                polyMarkers.splice(i, 1);
            }
        }
        if (polyMarkers.length > 0) {
            clearSelection();
        }
        // measureReset();
    }
    function removeLineSegment(event) {
      var lastOverlay = overlays.length > 0 ? overlays[overlays.length - 1] : null;    
      if (lastOverlay && lastOverlay.type === "polyline") {
        var path_area = lastOverlay.overlay.getPath();
        path_area.pop(); // remove last line segment
      }
    }
    function focusGeofence(selGeo) {
        //var selGeo = 1;
        if (selGeo > 0) {
            map_geo.panTo(polygons[selGeo], 1000)
            map_geo.setZoom(15);
        }
    }
    function editArea(id,edit_poly){

        editPoly = edit_poly;
        newPoly = false;

        // console.log(edit_poly.getBounds().toSource());
        //zoom=12;
        // map_geo.setCenter(edit_poly.getBounds().getCenter());
        //map_geo.setZoom(zoom);
        ajax_1 =   $.post(sUrl, {
            "_token": "{{ csrf_token() }}",
            "cmd": "edit",
            "id": id
        },
        function(result) {
            // $("#dialog_poly").html(htmltext);
            $('#btnCreatePoly').show();

            jQuery("input:button, input:submit, input:reset").button();

            $("#poly_id").val(result[0].id);
            $("#txtPoly1").val(result[0].polyname);
            $("#color").val(result[0].color);
            //$("#cmbSite").val(result[0].company_site_id).change();
            $("#area_sms_alert").attr("checked", 'checked');
            $("#area_email_alert").attr("checked", 'checked');
            $("#in_alert").attr("checked", 'checked');
            $("#out_alert").attr("checked", 'checked');

            if(result.sms_alert == 0)
                $("#area_sms_alert").attr("checked", false);
            if(result.email_alert == 0)
                $("#area_email_alert").attr("checked", false);
            if(result.in_alert == 0)
                $("#in_alert").attr("checked", false);
            if(result.out_alert == 0)
                $("#out_alert").attr("checked", false);

            edit_poly.setOptions({
                editable: true
            });

            $("#btnAddPoly").hide();
            $("#btnUpdatePoly").show();
            $("#btnCancelUpdate").show();

        }, 'json');
    }

    function updatePoly(polyid){

        //var polyid = $("#poly_id").val();
        //var in_alert = $("#in_alert").is(':checked');
        //var out_alert = $("#out_alert").is(':checked');
        //var sms_alert = $("#area_sms_alert").is(':checked');
        //var email_alert = $("#area_email_alert").is(':checked');
        //var polyname = $('#txtPoly1').val();
        //var siteId   = $("#cmbSite").val();
        //var data2 = $('#cmbSite').select2('data');
        //site_id = data2[0].id;
        //var cmbgType = $("#cmbgType").val();
        polyLat = [];
        polyLng = [];

        allPolygonCoords = editPoly.getPath();

        for (let i = 0; i < allPolygonCoords.length; i++) {
            polyLat.push(allPolygonCoords.getAt(i).lat());
            polyLng.push(allPolygonCoords.getAt(i).lng());
        }

        /*if(polyname == "" || polyname == null){
            alert("Please enter area name");
            //$('#txtPoly1').focus();
            return false;
        }*/
        ajax_1 =   $.post(sUrl, {
            "_token": "{{ csrf_token() }}",
            "cmd": "updateArea",
            "id": polyid,
            "latAdd":polyLat,
            "lngAdd":polyLng
        },
        function(data){

            clearSelection();
            $("#poly_main").modal('hide');
            if(data == 'true') {
                //alert('Geofence Saved Successfully');
            } else {
                alert(data);
            }
            //$('#txtPoly1').val('');
            //$("#cmbSite").val('');
            editPoly.setOptions({
                editable: false
            });

            newPoly = true;
            polyLat = [];
            polyLng = [];

            //refreshArea();
            editAreaRecord(polyid);
        });
    }

</script>
