<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title> {{ getPageTitle() }} | {{ config('app.name')}}</title>
        <!-- fav icon -->
        <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('img/apple-touch-icon.png') }}" />
        <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('img/favicon-32x32.png') }}" />
        <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('img/favicon-16x16.png') }}" />
        
        <link type="text/css"  href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
        <!-- Theme style -->
        <link rel="stylesheet"  href="{{ asset('css/adminltecss/adminlte.min.css') }}">

        <!-- overlayScrollbars -->
        <link type="text/css"  href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/datatable/dataTables.bootstrap.min.css') }}" >
        <link rel="stylesheet" type="text/css" href="{{ asset('css/select2.min.css') }}" >

        <link rel="stylesheet" type="text/css" href="{{ asset('css/toastr.min.css') }}" >
        <link rel="stylesheet" type="text/css" href="{{ asset('css/datatable/buttons.dataTables.min.css') }}">

        <link rel="stylesheet" type="text/css" href="{{ asset('css/daterangepicker.css') }}" />
        <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css') }}" >
        
        <link rel="stylesheet" href="{{ asset('css/adminltecss/coustom.css') }}" >

    </head>
        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('js/jquery.validate.js') }}" defer></script>
        <script>
            var dataTableConfigObj;
              dataTableConfigObj = {
                  "processing": true,
                  "oLanguage": {
                      "sZeroRecords": "No records to display",
                      "sSearch": '<a class="btn searchBtn p-0 pr-4 pl-3 pt-2" id="searchBtn"><i class="fa fa-search"></i></a>',
                      "sLengthMenu": "Show Records : _MENU_ ",
                      "loadingRecords": "&nbsp;",
                      "processing": "Loading...",
                 
                  },
      
                  "ajax": {
                      "type": "GET"
                  },
                  "scrollX": true,
                  "responsive": true,
                  "fixedColumns": {
                      "left": 3,
      
                  },
                  
                  "dom": '<"dt-buttons">Blfrtip<"clear">',
                  "lengthMenu": [10, 25, 50, 75, 100],
                  "paging": true,
                  "autoWidth": true,
                  "bServerSide": false,
                  "buttons":[],
              };
              var dataTableConfigObj_v1;
              dataTableConfigObj_v1 = {
                  "processing": true,
                  "oLanguage": {
                      "sSearch": false,
                      "sLengthMenu": false,
                      "loadingRecords": "&nbsp;",
                      "processing": "Loading...",
                  },
      
                  "ajax": {
                      "type": "GET"
                  },
                  "dom": '<""><"clear">',
                  "lengthMenu": false,
                  "paging": false,
                  "autoWidth": false,
                  "scrollX": true,
                  "responsive": true,
                
                  "bServerSide": false,
              };
            </script>
        <body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
        <div class="wrapper">
            <!-- Navbar -->
            <nav class="main-header navbar navbar-expand navbar-warning" style="height: 66px;">
                <!-- Left navbar links -->
                <ul class="navbar-nav">
                 <!-- Brand Logo -->
                <a href="dashboard" class="logo">
                    {{-- <img src="{{ asset('img/moba_logo.png') }}" alt="AdminLTE Logo" class="brand-image" height="50" /> --}}
                    <i class="nav-icon icon-glyph_moba_logo" style="font-size:100px;"  class="brand-image"></i>
                </a>
                </ul>
                <!-- Right navbar links -->
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <div class="skew_header align-item-center">
                            <span class="text_name">Hi {{ ucfirst(Auth::user()->name) }}</span>
                            <!--  <img src="./img/admin.png" height="50px" class="logo" /> -->
                            <div class="nav-item dropdown drop">
                                <a href="#" class="nav-link dropdown-toggle icon_top_select" data-bs-toggle="dropdown">
                                    {{-- <img class="rounded-circle me-lg-2" src="{{ asset('img/user.jpg') }}" alt="" style="width: 40px; height: 40px;" /> --}}
                                    <i class="nav-icon icon-glyph_user" style="font-size:40px;"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                                    <li class="user-header gril_color">
                                        <div class="media">
                                            <img class="rounded-circle me-lg-2 set-gril-img" alt="Gril" src="{{ asset('img/user.jpg') }}" style="width: 40px; height: 40px;" />

                                            <div class="media-body top-margin">
                                                <h3 class="dropdown-item-title mb-0 user" style="color: #ffcc00;">
                                                    {{ ucfirst(Auth::user()->name); }}
                                                </h3>
                                                <!--<p class="designation" style="color: #8a8a8a;">Software Engineer</p>-->
                                            </div>
                                        </div>
                                    </li>
                                    <li class="user-footer">
                                        {{-- <a href="#" class="btn btn-default btn-set-footer btn-flat user_btn"><i class="fa fa-user text-white"></i></a> --}}
                                        <a onclick="userLogout()" class="btn btn-default btn-set-footer btn-flat text-white" href="#"><i class="fa fa-power-off signout_icon mr-2" aria-hidden="true"></i>Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    {{-- <li class="nav-item">
                        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                            <i class="fas fa-th-large"></i>
                        </a>
                    </li> --}}
                </ul>
            </nav>
            <!-- /.navbar -->
            <!-- Main Sidebar Container -->
            <aside class="main-sidebar sidebar-dark-primary sidebar-no-expand ">
                <!-- Sidebar -->
                <div class="sidebar p-0">
                    <!-- Sidebar Menu -->
                    <nav class="mt-2"> 
                        <ul class="nav nav-pills nav-sidebar">
                            <li class="nav-item nav-top">
                                <a class="nav-link justify-content-end" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars "></i></a>
                            </li>
                        </ul>
                         <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                            {{-- <li class="nav-item">
                                <a class="nav-link justify-content-end" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars "></i></a>
                            </li> --}}
                            <li class="nav-item {{ Request::segment(1) }} {{ (Request::segment(1) == 'dashboard')  ? 'active' : '' }}">
                                <a href="{{url('dashboard')}}" class="nav-link">
                                     <span class="icon-glyph_home mr-2 MenuIcon" style="font-size: 25px;"></span>
                                    <p>
                                        Dashboard
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item {{ Request::segment(1) }} {{ (Request::segment(1) == 'report_center')  ? 'active' : '' }}">
                                <a href="{{url('report_center')}}" class="nav-link">
                                   <span class="icon-glyph_report mr-2 MenuIcon" style="font-size: 25px;"></span>
                                    <p>
                                        Report center
                                    </p>
                                </a>
                            </li>
                            <li  class="nav-item has-treeview {{ Request::segment(1) }} {{ (Request::segment(1) == 'location_map_new')  ? 'active menu-is-opening menu-open' : '' }}">
                               
                                <a class="nav-link" style="cursor:pointer">
                                    <span class="icon-glyph_map mr-2 MenuIcon" style="font-size: 25px;"></span>
                                    <p>
                                        Map View
                                        <i class="icon-glyph_ctrl_down right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li id="machines_nav" class="nav-item machines {{ ((Request::segment(1) == 'location_map_new') && (Request::segment(2) == 'machines'))  ? 'active' : '' }}">
                                        <a href="{{url('location_map_new/machines')}}" class="nav-link">
                                          <p>Machines</p>
                                        </a>
                                    </li>
                                    <li id="poi_nav" class="nav-item poi {{ ((Request::segment(1) == 'location_map_new') && (Request::segment(2) == 'poi'))  ? 'active' : '' }}">
                                        <a href="{{url('location_map_new/poi')}}" class="nav-link">
                                          <p>POI</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li  class="nav-item has-treeview">
                               
                                <a href="#" class="nav-link">
                                 <span class="icon-glyph_hydraulic_settings  mr-2 MenuIcon" style="font-size: 25px;"></span>
                                    <p>
                                        Setting
                                        <i class="icon-glyph_ctrl_down right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                  <li class="nav-item">
                                    <a href="#" class="nav-link">
                                     
                                      <p>User(Theme,Units,...)</p>
                                    </a>
                                  </li>
                                  <li class="nav-item">
                                    <a href="#" class="nav-link">
                                      
                                      <p>Fleet()</p>
                                    </a> 
                                  </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link">
                               <span class="icon-glyph_more mr-2" style="font-size: 25px;"></span>
                                    <p>
                                        More
                                    </p>
                                </a>
                            </li>
                            {{-- <li class="nav-item {{ Request::segment(1) }} {{ (Request::segment(1) == 'appUserLogout')  ? 'active' : '' }}">
                                <a  onclick="userLogout()" href="#" class="nav-link">
                                    <span class="icon-glyph_shutdown mr-2" style="font-size: 25px;"></span>
                                    <p>
                                        Log Out
                                    </p>
                                </a>
                            </li> --}}
       
                        </ul>
                        <ul class="nav nav-pills nav-sidebar">
                            <li class="nav-item nav-footer">
                                <a  onclick="userLogout()" href="#" class="nav-link"><span class="icon-glyph_shutdown mr-2" style="font-size: 25px;"></span><p>Log Out</p></a>
                            </li>
                        </ul>
                    </nav>
                    <!-- /.sidebar-menu -->
                </div>
                <!-- /.sidebar -->
            </aside>
            <!-- Content Wrapper. Contains page content -->
            
            <!-- /.content-wrapper -->
            <!-- Control Sidebar -->
            <script type="text/javascript">
                $(document).ready(function() {
                  $(".drop").click(function() {
                      $(".dropdown-menu").toggleClass("show");
                  });
              });
              function userLogout(){
                  $.ajax({
                      type: "POST",
                      url: "{{url('appUserLogout')}}",
                      data: {},
                      headers: {
                          'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                      },
                      
                         success: function(data) {
                              var returnVal = jQuery.parseJSON(data);
                              // console.log(returnVal);
                              if (returnVal.responseCode == 200) {
                                  toastr.success(returnVal.responseMessage);
                                  window.location.href = '{{ url("/login")}}';
                              }
                          }
                  });  

              }
              </script>
           
