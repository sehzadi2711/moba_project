<DOCTYPE html>
    <html lang="en-US">

        <head>
            <meta charset="utf-8">
        </head>

        <body>
            <p>
                Verify Your Email Address ,
                For Reset Password
            </p>

            <a href="{{$url}}">Click Here</a>.
            
            <p>If you did not create an account, no further action is required.</p>

            <p>
                Best regards, <br>

                {{ config('app.name')}}
            </p>

            <p>
            <hr>
            <span class="break-all">
            </p>
        </body>
    </HTML>
</DOCTYPE>
