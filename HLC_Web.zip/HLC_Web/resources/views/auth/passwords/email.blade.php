<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>{{ config('app.name')}}-Login</title>
    <!-- fav icon -->
    <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('img/apple-touch-icon.png') }}" />

    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('img/favicon-32x32.png') }}" />
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('img/favicon-16x16.png') }}" />
     <!-- css -->
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css') }}" >
    <link rel="stylesheet" type="text/css" href="{{ asset('css/login.css') }}" >
    <link rel="stylesheet" type="text/css" href="{{ asset('css/toastr.min.css') }}" >
     
    <script type="text/javascript" src="{{ asset('js/jquery-3.6.1.min.js') }}"></script>
    <script src="{{ asset('js/jquery.validate.js') }}" defer></script>
    <Style>
         .login-btn {
            display: block;
            margin-left: auto;
        }
        .text-yellow {
            color: #fbba00;
        }
        
        .loader {
            position: relative;
        }
        
        img.loader_imgage {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-44%, -50%);
            height: 34px;
        }
        
        .loader_img {
            width: 100px;
            height: 100px;
            margin: 0 auto;
            animation-name: rotate;
            animation-duration: 35s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
            border-radius: 50%;
            border: 2px dashed #fff;
        }
        
        @keyframes rotate {
            from {
                transform: rotate(-360deg);
            }
            to {
                transform: rotate(360deg);
            }
        }
    </Style>
</head>
<body>
    @include('auth.loader')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 p-0">
                <div class="login_bg">
                    <div class="header">
                        <div class="top_header">
                            <div class="col-sm-8 col-md-6 offset-md-6 p-0">
                                <div class="skew_header">
                                    <img src="{{ asset('img/moba_logo.png') }}" height="50px" class="logo" />
                                </div>
                            </div>
                        </div>
                        <div class="tagline_text">
                            <img src="{{ asset('img/hlc_web.png') }}" />
                        </div>
                    </div>
                    <div class="main">
                        <div class="login_form mb-5 mt-5">
                            <form class="form" method="POST" id="forget-password-form" > 
                                @csrf
                                <div class="form-group">
                                    <div class="input-container">
                                        <input type="text" id="email" name="email" class="input form-control" spellcheck="false" maxlength="25" />
                                        <div class="placeholder">
                                            Enter Email
                                        </div>
                                        <label class="error" style='display:none' for="email" id="email_error"></label>
                                    </div>
                                </div>
                                <div class="form-group pl-2">
                                    <a href="{{ url('login') }}" class="link_fp">Back To Login?</a>
                                </div>

                                <button type="submit" class="btn btn-primary text-right align-right login-btn">Submit</button>
                            </form>
                        </div>
                    </div>
                    <div class="footer">
                        <div class="text-right p-3">
                            <p class="mb-0">MOBA Mobile Automation AG</p>
                            <p class="mb-0">Kapellester, 15</p>
                            <p class="mb-0">65555 Limburg</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var container = $('#errors');
        function updateErrorContainer(errorId, errorMsg) {
            if (typeof errorMsg != 'undefined' && errorMsg != '') {
                $("#" + errorId).removeClass("hidden").find("label").html(errorMsg);
                container.removeClass("hidden");
            }
        }
        $(document).ready(function($) {
            $("#forget-password-form").validate({
                rules: {
                    email: {
                        required: true,
                        email: true,
                        maxlength: 50,
                    },
                },
                messages: {
                    email: {
                        required: "Please Enter Your Email",
                        email: "Please Enter Valid Email",
                        maxlength: "Please Enter Email no more than 50 characters"
                    },
                },
                errorPlacement: function(error, element) {
                    if (element.is(":radio")) {
                        error.appendTo(element.parents('.form-group'));
                    } else { // This is the default behavior 
                        // error.insertAfter(element);
                    }
                },
                submitHandler: function(form) {
                    $(".login-btn").prop("disabled", true);
                
                    $.ajax({
                        url: "{{url('/forgetPassword')}}",
                        type: "POST",
                        data: 
                            $('#forget-password-form').serialize(),
                            success: function(res) {
                                var returnVal = jQuery.parseJSON(res);
                                // console.log(returnVal.responseCode);
                                if (returnVal.responseCode == 200) {
                                    toastr.success(returnVal.responseMessage);
                                    setTimeout(function () {
                                        window.location.href = '{{ url("/forget-password")}}';
                                    }, 800);
                                }else{
                                    $(".login-btn"). attr("disabled", false);
                                    document.getElementById("forget-password-form").reset(); 
                                    toastr.error(returnVal.responseMessage); 
                                }
                            }
                    });
                }

            });
        });
    </script>
    <script type="text/javascript" src="{{ asset('js/bootstrap.bundle.min.js') }}" defer></script>
    
    {{-- <script type="text/javascript" src="https://use.fontawesome.com/b9bdbd120a.js"></script> --}}
    <script type="text/javascript" src="{{ asset('js/script.js') }}" defer></script>
    <script type="text/javascript" src="{{ asset('js/toastr.min.js') }}" defer></script>

    {!! Toastr::message() !!}
</body>
</html>